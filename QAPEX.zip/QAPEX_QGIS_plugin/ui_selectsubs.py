# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_selectsubs.ui'
#
# Created: Sun Jan 25 17:56:44 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_SelectSubbasinsDialog(object):
    def setupUi(self, SelectSubbasinsDialog):
        SelectSubbasinsDialog.setObjectName(_fromUtf8("SelectSubbasinsDialog"))
        SelectSubbasinsDialog.resize(370, 415)
        SelectSubbasinsDialog.setSizeGripEnabled(False)
        self.gridLayout = QtGui.QGridLayout(SelectSubbasinsDialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_2 = QtGui.QLabel(SelectSubbasinsDialog)
        self.label_2.setTextFormat(QtCore.Qt.AutoText)
        self.label_2.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_2.setWordWrap(False)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 3)
        self.checkBox = QtGui.QCheckBox(SelectSubbasinsDialog)
        self.checkBox.setObjectName(_fromUtf8("checkBox"))
        self.gridLayout.addWidget(self.checkBox, 1, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(SelectSubbasinsDialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setWordWrap(False)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 3)
        self.areaButton = QtGui.QRadioButton(self.groupBox)
        self.areaButton.setObjectName(_fromUtf8("areaButton"))
        self.gridLayout_2.addWidget(self.areaButton, 1, 0, 1, 1)
        self.threshold = QtGui.QLineEdit(self.groupBox)
        self.threshold.setInputMethodHints(QtCore.Qt.ImhFormattedNumbersOnly)
        self.threshold.setObjectName(_fromUtf8("threshold"))
        self.gridLayout_2.addWidget(self.threshold, 1, 1, 2, 1)
        self.pushButton = QtGui.QPushButton(self.groupBox)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.gridLayout_2.addWidget(self.pushButton, 1, 2, 2, 1)
        self.percentButton = QtGui.QRadioButton(self.groupBox)
        self.percentButton.setObjectName(_fromUtf8("percentButton"))
        self.gridLayout_2.addWidget(self.percentButton, 2, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox, 2, 0, 1, 3)
        self.count = QtGui.QLabel(SelectSubbasinsDialog)
        self.count.setObjectName(_fromUtf8("count"))
        self.gridLayout.addWidget(self.count, 3, 0, 1, 1)
        self.saveButton = QtGui.QPushButton(SelectSubbasinsDialog)
        self.saveButton.setObjectName(_fromUtf8("saveButton"))
        self.gridLayout.addWidget(self.saveButton, 3, 1, 1, 1)
        self.cancelButton = QtGui.QPushButton(SelectSubbasinsDialog)
        self.cancelButton.setObjectName(_fromUtf8("cancelButton"))
        self.gridLayout.addWidget(self.cancelButton, 3, 2, 1, 1)

        self.retranslateUi(SelectSubbasinsDialog)
        QtCore.QMetaObject.connectSlotsByName(SelectSubbasinsDialog)

    def retranslateUi(self, SelectSubbasinsDialog):
        SelectSubbasinsDialog.setWindowTitle(QtGui.QApplication.translate("SelectSubbasinsDialog", "Select subbasins for merging", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "Hold Ctrl and click in the subbasins you want to select. Selected \n"
"subbasins will turn yellow, and a count is shown at the bottom left \n"
"of this window.  If you want to start again release Ctrl and \n"
"click outside the watershed; then hold Ctrl and resume selection. \n"
"\n"
"You can pause in the selection to pan or zoom provided you hold \n"
"Ctrl again when you resume selection.\n"
"\n"
"Small subbasins selected by threshold (below) will be additional to \n"
"those selected by clicking.\n"
"\n"
"When finished click \"Save\" to save your selection, \n"
"or \"Cancel\" to abandon the selection.", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "Select small subbasins", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("SelectSubbasinsDialog", "Select by threshold", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "Set a threshold for small subbasins, either as an area in hectares \n"
"or as a percentage of the mean subbasin area.   Click the Select \n"
"button to select subbasins below the threshold.", None, QtGui.QApplication.UnicodeUTF8))
        self.areaButton.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "Area (ha)", None, QtGui.QApplication.UnicodeUTF8))
        self.threshold.setToolTip(QtGui.QApplication.translate("SelectSubbasinsDialog", "The maximum distance a point may be moved to place it on the stream network (snapped).  Points which would require more than this distance will not be used.", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "Select", None, QtGui.QApplication.UnicodeUTF8))
        self.percentButton.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "Percentage of mean area", None, QtGui.QApplication.UnicodeUTF8))
        self.count.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "0 selected", None, QtGui.QApplication.UnicodeUTF8))
        self.saveButton.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "Save", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelButton.setText(QtGui.QApplication.translate("SelectSubbasinsDialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))

