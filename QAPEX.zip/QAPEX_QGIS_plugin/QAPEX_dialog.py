# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QAPEXDialog
                                 A QGIS plugin
 APEX in QGIS
                             -------------------
        begin                : 2016-07-29
        git sha              : $Format:%H$
        copyright            : (C) 2016 by KJY
        email                : K
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt4 import QtGui
from ui_qapex import Ui_QAPEXDialogBase

"""
import os
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'QAPEX_dialog_base.ui'))
"""

class QAPEXDialog(QtGui.QDialog, Ui_QAPEXDialogBase):
    def __init__(self):#, parent=None):
        """Constructor."""
        #super(QAPEXDialog, self).__init__(parent)
        QtGui.QDialog.__init__(self)
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
