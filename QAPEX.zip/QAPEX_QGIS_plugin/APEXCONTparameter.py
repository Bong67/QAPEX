# -*- coding: utf-8 -*-

# Import the PyQt and QGIS libraries
from PyQt4.QtCore import * # @UnusedWildImport
from PyQt4.QtGui import * # @UnusedWildImport
from qgis.core import * # @UnusedWildImport
# Import the code for the dialog
from APEXCONTparameterdialog import APEXCONTParameterDialog
import takeapex, Termdict
from QSWATUtils import QSWATUtils
import os.path, re


class APEXCONTParameter(QObject):

    def __init__(self, iface, gv):
        QObject.__init__(self)
        self._iface = iface
        self._gv = gv
        self._dlg = APEXCONTParameterDialog()
        self._dlg.setWindowFlags(self._dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self._set = takeapex.SuperClass()
        
        self._dict = Termdict.Term_Dict()
        self._Des_dict = self._dict._Des_dict


        #default parm
        #line_1
        self._dlg.NBYR_line.setText("10")
        self._dlg.IYR_line.setText("1985")
        self._dlg.IMO_line.setText("1")
        self._dlg.IDA_line.setText("1")
        self._dlg.IPD_line.setText("6")
        self._dlg.NGN_line.setText("2345")
        self._dlg.IGN_line.setText("0")
        self._dlg.IGSD_line.setText("0")
        self._dlg.LPYR_line.setText("0")
        self._dlg.IET_line.setText("1")
        self._dlg.ISCN_line.setText("0")
        self._dlg.ITYP_line.setText("0")
        self._dlg.ISTA_line.setText("0")
        self._dlg.IHUS_line.setText("1")
        self._dlg.NVCN_line.setText("0")
        self._dlg.INFL_line.setText("0")
        self._dlg.MASP_line.setText("1")
        self._dlg.IERT_line.setText("0")
        self._dlg.LBP_line.setText("0")
        self._dlg.NUPC_line.setText("1")
        #line 2
        self._dlg.MNUL_line.setText("0")
        self._dlg.LPD_line.setText("0")
        self._dlg.MSCP_line.setText("0")
        self._dlg.ISLF_line.setText("0")
        self._dlg.NAQ_line.setText("0")
        self._dlg.IHY_line.setText("0")
        self._dlg.ICO2_line.setText("0")
        self._dlg.ISW_line.setText("0")
        self._dlg.IGMX_line.setText("0")
        self._dlg.IDIR_line.setText("0")
        self._dlg.IMW_line.setText("0")
        self._dlg.IOX_line.setText("0")
        self._dlg.IDNT_line.setText("1")
        self._dlg.IAZM_line.setText("0")
        self._dlg.IPAT_line.setText("0")
        self._dlg.IHRF_line.setText("0")
        self._dlg.IWTB_line.setText("0")
        self._dlg.NSTP_line.setText("0")
        self._dlg.ISAP_line.setText("0")
        #line 3
        self._dlg.RFN_line.setText("0.77")
        self._dlg.CO2_line.setText("380")
        self._dlg.CQN_line.setText("0")
        self._dlg.PSTX_line.setText("0")
        self._dlg.YWI_line.setText("0")
        self._dlg.BTA_line.setText("0")
        self._dlg.EXPK_line.setText("0")
        self._dlg.QG_line.setText("0")
        self._dlg.QCF_line.setText("0.50")
        self._dlg.CHSO_line.setText("0.17")
        #line 4
        self._dlg.BWD_line.setText("1.00")
        self._dlg.FCW_line.setText("1.00")
        self._dlg.FPSC_line.setText("0.10")
        self._dlg.GWSO_line.setText("50.00")
        self._dlg.RFTO_line.setText("10.00")
        self._dlg.RFPO_line.setText("0.95")
        self._dlg.SATO_line.setText("0")
        self._dlg.FL_line.setText("0")
        self._dlg.FW_line.setText("0")
        self._dlg.ANG_line.setText("90.00")
        #line 5
        self._dlg.UXP_line.setText("0.60")
        self._dlg.DIAM_line.setText("0")
        self._dlg.ACW_line.setText("1.00")
        self._dlg.GZL0_line.setText("0")
        self._dlg.RTN0_line.setText("100.00")
        self._dlg.BXCT_line.setText("0")
        self._dlg.BYCT_line.setText("0")
        self._dlg.DTHY_line.setText("0")
        self._dlg.QTH_line.setText("0")
        self._dlg.STND_line.setText("5.00")
        #line 6
        self._dlg.DRV_line.setText("4.00")
        self._dlg.PCO0_line.setText("0")
        self._dlg.RCC0_line.setText("0")
        self._dlg.CSLT_line.setText("0")
        self._dlg.BUS1_line.setText("0.22")
        self._dlg.BUS2_line.setText("0.68")
        self._dlg.BUS3_line.setText("0.95")
        self._dlg.BUS4_line.setText("0.61")
    
    

    def init(self):
        """Set connections to controls."""
        settings = QSettings()
        APEXCONTParameter._path = self._gv.projDir
        
        self._dlg.Save_pushButton.clicked.connect(self.doSave)
        self._dlg.Cancel_pushButton.clicked.connect(self.doClose)  #완
        self._dlg.Notes_push.clicked.connect(self.Describe)

    def run(self):
        self.init()
        self._dlg.show()

        result = self._dlg.exec_()  # @UnusedVariable
        self._gv.delineatePos = self._dlg.pos()
        self._gv.writeMasterProgress(0,0)
        return 0


    def Describe(self):
        try:
            self._dlg.Notes_text.setText(self._Des_dict[str(self._dlg.Notes_lineEdit.text())])
        except KeyError:
            self._dlg.Notes_text.setText(" ")
        return

    def doSave(self):
        f = open(APEXCONTParameter._path+"/Source/APEXCONT_parm.txt", "w")
        f.write(self._dlg.NBYR_line.text()+","+self._dlg.IYR_line.text()+","+self._dlg.IMO_line.text()
                +","+self._dlg.IDA_line.text()+","+self._dlg.IPD_line.text()+","+self._dlg.NGN_line.text()
                +","+self._dlg.IGN_line.text()+","+self._dlg.IGSD_line.text()+","+self._dlg.LPYR_line.text()
                +","+self._dlg.IET_line.text()+","+self._dlg.ISCN_line.text()+","+self._dlg.ITYP_line.text()
                +","+self._dlg.ISTA_line.text()+","+self._dlg.IHUS_line.text()+","+self._dlg.NVCN_line.text()
                +","+self._dlg.INFL_line.text()+","+self._dlg.MASP_line.text()+","+self._dlg.IERT_line.text()
                +","+self._dlg.LBP_line.text()+","+self._dlg.NUPC_line.text()+"\n")
        f.write(self._dlg.MNUL_line.text()+","+self._dlg.LPD_line.text()+","+self._dlg.MSCP_line.text()
                +","+self._dlg.ISLF_line.text()+","+self._dlg.NAQ_line.text()+","+self._dlg.IHY_line.text()
                +","+self._dlg.ICO2_line.text()+","+self._dlg.ISW_line.text()+","+self._dlg.IGMX_line.text()
                +","+self._dlg.IDIR_line.text()+","+self._dlg.IMW_line.text()+","+self._dlg.IOX_line.text()
                +","+self._dlg.IDNT_line.text()+","+self._dlg.IAZM_line.text()+","+self._dlg.IPAT_line.text()
                +","+self._dlg.IHRF_line.text()+","+self._dlg.IWTB_line.text()+","+self._dlg.NSTP_line.text()
                +","+self._dlg.ISAP_line.text()+"\n")
        f.write(self._dlg.RFN_line.text()+","+self._dlg.CO2_line.text()+","+self._dlg.CQN_line.text()
                +","+self._dlg.PSTX_line.text()+","+self._dlg.YWI_line.text()+","+self._dlg.BTA_line.text()
                +","+self._dlg.EXPK_line.text()+","+self._dlg.QG_line.text()+","+self._dlg.QCF_line.text()
                +","+self._dlg.CHSO_line.text()+"\n")
        f.write(self._dlg.BWD_line.text()+","+self._dlg.FCW_line.text()+","+self._dlg.FPSC_line.text()
                +","+self._dlg.GWSO_line.text()+","+self._dlg.RFTO_line.text()+","+self._dlg.RFPO_line.text()
                +","+self._dlg.SATO_line.text()+","+self._dlg.FL_line.text()+","+self._dlg.FW_line.text()
                +","+self._dlg.ANG_line.text()+"\n")
        f.write(self._dlg.UXP_line.text()+","+self._dlg.DIAM_line.text()+","+self._dlg.ACW_line.text()
                +","+self._dlg.GZL0_line.text()+","+self._dlg.RTN0_line.text()+","+self._dlg.BXCT_line.text()
                +","+self._dlg.BYCT_line.text()+","+self._dlg.DTHY_line.text()+","+self._dlg.QTH_line.text()
                +","+self._dlg.STND_line.text()+"\n")
        f.write(self._dlg.DRV_line.text()+","+self._dlg.PCO0_line.text()+","+self._dlg.RCC0_line.text()
                +","+self._dlg.CSLT_line.text()+","+self._dlg.BUS1_line.text()+","+self._dlg.BUS2_line.text()
                +","+self._dlg.BUS3_line.text()+","+self._dlg.BUS4_line.text()+"\n")
        f.close()
        self._dlg.close()
        return


    def doClose(self):
        """Close form."""
        self._dlg.close()

