# -*- coding: utf-8 -*-

# Import the PyQt and QGIS libraries
from PyQt4.QtCore import * # @UnusedWildImport
from PyQt4.QtGui import * # @UnusedWildImport
from qgis.core import * # @UnusedWildImport
# Import the code for the dialog
from editdialog import EditDialog
import takeapex
from QSWATUtils import QSWATUtils
import os.path, re, shutil, subprocess
from APEXparameter import APEXParameter
from APEXCONTparameter import APEXCONTParameter



class Edit(QObject):

    _MDB_path = ''
    _Weather_name = ''
    _OPS_name = ''
    _WINAPEXDIFAULTDIR = 'C:\\APEX\\WINAPEX'


    def __init__(self, iface, gv):
        QObject.__init__(self)
        self._iface = iface
        self._gv = gv
        self._dlg = EditDialog()
        self._dlg.setWindowFlags(self._dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self._set = takeapex.SuperClass()

    def init(self):
        """Set connections to controls."""
        settings = QSettings()
        self._dlg.MDB_pushButton.clicked.connect(self.MDB_set)
        self._dlg.Weather_pushButton.clicked.connect(self.Weather_set)
        self._dlg.OPS_pushButton.clicked.connect(self.OPS_set)
        self._dlg.Run_pushButton.clicked.connect(self.Run_APEX)
        self._dlg.Cancel_pushButton.clicked.connect(self.doClose)
        self._dlg.APEXCONT_pushButton.clicked.connect(self.APEXCONT_set)
        self._dlg.parm_pushButton.clicked.connect(self.Parm_set)
        self._dlg.Set_pushButton.clicked.connect(self.APEX_set)
        

    def run(self):
        self.init()
        self._dlg.show()

        
        Edit._path = self._gv.projDir
        result = self._dlg.exec_()  # @UnusedVariable
        self._gv.delineatePos = self._dlg.pos()
        self._gv.writeMasterProgress(0,0)
        return 0

    def MDB_set(self):
        Edit._MDB_path = QFileDialog.getOpenFileName(None, 'Select a APEX MDB file', 'C:\\')
        self._dlg.MDB_lineEdit.setText(Edit._MDB_path)
        f = open(Edit._path+"/Source/MDB_path.txt", "w")
        f.write(Edit._MDB_path)
        f.close()
        #APEXCONT_Combobox(add)
        Read = self._set.Read_MDB(Edit._MDB_path, "[Control Table APEX]")
        for APEXCONT_list in Read:
            self._dlg.APEXCONT_comboBox.addItem(str(APEXCONT_list[0]))
        return

    def Weather_set(self):
        Edit._Weather_name = QFileDialog.getExistingDirectory(None, 'Select a folder:', 'C:\\', QFileDialog.ShowDirsOnly)
        self._dlg.Weather_lineEdit.setText(Edit._Weather_name)
        return

    def OPS_set(self):
        Edit._OPS_name = QFileDialog.getExistingDirectory(None, 'Select a folder:', 'C:\\', QFileDialog.ShowDirsOnly)
        self._dlg.OPS_lineEdit.setText(Edit._OPS_name)
        return

    def APEX_set(self):

        path = Edit._path+"/Scenarios/sample"
        if not os.path.isdir(path):
            os.mkdir(path) 
        
        
        self._set.APEXDIM(path, 25, 25, 125,15,10,4,25,"5","1","400")
        self._set.APEXFILE(path, self._dlg.MDB_lineEdit.text()) 
        self._set.CROP(path, self._dlg.MDB_lineEdit.text()) 
        self._set.FERT(path, self._dlg.MDB_lineEdit.text()) 
        self._set.MLRN(path, self._dlg.MDB_lineEdit.text()) 
        self._set.OPSC(path, self._dlg.MDB_lineEdit.text())
        self._set.PEST(path, self._dlg.MDB_lineEdit.text())
        self._set.RFDTLST(path, self._dlg.MDB_lineEdit.text())
        self._set.SITE(path, self._dlg.MDB_lineEdit.text())
        self._set.SUBA(path, self._dlg.MDB_lineEdit.text())

        self._set.SOIL(path, self._dlg.MDB_lineEdit.text())
        self._set.TILL(path, self._dlg.MDB_lineEdit.text())
        self._set.TR55(path, self._dlg.MDB_lineEdit.text())
        self._set.WDLST(path, self._dlg.MDB_lineEdit.text())
        self._set.WIND(path, self._dlg.MDB_lineEdit.text())
        self._set.WPM(path, self._dlg.MDB_lineEdit.text())
        self._set.PSOCOM(path, self._dlg.MDB_lineEdit.text())#
        self._set.PRNT(path, self._dlg.MDB_lineEdit.text())#
        self._set.sub(Edit._path, path, self._dlg.MDB_lineEdit.text(), self._dlg.Weather_lineEdit.text(), self._dlg.OPS_lineEdit.text())  #<< revise __ 
        
        #Weather
        Read = self._set.Read_MDB(self._dlg.MDB_lineEdit.text(), "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(path+"/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x] #g_line[1] = WINAPEX.SUB

        f = open(path+"/"+g_line[1], "r")
        f.readline()
        f_line = f.readline()
        f.close()
        f_line_strip = f_line.strip().split(" ")
        f_line = [x for x in f_line_strip if x]
        WITH_num= f_line[7]
        
        Read = self._set.Read_MDB(self._dlg.MDB_lineEdit.text(), "ApexFile")
        for line in Read:
            if line[1] == "FPMV":
                WDLST_name = line[2]

        f = open(path+"/"+WDLST_name, "r")
        f_lines = f.readlines()
        f.close()
        for f_line in f_lines:
            f_line_strip = f_line.strip().split(" ")
            f_line = [x for x in f_line_strip if x]
            if str(f_line[0]) == str(WITH_num):
                Weather_county_name = f_line[5]
                SIT_PARAM = [[f_line[2],f_line[3],f_line[4],'1','0','0','0','1000','1000','0'],
                             ['0','0','0','0','0','0','0','0','0','0'], f_line[0], f_line[1]] #SIT - xct,yct,elv (f_line => WDLST.DAT)
                
        self._set.APEXRUN(path, self._dlg.MDB_lineEdit.text(), Weather_county_name)
        
        SIT_user_param = '' 
        self._set.SIT(path,self._dlg.MDB_lineEdit.text(), SIT_user_param, SIT_PARAM)
        #APEXCONT
        APEXCONT_Text = self._dlg.APEXCONT_comboBox.currentText()
        if APEXCONT_Text == "Users Control":
            self._set.APEXCONT_Users(path, Edit._path, self._dlg.MDB_lineEdit.text())
        else:
            self._set.APEXCONT(path, self._dlg.MDB_lineEdit.text(), APEXCONT_Text)
        
        self._set.PARMS(path) #
        self._set.sol(path, self._dlg.MDB_lineEdit.text())
        self._set.wnd(path, self._dlg.MDB_lineEdit.text())
        self._set.wp1(path, self._dlg.MDB_lineEdit.text())
        #ops is done where takeapex

    def Run_APEX(self):
        os.chdir(Edit._path+"/Scenarios/sample/")
        shutil.copy(Edit._WINAPEXDIFAULTDIR+"\\apexprog\\apex0806.exe", Edit._path+"/Scenarios/sample/apex0806.exe")
        subprocess.call(Edit._path+"/Scenarios/sample/apex0806.exe")

        Scenario_name = self._dlg.Scenario_lineEdit.text()
        if not os.path.isdir(Edit._path+"/Scenarios/"+Scenario_name):
            os.mkdir(Edit._path+"/Scenarios/"+Scenario_name)

        for file_list in os.listdir(Edit._path+"/Scenarios/sample"):
            shutil.copy(Edit._path+"/Scenarios/sample/"+file_list, Edit._path+"/Scenarios/"+Scenario_name+"/"+file_list)   
        return

    def doClose(self):
        """Close form."""
        self._dlg.close()

    def Parm_set(self):
        APEX_Parm = APEXParameter(self._iface, self._gv)
        APEX_Parm.run()
        return

    def APEXCONT_set(self):
        APEXCONT_Parm = APEXCONTParameter(self._iface, self._gv)
        APEXCONT_Parm.run()
        self._dlg.APEXCONT_comboBox.addItem("Users Control")
        self._dlg.APEXCONT_comboBox.setCurrentIndex(self._dlg.APEXCONT_comboBox.findText("Users Control"))
