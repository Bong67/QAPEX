# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QAPEX
                                 A QGIS plugin
 APEX in QGIS
                              -------------------
        begin                : 2016-07-29
        git sha              : $Format:%H$
        copyright            : (C) 2016 by KJY
        email                : K
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
import os.path
import subprocess
import time
import resources_rc
# Import the code for the dialog
from QAPEX_dialog import QAPEXDialog
#append
from QSWATUtils import QSWATUtils, FileTypes
from qswatdialog import QSwatDialog
from hrus import HRUs
from QSWATUtils import QSWATUtils, FileTypes
from QSWATTopology import QSWATTopology
from globals import GlobalVars
from delineation import Delineation
from parameters import Parameters
from visualise import Visualise
from edit import Edit
from about import AboutQSWAT


class QAPEX():
    """QGIS Plugin Implementation."""
    _QSWATVERSION = 'Test'
    _SWATEDITORVERSION = Parameters._SWATEDITORVERSION
    _SLOPE_GROUP_NAME = 'Slope'
    _LANDUSE_GROUP_NAME = 'Landuse'
    _SOIL_GROUP_NAME = 'Soil'
    _WATERSHED_GROUP_NAME = 'Watershed'
    _RESULTS_GROUP_NAME = 'Results'
    def __init__(self, iface):
#append
        
        self._gv = None
#append
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self._iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'QAPEX_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self._odlg = QAPEXDialog()
        self._demIsProcessed = False
        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&QAPEX')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self._iface.addToolBar(u'QAPEX')
        self.toolbar.setObjectName(u'QAPEX')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('QAPEX', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self._iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    '''def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/QAPEX/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'QAPEX'),
            callback=self.run,
            parent=self._iface.mainWindow())
    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self._iface.removePluginMenu(
                self.tr(u'&QAPEX'),
                action)
            self._iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar'''

    
    def initGui(self):
        """Create QSWAT button in the toolbar."""
        ## Action that will start plugin configuration
        self.action = QAction(
            QIcon(":/plugins/QAPEX/icon.png"),
            u"QAPEX", self._iface.mainWindow())
        # connect the action to the run method
        self.action.triggered.connect(self.run)

        # Add toolbar button and menu item
        self._iface.addToolBarIcon(self.action)
        self._iface.addPluginToMenu(u"&QAPEX", self.action)

    def unload(self):
        """Remove the QSWAT menu item and icon."""
        self._iface.removePluginMenu(u"&QAPEX", self.action)
        self._iface.removeToolBarIcon(self.action)
    



    def run(self):
        """Run method that performs all the real work"""

#append
 #connect buttons
        self._odlg.reportsBox.setVisible(False)
        self._odlg.reportsLabel.setVisible(False)
        self._odlg.reportsBox.clear()
        self._odlg.reportsBox.addItem(QSWATUtils.trans('Select report to view'))

        self._odlg.aboutButton.clicked.connect(self.about)
        self._odlg.newButton.clicked.connect(self.newProject)
        self._odlg.existingButton.clicked.connect(self.existingProject)
        self._odlg.delinButton.clicked.connect(self.doDelineation)
        self._odlg.hrusButton.clicked.connect(self.doCreateHRUs)
        self._odlg.editButton.clicked.connect(self.startEditor)
        self._odlg.visualiseButton.clicked.connect(self.visualise)
        self._odlg.paramsButton.clicked.connect(self.runParams)
        self._odlg.reportsBox.activated.connect(self.showReport)
        self.initButtons()   #0811 #제거
        self._odlg.projPath.setText('')
        
        # show the dialog
        self._odlg.show()
        # initially only new/existing project buttons visible if project not set
        proj = QgsProject.instance()
        if proj.fileName() == '':
            self._odlg.mainBox.setVisible(False)
        else:
            self._iface.mainWindow().setCursor(Qt.WaitCursor)
            self.setupProject(proj, False)
            self._iface.mainWindow().setCursor(Qt.ArrowCursor)
        
        # Run the dialog event loop
        result = self._odlg.exec_()
        # See if OK was pressed
        if result:
            # Do something useful here - delete the line containing pass and
            # substitute with your code.
            pass
    def about(self):
        """Show information about QSWAT."""
        form = AboutQSWAT(self._gv)
        form.run(QAPEX._QSWATVERSION)

    def newProject(self):
        """Call QGIS actions to create and name a new project."""
        self._iface.actionNewProject().trigger()
        # save the project to force user to supply a name and location
        self._iface.actionSaveProjectAs().trigger()
        self.initButtons()    #0811  #제
        # allow time for project to be created
        time.sleep(2)
        proj = QgsProject.instance()
        if proj.fileName() == '':
            # QSWATUtils.error('No project created', False)
            return
        self._odlg.raise_()
        self.setupProject(proj, False)
        self._gv.writeMasterProgress(0, 0)
        
    def initButtons(self):
        """Initial button settings."""
        self._odlg.delinLabel.setText('Step 1')
        self._odlg.hrusLabel.setText('Step 2')
        self._odlg.hrusLabel.setEnabled(False)
        self._odlg.hrusButton.setEnabled(False)
        self._odlg.editLabel.setEnabled(False)
        self._odlg.editButton.setEnabled(False)
        self._odlg.visualiseLabel.setVisible(False)
        self._odlg.visualiseButton.setVisible(False)


    def existingProject(self):
        """Open an existing QGIS project."""
        self._iface.actionOpenProject().trigger()
        # allow time for project to be opened
        time.sleep(2)
        proj = QgsProject.instance()
        if proj.fileName() == '':
            QSWATUtils.error('No project opened', False)
            return
        self._odlg.raise_()
        self.setupProject(proj, False)

    def setupProject(self, proj, isBatch):
        """Set up the project."""
        self._odlg.mainBox.setVisible(True)
        self._odlg.mainBox.setEnabled(False)
        self._odlg.setCursor(Qt.WaitCursor)
        self._odlg.projPath.setText('Restarting project ...')
        proj.setTitle(QFileInfo(proj.fileName()).baseName())
        # now have project so initiate global vars
        # if we do this earlier we cannot for example find the project database
        self._gv = GlobalVars(isBatch)
        self._gv.plugin_dir = self.plugin_dir
        self._odlg.projPath.repaint()
        self.setLegendGroups()
        if self.demProcessed():
            self._demIsProcessed = True
            self.allowCreateHRU()
            hrus = HRUs(self._iface, self._gv, self._odlg.reportsBox)
            result = hrus.tryRun()
            if result == 1:
                QSWATUtils.progress('Done', self._odlg.hrusLabel)
                self._odlg.editLabel.setEnabled(True)
                self._odlg.editButton.setEnabled(True)
        if os.path.exists(QSWATUtils.join(self._gv.tablesOutDir, Parameters._OUTPUTDB)):
            self._odlg.visualiseLabel.setVisible(True)
            self._odlg.visualiseButton.setVisible(True)
        self._odlg.projPath.setText(self._gv.projDir)
        self._odlg.mainBox.setEnabled(True)
        self._odlg.setCursor(Qt.ArrowCursor)
            
    def runParams(self):
        """Run parameters form."""
        params = Parameters(self._gv)
        params.run()

#re
    def showReport(self):
        """Display selected report."""
        if not self._odlg.reportsBox.hasFocus():
            return
        item = self._odlg.reportsBox.currentText()
        if item == Parameters._TOPOITEM:
            report = Parameters._TOPOREPORT
        elif item == Parameters._BASINITEM:
            report = Parameters._BASINREPORT
        elif item == Parameters._HRUSITEM:
            report = Parameters._HRUSREPORT
        else:
            return
        report = QSWATUtils.join(self._gv.textDir, report)
        if os.name == 'nt': # Windows
            os.startfile(report)
        elif os.name == 'posix': # Linux
            subprocess.call(('xdg-open', report))
        self._odlg.reportsBox.setCurrentIndex(0)

    def doDelineation(self):
        """Run the delineation dialog."""
        delin = Delineation(self._iface, self._gv, self._demIsProcessed)
        result = delin.run()
        if result == 1:
            self.allowCreateHRU()
            # remove old data so cannot be reused
            self._gv.db.clearTable('BASINSDATA1')
        elif result == 0:
            self._demIsProcessed = False
            self._odlg.delinLabel.setText('Step 1')
            self._odlg.hrusLabel.setText('Step 2')
            self._odlg.hrusLabel.setEnabled(False)
            self._odlg.hrusButton.setEnabled(False)
            self._odlg.editLabel.setEnabled(False)
            self._odlg.editButton.setEnabled(False)
        self._odlg.raise_()

    def doCreateHRUs(self):
        """Run the HRU creation dialog."""
        hrus = HRUs(self._iface, self._gv, self._odlg.reportsBox)
        result = hrus.run()
        if result == 1:
            # TODO: more?
            QSWATUtils.progress('Done', self._odlg.hrusLabel)
            self._odlg.editLabel.setEnabled(True)
            self._odlg.editButton.setEnabled(True)
        self._odlg.raise_()
            
    def demProcessed(self):
        """
        Return true if we can proceed with HRU creation.
        
        Return false if any required project setting is not found 
        in the project file
        Return true if:
        Using existing watershed and watershed grid exists and 
        is newer than dem
        or
        Not using existing watershed and filled dem exists and 
        is no older than dem, and
        watershed shapefile exists and is no older than filled dem
        """
        proj = QgsProject.instance()
        if not proj:
            QSWATUtils.loginfo('demProcessed failed: no project')
            return False
        title = proj.title()
        demFile, found = proj.readEntry(title, 'delin/DEM', '')
        if not found or demFile == '':
            QSWATUtils.loginfo('demProcessed failed: no DEM')
            return False
        li = self._iface.legendInterface()
        demFile = QSWATUtils.join(self._gv.projDir, demFile)
        demLayer, loaded = QSWATUtils.getLayerByFilename(li.layers(), demFile, FileTypes._DEM, self._gv, True)
        if not demLayer:
            QSWATUtils.loginfo('demProcessed failed: no DEM layer')
            return False
        if loaded: 
            li.moveLayer(demLayer, self._gv.watershedGroupIndex)
        self._gv.demFile = demFile
        outletFile, found = proj.readEntry(title, 'delin/outlets', '')
        if found and outletFile:
            outletFile = QSWATUtils.join(self._gv.projDir, outletFile)
            outletLayer, loaded = \
                QSWATUtils.getLayerByFilename(li.layers(), outletFile, FileTypes._OUTLETS, self._gv, True)
            if not outletLayer:
                QSWATUtils.loginfo('demProcessed failed: no outlet layer')
                return False
            if loaded: 
                li.moveLayer(outletLayer, self._gv.watershedGroupIndex)
        else:
            outletLayer = None
        self._gv.outletFile = outletFile
        streamFile, found = proj.readEntry(title, 'delin/net', '')
        if not found or streamFile == '':
            QSWATUtils.loginfo('demProcessed failed: no stream reaches shapefile')
            return False
        streamFile = QSWATUtils.join(self._gv.projDir, streamFile)
        streamLayer, loaded = \
            QSWATUtils.getLayerByFilename(li.layers(), streamFile, FileTypes._STREAMS, self._gv, True)
        if not streamLayer:
            QSWATUtils.loginfo('demProcessed failed: no stream reaches layer')
            return False
        if loaded: 
            li.moveLayer(streamLayer, self._gv.watershedGroupIndex)
        self._gv.streamFile = streamFile
        wshedFile, found = proj.readEntry(title, 'delin/wshed', '')
        if not found or wshedFile == '':
            QSWATUtils.loginfo('demProcessed failed: no subbasins shapefile')
            return False
        wshedFile = QSWATUtils.join(self._gv.projDir, wshedFile)
        wshedInfo = QFileInfo(wshedFile)
        wshedTime = wshedInfo.lastModified()
        wshedLayer, loaded = \
            QSWATUtils.getLayerByFilename(li.layers(), wshedFile, FileTypes._SUBBASINS, self._gv, True)
        if not wshedLayer:
            QSWATUtils.loginfo('demProcessed failed: no subbasins layer')
            return False
        if loaded: 
            li.moveLayer(wshedLayer, self._gv.watershedGroupIndex)
        self._gv.wshedFile = wshedFile
        extraOutletFile, found = proj.readEntry(title, 'delin/extraOutlets', '')
        if found and extraOutletFile != '':
            extraOutletFile = QSWATUtils.join(self._gv.projDir, extraOutletFile)
            extraOutletLayer, loaded = \
                QSWATUtils.getLayerByFilename(li.layers(), extraOutletFile, FileTypes._OUTLETS, self._gv, True)
            if not extraOutletLayer:
                QSWATUtils.loginfo('demProcessed failed: no extra outlet layer')
                return False
            if loaded: 
                li.moveLayer(outletLayer, self._gv.watershedGroupIndex)
        else:
            extraOutletLayer = None
        self._gv.extraOutletFile = extraOutletFile
        demInfo = QFileInfo(demFile)
        if not demInfo.exists():
            QSWATUtils.loginfo('demProcessed failed: no DEM info')
            return False
        base = QSWATUtils.join(demInfo.absolutePath(), demInfo.baseName())
        self._gv.basinFile = base + 'w.tif'
        if not os.path.exists(self._gv.basinFile):
            QSWATUtils.loginfo('demProcessed failed: no basins raster')
            return False
        self._gv.slopeFile = base + 'slp.tif'
        if not os.path.exists(self._gv.slopeFile):
            QSWATUtils.loginfo('demProcessed failed: no slope raster')
            return False
        self._gv.existingWshed = proj.readBoolEntry(title, 'delin/existingWshed', False)[0]
        if self._gv.existingWshed:
            winfo = QFileInfo(self._gv.basinFile)
            # cannot use last modified times because subbasin field in wshed file changed after wfile is created
            wCreateTime = winfo.created()
            wshedCreateTime = wshedInfo.created()
            if not wshedCreateTime <= wCreateTime:
                QSWATUtils.loginfo('demProcessed failed: wFile not up to date for existing watershed')
                return False
        else:
            self._gv.pFile = base + 'p.tif'
            if not os.path.exists(self._gv.pFile):
                QSWATUtils.loginfo('demProcessed failed: no p raster')
                return False
            felInfo = QFileInfo(base + 'fel.tif')
            if not (felInfo.exists() and wshedInfo.exists()):
                QSWATUtils.loginfo('demProcessed failed: no filled raster')
                return False
            demTime = demInfo.lastModified()
            felTime = felInfo.lastModified()
            if not (demTime <= felTime <= wshedTime):
                QSWATUtils.loginfo('demProcessed failed: not up to date')
                return False
            self._gv.distFile = base + 'dist.tif'
            if not os.path.exists(self._gv.distFile):
                QSWATUtils.loginfo('demProcessed failed: no distance to outlet raster')
        basinIndex = self._gv.topo.getIndex(wshedLayer, QSWATTopology._POLYGONID)
        for feature in wshedLayer.getFeatures():
            basin = feature.attributes()[basinIndex]
            centroid = feature.geometry().centroid().asPoint()
            centroidlatlong = self._gv.topo.pointToLatLong(centroid, wshedLayer.crs())
            self._gv.topo.basinCentroids[basin] = (centroidlatlong.x(), centroidlatlong.y())
        if not self._gv.topo.setUp0(demLayer, streamLayer, self._gv.verticalFactor):
            return False
        # this can go wrong if eg the streams and watershed files exist but are inconsistent
        try:
            if not self._gv.topo.setUp(demLayer, streamLayer, wshedLayer, outletLayer, extraOutletLayer, self._gv.db, self._gv.existingWshed, False, False):
                QSWATUtils.loginfo('demProcessed failed: topo setup failed')
                return False
            if not self._gv.topo.inletLinks:
                # no inlets, so no need to expand subbasins layer legend
                li.setLayerExpanded(wshedLayer, False)
        except Exception:
            QSWATUtils.loginfo('demProcessed failed: topo setup raised exception')
            return False
        return True
            
    def allowCreateHRU(self):
        """Mark delineation as Done and make create HRUs option visible."""
        QSWATUtils.progress('Done', self._odlg.delinLabel)
        QSWATUtils.progress('Step 2', self._odlg.hrusLabel)
        self._odlg.hrusLabel.setEnabled(True)
        self._odlg.hrusButton.setEnabled(True)
        self._odlg.editLabel.setEnabled(False)
        self._odlg.editButton.setEnabled(False)
            
    def setLegendGroups(self):
        """Legend groups are used to keep legend in reasonable order.  
        Create them if necessary.
        """
        li = self._iface.legendInterface()
        groups = li.groups()
        try:
            self._gv.resultsGroupIndex = groups.index(QAPEX._RESULTS_GROUP_NAME)
        except Exception:
            self._gv.resultsGroupIndex = li.addGroup(QAPEX._RESULTS_GROUP_NAME)
        try:
            self._gv.watershedGroupIndex = groups.index(QAPEX._WATERSHED_GROUP_NAME)
        except Exception:
            self._gv.watershedGroupIndex = li.addGroup(QAPEX._WATERSHED_GROUP_NAME)
        try:
            self._gv.landuseGroupIndex = groups.index(QAPEX._LANDUSE_GROUP_NAME)
        except Exception:
            self._gv.landuseGroupIndex = li.addGroup(QAPEX._LANDUSE_GROUP_NAME)
        try:
            self._gv.soilGroupIndex = groups.index(QAPEX._SOIL_GROUP_NAME)
        except Exception:
            self._gv.soilGroupIndex = li.addGroup(QAPEX._SOIL_GROUP_NAME)
        try:
            self._gv.slopeGroupIndex = groups.index(QAPEX._SLOPE_GROUP_NAME)
        except Exception:
            self._gv.slopeGroupIndex = li.addGroup(QAPEX._SLOPE_GROUP_NAME)

    def startEditor(self):
        """Start the SWAT Editor, first setting its initial parameters."""
        
        '''revise
        self._gv.setSWATEditorParams()
        subprocess.call(self._gv.SWATEditorPath)
        if os.path.exists(QSWATUtils.join(self._gv.tablesOutDir, Parameters._OUTPUTDB)):
            self._odlg.visualiseLabel.setVisible(True)
            self._odlg.visualiseButton.setVisible(True)
        '''

        #add
        edit = Edit(self._iface, self._gv)
        result = edit.run()
        self._odlg.visualiseLabel.setVisible(True)
        self._odlg.visualiseButton.setVisible(True)

    def visualise(self):
        """Run visualise form."""
        vis = Visualise(self._iface, self._gv)
        # vis = VisualOutput(self._iface, self._gv)
        vis.run()
      
