# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_outlets.ui'
#
# Created: Tue Jan 06 18:20:54 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_OutletsDialog(object):
    def setupUi(self, OutletsDialog):
        OutletsDialog.setObjectName(_fromUtf8("OutletsDialog"))
        OutletsDialog.resize(238, 279)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/plugins/qswat/QSWAT-Icon/QSWAT-Icon-SWAT-16.ico")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        OutletsDialog.setWindowIcon(icon)
        self.verticalLayout_2 = QtGui.QVBoxLayout(OutletsDialog)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.label = QtGui.QLabel(OutletsDialog)
        self.label.setWordWrap(True)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout_2.addWidget(self.label)
        self.widget = QtGui.QWidget(OutletsDialog)
        self.widget.setObjectName(_fromUtf8("widget"))
        self.verticalLayout = QtGui.QVBoxLayout(self.widget)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.outletButton = QtGui.QRadioButton(self.widget)
        self.outletButton.setChecked(True)
        self.outletButton.setAutoExclusive(True)
        self.outletButton.setObjectName(_fromUtf8("outletButton"))
        self.verticalLayout.addWidget(self.outletButton)
        self.reservoirButton = QtGui.QRadioButton(self.widget)
        self.reservoirButton.setObjectName(_fromUtf8("reservoirButton"))
        self.verticalLayout.addWidget(self.reservoirButton)
        self.inletButton = QtGui.QRadioButton(self.widget)
        self.inletButton.setObjectName(_fromUtf8("inletButton"))
        self.verticalLayout.addWidget(self.inletButton)
        self.ptsourceButton = QtGui.QRadioButton(self.widget)
        self.ptsourceButton.setObjectName(_fromUtf8("ptsourceButton"))
        self.verticalLayout.addWidget(self.ptsourceButton)
        self.verticalLayout_2.addWidget(self.widget)
        self.widget_2 = QtGui.QWidget(OutletsDialog)
        self.widget_2.setObjectName(_fromUtf8("widget_2"))
        self.resumeButton = QtGui.QPushButton(self.widget_2)
        self.resumeButton.setGeometry(QtCore.QRect(0, 10, 97, 23))
        self.resumeButton.setObjectName(_fromUtf8("resumeButton"))
        self.verticalLayout_2.addWidget(self.widget_2)
        self.buttonBox = QtGui.QDialogButtonBox(OutletsDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout_2.addWidget(self.buttonBox)

        self.retranslateUi(OutletsDialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), OutletsDialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), OutletsDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(OutletsDialog)

    def retranslateUi(self, OutletsDialog):
        OutletsDialog.setWindowTitle(QtGui.QApplication.translate("OutletsDialog", "Inlets/outlets", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("OutletsDialog", "Select type of point to add, then click on map to place it.  If you return to the map canvas to pan, zoom, etc click Resume adding to enable adding more points. Click OK to confirm and exit, Cancel to remove points and exit.", None, QtGui.QApplication.UnicodeUTF8))
        self.outletButton.setText(QtGui.QApplication.translate("OutletsDialog", "Outlet", None, QtGui.QApplication.UnicodeUTF8))
        self.reservoirButton.setText(QtGui.QApplication.translate("OutletsDialog", "Reservoir", None, QtGui.QApplication.UnicodeUTF8))
        self.inletButton.setText(QtGui.QApplication.translate("OutletsDialog", "Inlet", None, QtGui.QApplication.UnicodeUTF8))
        self.ptsourceButton.setText(QtGui.QApplication.translate("OutletsDialog", "Point source", None, QtGui.QApplication.UnicodeUTF8))
        self.resumeButton.setText(QtGui.QApplication.translate("OutletsDialog", "Resume adding", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
