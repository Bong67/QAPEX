# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_Parameters._ui'
#
# Created: Sat Jan 03 16:37:12 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_ParametersDialog(object):
    def setupUi(self, ParametersDialog):
        ParametersDialog.setObjectName(_fromUtf8("ParametersDialog"))
        ParametersDialog.resize(579, 171)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("QSWAT-Icon/QSWAT-Icon-SWAT-16.ico")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        ParametersDialog.setWindowIcon(icon)
        self.editorBox = QtGui.QLineEdit(ParametersDialog)
        self.editorBox.setGeometry(QtCore.QRect(20, 30, 471, 20))
        self.editorBox.setObjectName(_fromUtf8("editorBox"))
        self.editorButton = QtGui.QPushButton(ParametersDialog)
        self.editorButton.setGeometry(QtCore.QRect(490, 30, 75, 23))
        self.editorButton.setWhatsThis(_fromUtf8(""))
        self.editorButton.setObjectName(_fromUtf8("editorButton"))
        self.editorlLabel = QtGui.QLabel(ParametersDialog)
        self.editorlLabel.setGeometry(QtCore.QRect(20, 10, 141, 16))
        self.editorlLabel.setObjectName(_fromUtf8("editorlLabel"))
        self.MPIBox = QtGui.QLineEdit(ParametersDialog)
        self.MPIBox.setGeometry(QtCore.QRect(20, 100, 471, 20))
        self.MPIBox.setObjectName(_fromUtf8("MPIBox"))
        self.MPIButton = QtGui.QPushButton(ParametersDialog)
        self.MPIButton.setGeometry(QtCore.QRect(490, 100, 75, 23))
        self.MPIButton.setWhatsThis(_fromUtf8(""))
        self.MPIButton.setObjectName(_fromUtf8("MPIButton"))
        self.checkUseMPI = QtGui.QCheckBox(ParametersDialog)
        self.checkUseMPI.setGeometry(QtCore.QRect(20, 60, 121, 17))
        self.checkUseMPI.setWhatsThis(_fromUtf8(""))
        self.checkUseMPI.setObjectName(_fromUtf8("checkUseMPI"))
        self.MPILabel = QtGui.QLabel(ParametersDialog)
        self.MPILabel.setGeometry(QtCore.QRect(20, 80, 121, 16))
        self.MPILabel.setObjectName(_fromUtf8("MPILabel"))
        self.cancelButton = QtGui.QPushButton(ParametersDialog)
        self.cancelButton.setGeometry(QtCore.QRect(490, 140, 75, 23))
        self.cancelButton.setObjectName(_fromUtf8("cancelButton"))
        self.saveButton = QtGui.QPushButton(ParametersDialog)
        self.saveButton.setGeometry(QtCore.QRect(400, 140, 75, 23))
        self.saveButton.setObjectName(_fromUtf8("saveButton"))

        self.retranslateUi(ParametersDialog)
        QtCore.QMetaObject.connectSlotsByName(ParametersDialog)

    def retranslateUi(self, ParametersDialog):
        ParametersDialog.setWindowTitle(QtGui.QApplication.translate("ParametersDialog", "QSWAT Parameters", None, QtGui.QApplication.UnicodeUTF8))
        self.editorButton.setToolTip(QtGui.QApplication.translate("ParametersDialog", "Browse to select SWAT editor directory", None, QtGui.QApplication.UnicodeUTF8))
        self.editorButton.setText(QtGui.QApplication.translate("ParametersDialog", ". . .", None, QtGui.QApplication.UnicodeUTF8))
        self.editorlLabel.setToolTip(QtGui.QApplication.translate("ParametersDialog", "This is the directory where the SWAT Editor is located.  On Windows it is usually C:\\SWAT\\SWATEditor.", None, QtGui.QApplication.UnicodeUTF8))
        self.editorlLabel.setText(QtGui.QApplication.translate("ParametersDialog", "SWAT editor directory", None, QtGui.QApplication.UnicodeUTF8))
        self.MPIButton.setToolTip(QtGui.QApplication.translate("ParametersDialog", "Browse to select MPI bin directory", None, QtGui.QApplication.UnicodeUTF8))
        self.MPIButton.setText(QtGui.QApplication.translate("ParametersDialog", ". . .", None, QtGui.QApplication.UnicodeUTF8))
        self.checkUseMPI.setToolTip(QtGui.QApplication.translate("ParametersDialog", "If you have a multi-core processor then using the Message Passing Interface (MPI) can speed up the TauDEM programs used for watershed delineation.  If you install MP you should set this directory to where the mpiexec program is located.  On Windows this is probably C:\\Program Files\\Microsoft MPI\\Bin.", None, QtGui.QApplication.UnicodeUTF8))
        self.checkUseMPI.setText(QtGui.QApplication.translate("ParametersDialog", "Use MPI", None, QtGui.QApplication.UnicodeUTF8))
        self.MPILabel.setToolTip(QtGui.QApplication.translate("ParametersDialog", "If you have a multi-core processor then using the Message Passing Interface (MPI) can speed up the TauDEM programs used for watershed delineation.  If you install MP you should set this directory to where the mpiexec program is located.  On Windows this is probably C:\\Program Files\\Microsoft MPI\\Bin.", None, QtGui.QApplication.UnicodeUTF8))
        self.MPILabel.setText(QtGui.QApplication.translate("ParametersDialog", "MPI bin directory", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelButton.setText(QtGui.QApplication.translate("ParametersDialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))
        self.saveButton.setText(QtGui.QApplication.translate("ParametersDialog", "Save", None, QtGui.QApplication.UnicodeUTF8))

