# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_selectlu.ui'
#
# Created: Mon Jan 19 16:25:19 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_SelectluDialog(object):
    def setupUi(self, SelectluDialog):
        SelectluDialog.setObjectName(_fromUtf8("SelectluDialog"))
        SelectluDialog.resize(339, 554)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/plugins/qswat/QSWAT-Icon/QSWAT-Icon-SWAT-16.ico")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        SelectluDialog.setWindowIcon(icon)
        self.gridLayout = QtGui.QGridLayout(SelectluDialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.listBox = QtGui.QListWidget(SelectluDialog)
        self.listBox.setObjectName(_fromUtf8("listBox"))
        self.gridLayout.addWidget(self.listBox, 0, 0, 1, 1)
        self.buttonBox = QtGui.QDialogButtonBox(SelectluDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.gridLayout.addWidget(self.buttonBox, 1, 0, 1, 1)

        self.retranslateUi(SelectluDialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), SelectluDialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), SelectluDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(SelectluDialog)

    def retranslateUi(self, SelectluDialog):
        SelectluDialog.setWindowTitle(QtGui.QApplication.translate("SelectluDialog", "Select sub-landuse", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
