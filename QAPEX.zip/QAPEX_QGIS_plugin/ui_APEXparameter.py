# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'APEXparameter_ui(0523).ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_APEXParameterDialog(object):
    def setupUi(self, APEXParameterDialog):
        APEXParameterDialog.setObjectName(_fromUtf8("APEXParameterDialog"))
        APEXParameterDialog.resize(136, 151)
        self.SUB_push = QtGui.QPushButton(APEXParameterDialog)
        self.SUB_push.setGeometry(QtCore.QRect(10, 30, 111, 31))
        self.SUB_push.setObjectName(_fromUtf8("SUB_push"))
        self.Parameter_label = QtGui.QLabel(APEXParameterDialog)
        self.Parameter_label.setGeometry(QtCore.QRect(10, 10, 71, 21))
        self.Parameter_label.setObjectName(_fromUtf8("Parameter_label"))
        self.BMP_push = QtGui.QPushButton(APEXParameterDialog)
        self.BMP_push.setGeometry(QtCore.QRect(10, 70, 111, 31))
        self.BMP_push.setObjectName(_fromUtf8("BMP_push"))
        self.Okay_push = QtGui.QPushButton(APEXParameterDialog)
        self.Okay_push.setGeometry(QtCore.QRect(10, 110, 51, 31))
        self.Okay_push.setObjectName(_fromUtf8("Okay_push"))
        self.Cancel_push = QtGui.QPushButton(APEXParameterDialog)
        self.Cancel_push.setGeometry(QtCore.QRect(70, 110, 51, 31))
        self.Cancel_push.setObjectName(_fromUtf8("Cancel_push"))

        self.retranslateUi(APEXParameterDialog)
        QtCore.QMetaObject.connectSlotsByName(APEXParameterDialog)

    def retranslateUi(self, APEXParameterDialog):
        APEXParameterDialog.setWindowTitle(QtGui.QApplication.translate("APEXParameterDialog", "Parameters", None, QtGui.QApplication.UnicodeUTF8))
        self.SUB_push.setText(QtGui.QApplication.translate("APEXParameterDialog", "FILENAME.SUB", None, QtGui.QApplication.UnicodeUTF8))
        self.Parameter_label.setText(QtGui.QApplication.translate("APEXParameterDialog", "Parameters", None, QtGui.QApplication.UnicodeUTF8))
        self.BMP_push.setText(QtGui.QApplication.translate("APEXParameterDialog", "BMPs", None, QtGui.QApplication.UnicodeUTF8))
        self.Okay_push.setText(QtGui.QApplication.translate("APEXParameterDialog", "Ok", None, QtGui.QApplication.UnicodeUTF8))
        self.Cancel_push.setText(QtGui.QApplication.translate("APEXParameterDialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))

