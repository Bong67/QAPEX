# -*- coding: utf-8 -*-

class Term_Dict:
    def __init__(self):
        
        self._Des_dict = {"SNUM":"Subarea ID number",  #SUB
                          "TITLE":"Description of the subarea",
                          "INPS":"Soil number from soil list",
                          "IOPS":"Operation schedule from operation schedule list",
                          "IOW":"Owner ID",
                          "II":"Feeding area",
                          "IAPL":"Manure application area",
                          "NVCN":"""CN-CN2 code
0 Variable daily CN nonlinear CN/SW with depth soil water weighting
1 Variable daily CN nonlinear CN/SW without depth weighting
2 Variable daily CN linear CN/SW no depth weighting
3 Non-varying CN – CN2 used for all storms
4 Variable daily CN SMI (soil moisture index)""",
                          "WITH":"Input daily weather station number",
                          "IPTS":"Point source number",
                          "ISAO":"Outflow release method(Range: 0-10000)",
                          "LUNS":"Land use Number",
                          "IMW":"Minimum Interval between Auto Mow",
                          "SNO":"Water content of snow on ground at start of simulation",
                          "STDO":"Standing dead crop residue",
                          "YCT":"Y Coordinate(Latitude) of subarea centroid",
                          "XCT":"X Coordinate(Longitude) of subarea centroid",
                          "AZM":"Azimuth Orientation of Land Slope(degrees clockwise from North)",
                          "FL":"Field Length(if wind erosion is to be considered) in kilometers",
                          "FW":"Field Width(if wind erosion is to be considered) in kilometers",
                          "ANGL":"Clockwise Angle of Field Length from North(if wind erosion is to be considered)",
                          "WSA":"Watershed(drainage) area",
                          "CHL":"""Distance from outlet to most distant point os watershed(Channel length)(If unknown, enter 0.)
The channel length is the distance along the channel from the outlet to the most
distant point on the watershed. Often in small areas (approx. 1 ha) there is no
defined channel. In such cases the length is measured along a concentrated flow
path or it can simply be estimated from the length-width ratio of the watershed.
For areas ≤ 20 ha, the channel length measurement is not critical. In such cases,
enter 0. Units are kilometers (metric) or miles (English). If this is an
EXTREME subarea then Channel Length of Routing Reach MUST EQUAL
Distance from Outlet. If this is a DOWNSTREAM subarea then Channel
Length of Routing Reach can NOT BE EQUAL to Distance from Outlet.""",
                          "CHD":"Channel depth(If unknown, enter 0.)",
                          "CHS":"Mainstream channel slope(If unknown, enter 0.)",
                          "CHN":"Manning's N for channel(If unknown, enter 0.)",
                          "SLP":"Average Uplang Slope",
                          "SPLG":"Average Upland Slope Length",
                          "UPN":"Manning's N for Upland",
                          "FFPQ":"Fraction of floodplain flow(Range: 0-1)",
                          "URBF":"Fraction of Subarea which is Urban(Range: 0-1)",
                          "RCHL":"""Channel Length of Routing Reach
The length (distance) in km between where channel starts or enters the subarea
and leaves the subarea. If this is an EXTREME subarea, then Routing Reach
Length MUST EQUAL Longest Distance from Outlet (CHL). If this is a
DOWNSTREAM subarea, then Routing Reach Length can not be equal to
Longest Distance from Outlet.""",
                          "RCHD":"Channel Depth of Routing Reach(If unknown, enter 0.)",
                          "RCBW":"Botton Width of Channel of Routing Reach(If unknown, enter 0.)",
                          "RCTW":"Top Width of Channel of Routing Reach(If unknown, enter 0.)",
                          "RCHS":"Channel Slope of Routing Reach(If unknown, enter 0.)",
                          "RCHN":"Channel Manning's N of Routing Reach(If unknown, enter 0.)",
                          "RCHC":"USLE Crop Management Channel (C) Factor(Range is 0.0001 - 0.6)",
                          "RCHK":"USLE Erodibility Channel (K) Factor(Range is 0.0001 - 0.5)",
                          "RFPW":"Reach Floodplain width(If unknown, enter 0.)",
                          "RFPL":"Floodplain length(If unknown, enter 0.)",
                          "RSEE":"Elevation at emergency spillway(meters)",
                          "RSAE":"Total reservoir surface area at emergency spillway elevation (RSEE) in ha",
                          "RSVE":"Runoff volume from reservoir catchment area at emergency spillway elevation in mm.",
                          "RSEP":"Elevation at principal spillway (meters)",
                          "RSAP":"Total reservoir surface area at principal spillway elevation (RSEP) in ha.",
                          "RSVP":"Volume at principal spillway elevation in mm.",
                          "RSV":"Initial reservoir volumes in mm.",
                          "RSRR":"Average principal spillway release rate in days.",
                          "RSYS":"Initial sediment concentration in reservoirs in ppm.",
                          "RSYN":"Normal sediment concentration in reservoirs in ppm.",
                          "RSHC":"Hydraulic conductivity of reservoir bottoms in mm/h.",
                          "RSDP":"Time for Sediment Concentrations to Return to Normal",
                          "RSBD":"Bulk density of sediment in reservoir (t/m3)",
                          "PCOF":"Fraction of subarea controlled by ponds",
                          "BCOF":"Fraction of the Subarea controlled by Buffers",
                          "BFFL":"Buffer Flow Length (m)",
                          "NIRR":"Rigidity of Irrigation Code (Range: 0-1)",
                          "IRR":"""Irrigation Code (Range: 0-5)
0 for dryland
1 for sprinkler irrigation
2 for furrow/flood irrigation
3 for fertigation (irrigation with fertilizer added)
4 for lagoon (irrigation from a lagoon)
5 for drip irrigation""",
                          "IRI":"Minimum application interval for automatic irrigation",
                          "IFA":"Minimum fertilizer application interval for auto option",
                          "LM":"""Liming Code
0 Lime applied automatically as needed to prevent acidification of the soil
1 No lime applied.""",
                          "IFD":"""Furrow Dike Code
0 Furrow dike system not simulated
1 Furrow dike system simulated""",
                          "IDR":"""Drainage code
0 No drainage
>0 Enter depth to drainage system in mm.""",
                          "IDF1":"Fertigation Fertilizer from Lagoon.",
                          "IDF2":"Automatic Solid Manure Application from Feeding Area Stock Pile.",
                          "IDF3":"Automatic Commercial Phosphorus Fertilizer Application",
                          "IDF4":"Automatic Commercial Fertilizer Application.",
                          "IDF5":"Automatic Solid Manure Application",
                          "BIR":"""Water stress factor to trigger automatic irrigation.
To trigger automatic irrigation, the water stress factor is set:
0 manual irrigation
0 – 1.0 Plant water stress factor. (1 – BIR) equals the fraction of plant water stress allowed 1.0 Does not allow water stress
< 0.0 Plant available water deficit in root zone (number is in mm and must be negative)
> 1.0 Soil water tension in top 200mm (Absolute number is in kilopascals)
-1000 Sets water deficit high enough that only manual irrigations""",
                          "EFI":"Runoff Vol/Vol Irrigation Water Applied(Range: 0-1).",
                          "VIMX":"Maximum annual irrigation volume",
                          "ARMN":"Minimum single application volume",
                          "ARMX":"Maximum single application volume",
                          "BFT":"""N stress factor to trigger auto fertilization.
The automatic fertilizer trigger functions much like BIR for irrigation. When the plant nitrogen stress level reaches BFT, nitrogen fertilizer may be applied automatically.
If this value is greater than 0, IDFT must be the Number of the Fertilizer application.
0.00 For manual fertilizer
0 – 1 Allows percentage of plant nitrogen stress (1 – BFT) equals the fraction of N stress allowed.
1.00 No N stress, auto-fertilization when needed.
>1 If BFT is greater than 1, BFT is the PPM(g/t) N in soil at which automatic fertilizer is triggered""",
                          "FNP4":"Auto Fertilization Application Rate (N)",
                          "FMX":"Maximum annual N fertilizer applied",
                          "DRT":"Time requirement for drainage system to end plant stress in days.",
                          "FDSF":"Furrow Dike Safety Factor",
                          "PEC":"Erosion control practice factor.",
                          "DALG":"Fraction of Subarea controlled by lagoon.",
                          "VLGN":"Lagoon Volume Ratio",
                          "COWW":"Lagoon Input From Wash Water",
                          "DDLG":"Time to Reduce Lagoon Storage From Maximum to Normal",
                          "SOLQ":"Ratio Liquid/Total Manure Produced in this Feedlot Subarea.",
                          "SFLG":"Safety factor for lagoon design",
                          "FNP2":"Feeding Area Stock Pile Auto Solid Manure Application Rate",
                          "FNP5":"Automatic Manure application rate",
                          "FIRG":"Factor to Adjust Automatic Irrigation Volume",
                          "NY1":"Herd(s) Eligible for Grazing this Crop",
                          "NY2":"Herd(s) Eligible for Grazing this Crop",
                          "NY3":"Herd(s) Eligible for Grazing this Crop",
                          "NY4":"Herd(s) Eligible for Grazing this Crop",
                          "NY5":"Herd(s) Eligible for Grazing this Crop",
                          "NY6":"Herd(s) Eligible for Grazing this Crop",
                          "NY7":"Herd(s) Eligible for Grazing this Crop",
                          "NY8":"Herd(s) Eligible for Grazing this Crop",
                          "NY9":"Herd(s) Eligible for Grazing this Crop",
                          "NY10":"Herd(s) Eligible for Grazing this Crop",
                          "NY":"Herd(s) Eligible for Grazing this Crop",
                          "XTP":"Grazing limit for each herd",
                          "XTP1":"Grazing limit for each herd",
                          "XTP2":"Grazing limit for each herd",
                          "XTP3":"Grazing limit for each herd",
                          "XTP4":"Grazing limit for each herd",
                          "XTP5":"Grazing limit for each herd",
                          "XTP6":"Grazing limit for each herd",
                          "XTP7":"Grazing limit for each herd",
                          "XTP8":"Grazing limit for each herd",
                          "XTP9":"Grazing limit for each herd",
                          "XTP10":"Grazing limit for each herd",
                          #CONT
                          "NBYR":"Number of Years for Simulation Duration(cols. 1-4)",
                          "IYR":"Beginning Year of Simulation (cols. 5-8)",
                          "IMO":"Beginning Month of Simulation (cols. 9-12)",
                          "IDA":"Beginning Day of Simulation (cols. 13-16)",
                          "IPD":"Print Code for Type of Output (cols. 17-20)",
                          "NGN":"Input Code for Weather Variables (cols. 21-24)",
                          "IGN":"Number of Times Random Number Generator Cycles Before Simulations Starts (cols. 25-28)",
                          "IGSD":"Day Weather Generator Stops Generating Daily Weather (cols. 29-32)",
                          "LPYR":"Leap Year Considered (cols. 33-36) (Range: 0-1)",
                          "IET":"Potential Evapotranspiration Equation Code (cols. 37-40)",
                          "ISCN":"Stochastic CN Estimator Code (cols. 41-44)",
                          "ITYP":"Peak Rate Estimate Code (cols. 45-48)",
                          "ISTA":"Static Soil Code (cols. 49-52)",
                          "IHUS":"Automatic Heat Unit Scheduling (cols. 53-56)",
                          "NVCN":"Non-varying CN-CN2 Used (cols. 57-60) (Range: 0-4)",
                          "INFL":"Runoff (Q) Estimation Methodology (cols. 61-64) (Range: 0-4)",
                          "MASP":"Pesticide Output in Mass and Concentration (cols. 65-68) (Range: 0-1)",
                          "IERT":"Enrichment Ratio Method (cols. 69-72)",
                          "LBP":"Soluble Phosphorus Runoff Estimate Equation (cols. 73-76) (Range: 0-2)",
                          "NUPC":"N and P plant uptake concentration code (cols. 77-80) (Range: 0-1)",
                          "MNUL":"Manure application code (cols. 1-4) (Range: 0-3)",
                          "LPD":"Lagoon pumping (cols. 5-8) (Range: 0-365)",
                          "MSCP":"Solid manure scraping (cols. 9-12) (Range: 0-365)",
                          "ISLF":"Slope length/steepness factor (cols. 13-16) (Range: 0-1)",
                          "NAQ":"Air Quality Analysis (cols. 17-20) (Range: 0-1)",
                          "IHY":"Flood Routing (cols. 21-24) (Range: 0-2)",
                          "ICO2":"Atmospheric CO2 (cols. 25-28) (Range: 0-2)",
                          "ISW":"Field Capacity/Wilting Point Estimation (cols. 29-32) (Range: 0-5)",
                          "IGMX":"Number of times generator seeds are initialized for a site (cols. 33-36)(Range: 1-100)",
                          "IDIR":"Data Directory (cols.37-40) (Range: 0-1)",
                          "IMW":"Minimum Interval between auto mow (cols.41-44)",
                          "IOX":"O2 – depth function (cols. 45-48) (Range: 0-1)",
                          "IDNT":"Denitrification subprogram (cols. 49-52) (Range: 0-1)",
                          "IAZM":"Latitude source (cols. 53-56) (Range: 0-1)",
                          "IPAT":"Auto-Phosphorus Switch (cols. 57-60) (Range: 0-1)",
                          "IHRD":"Grazing Mode (cols. 61-64) (Range: 0-2)",
                          "IWTB":"Duration of antecedent period for rainfall and PET accumulation to drive water table. (cols. 65-68)",
                          "NSTP":"Real time day of year (cols. 69-72) (Range: 0-365)",
                          "ISAP":"Enter subarea number (NBSA) to print monthly .OUT for 1 subarea (cols. 73-76) (Range: 1-1000)",
                          "RFN":"Average concentration of nitrogen in rainfall (cols. 1-8)",
                          "CO2":"Carbon dioxide concentration in atmosphere (cols. 9-16)",
                          "CQN":"Concentration of NO3-N in irrigation water in ppm (cols. 17-24) (Range: 0-1000)",
                          "PSTX":"Pest damage scaling factor (cols. 25-32) (Range: 0-10)",
                          "YWI":"Number years of maximum monthly 0.5 hour rainfall available. (cols. 33-40)",
                          "BTA":"COEF (0-1) governing wet-dry probabilities given days of rain. (cols. 41-48)",
                          "EXPK":"Parameter used to modify exponential rainfall amount distribution (cols. 49-56)",
                          "QG":"Channel Capacity Flow Rate (cols. 57-64)",
                          "QCF":"Exponent in watershed area flow rate equation. (cols. 65-72) (Range: 0.4-0.6)",
                          "CHSO":"Average upland slope (m/m) in watershed (cols. 73-80) (Range: 0.001-0.7)",
                          "BWD":"Channel bottom width/depth in m/m; Channel flow rate (QG) > 0. (cols. 1-8) (Range: 1-20)",
                          "FCW":"Floodplain width/channel width in m/m (cols. 9-16) (Range: 2-50)",
                          "FPSC":"Floodplain saturated hydraulic conductivity in mm/h (cols. 17-24)(Range: 0.0001-10)",
                          "GWSO":"Maximum ground water storage in mm (cols. 25-32) (Range: 5-200)",
                          "RFTO":"Ground water residence time in days (cols. 33-40) (Range: 0-365)",
                          "RFPO":"Return Flow / (Return Flow + Deep Percolation) (cols. 41-48) (Range: 0-1)",
                          "SATO":"Saturated Conductivity adjustment factor (cols. 49-56)",
                          "FL":"Field length (if wind erosion is to be considered) in kilometers(cols. 57-64)",
                          "FW":"Field width (if wind erosion is to be considered) in kilometers (cols. 65-72)",
                          "ANG":"Clockwise angle of field length from north (if wind erosion is to be considered) (cols. 73-80)",
                          "UXP":"Power Parameter of Modified Exponential Distribution of Wind Speed (if wind erosion is to be considered) (cols. 1-8)",
                          "DIAM":"Soil Particle Diameter(if wind erosion is to be considered) (cols. 9-16)",
                          "ACW":"Wind Erosion Adjustment Factor (cols. 17-24)",
                          "GZL0":"Grazing limit (cols. 25-32)",
                          "RTN0":"Number of years of cultivation at start of simulation (cols. 33-40)",
                          "BXCT":"Linear coefficient of change in rainfall from east to west (PI/PO/KM) (cols. 41-48) (Range: 0-1)",
                          "BYCT":"Linear coefficient of change in rainfall from south to north (PI/PO/KM) (cols. 49-56) (Range: 0-1)",
                          "DTHY":"Time interval for flood routing (hours) (cols. 57-64) (Range: 0.5-12)",
                          "QTH":"Routing Threshold (mm) – VSC routing used when QVOL>QTH (cols. 65-72) (Range: 0-200000)",
                          "STND":"VSC Routing used when reach storage > STND (cols. 73-80) (Range: 0-200000)",
                          "DRV":"Equation for Water Erosion (cols. 1-8) (Range: 0-7)",
                          "PCO0":"Fraction of subareas controlled by ponds (cols. 9-16) (Range: 0-1)",
                          "RCC0":"USLE Crop Management Channel Factor (cols. 17-24)",
                          "CSLT":"Salt Concentration in Irrigation Water (cols. 25-32) ppm",
                          "BUS":"""First through Fourth Parameter Estimates for MUSI Erosion Equation
YSD(6) = BUS(1) x QVOLBUS(2) x QRBBUS(3) x WSABUS(4) x KCPLS""",
                          "BUS1":"MUSI input according to equation above (cols. 33-40) (Range: 0-10)",
                          "BUS2":"MUSI input according to equation above (cols. 41-48) (Range: 0-0.9)",
                          "BUS3":"MUSI input according to equation above (cols. 49-56) (Range: 0-0.9)",
                          "BUS4":"MUSI input according to equation above (cols. 57-64) (Range: 0-1.2)",
                          #BMP
                          "Check Dam":"Check dams are small, temporary dams constructed across a swale or channel. They can be constructed using gravel, straw bales, sand bags or fiber rolls. They are used to reduce the velocity of concertrated flow and, therefore, to reduce the erosion in a swale or channel. Check dams should be used when itis not feasible or practical to line the channel or implement permanent flow control practices. Check dams are usually installed such that the crest of a dam is level with the toe of the next check dam(if any) upslope.",
                          "Diversion Dike":"A barrier constructed of earth or manufactured materials. To protect people and property from floods and to control water level in connection with crop production; fish and wildlife management; or wetland maintenance, improvement, restoration, or construction. Diversion dikes can work to control the flow and velocity of stromwater.",
                          "Filter Strips":"Filter strips are vegetated areas that are situated between surface water bodies(i.e. streams and lakes) and cropland, grazing land, foresland, or disturbed land. They are generally in locations when runoff water leaves a field with the intention that sediment, organic material, nutrients, and chemicals can be filtered from the runoff water. Filter strips are also known as vegetative filter or buffer strips. Strips slow runoff water leaving a field so that larger particles, including soil and organic material can settle out. Due to entrapment of sediment and the establishment of vegetation, nutrients can be absorbed nto the sediment that is deposited and remain on the field landscape, enabling plant uptake.",
                          "Grade Stabilization Structure":"Grade stabilization is a practice that involves the strategic intallation of a structure made of earth, rock, concrete, or steel into a slope adjacent to a reservoir or tributary stream. Grade stabilization is designed to prevent the erosion of channel or reservoir embankments and thus prevent sedimentation and a degradation of water quality.",
                          "Grassed Waterway":"Grassed waterways are natural or constructed channels established for the transport of concentrated flow at safe velocities using adequate vegetation. The vegetative cover slows the water flow, minimizing channel surface erosion. This BMP can reduce sedimentation of nearby water bodies and pollutants in runoff. The vegetation improves the soil aeration and water quality due to its nutrient removal through plant uptake and sorption by the soil. Entrapment of sediment and the establishment of vegetation allow nutrients to be absorbed into trapped sediments to remain in the agricultural field rather than being deposited into waterways",
                          "Interceptor Swale":"An inceptor swale or rain garden is an open, vegetated channel that collects and diverts the flow of storm water to a desired location. Swales are an aesthetically pleasing variation on a drainage ditch and are enhanced with native vegetation and landscape features to slow and filter storm water. This practice is most typically used in an urban or suburban setting.",
                          "Rain Garden":"An inceptor swale or rain garden is an open, vegetated channel that collects and diverts the flow of storm water to a desired location. Swales are an aesthetically pleasing variation on a drainage ditch and are enhanced with native vegetation and landscape features to slow and filter storm water. This practice is most typically used in an urban or suburban setting.",
                          "Interceptor Swale/Rain Garden":"An inceptor swale or rain garden is an open, vegetated channel that collects and diverts the flow of storm water to a desired location. Swales are an aesthetically pleasing variation on a drainage ditch and are enhanced with native vegetation and landscape features to slow and filter storm water. This practice is most typically used in an urban or suburban setting.",
                          "Pipe Slope Drain":"A pipe slope drain is a device used to carry concentrated runoff from the top to the bottom of a slope that has already been damaged by erosion or is at high risk for erosion. It may be used to convey runoff from off-site around a disturbed portion of the site. It may also be used to drain saturated slopes that have the potential for soil slides. Pope slope drains can either be temporary or permanent dependant on the method of installation and materials used.",
                          "Sediment Basin":"A basin constructed to collect and store debris or sediment. Sediment basins are installed to preserve the capacity of reservoirs, wetlands, ditches, canals, diversion, waterways, and streams. This practice also prevents undesirable deposition on bottom lands and developed areas. The practice works to trap sediment originating from construction sites or other disturbed areas. Sediment basins also work to reduce or abate pollution by providing basins for deposition and storage of silt, sand, gravel, stone, agricultural waste solids, and other detritus.",
                          "Silt Fence":"A sediment fence is a temporary barrier consisting of synthetic fiber that is stretched across and attached to supporting posts. Sediment fences are designed to limit the flow of silt and sediment from construction sites in which the soil is disturbed. Fences are often part of a compliment of best management practices designed for construction sites to work in concert as part of a Storm Water Prevention and Protection Plan as mandated by the Texas Commission on Environmental Quality.",
                          "Terraces":"An earth embankment, or a combination ridge and channel, constructed across the field slope. This practice is applied as part of a resource management system designed to reduce erosion by reducing slope length and retaining runoff for moisture conservation. This practis applies where soil erosion caused by water and excessive slope length is a problem, excess runoff is a problem and there is a need to conserve water. Terracing requires that the soils and topography are such that terraces can be constructed and reasonably farmed and suitable outlet can be provided.",
                          "Triangular Sediment Dike":"The purpose of a triangular sediment filter dike is to intercept and detain water-borne sediment from unprotected areas of limited extent. The triangular sediment filter dike is used where there is no concentration of water in a channel or other drainage way above the barrier and the contributing drainage area is less than one acre. This measure is effective on paved areas where installation of silt fence is not possible or where vehicle access must be maintained. The advantage of these controls is the ease with which they can be moved to allow vehicle traffic and then reinstalled to maintain sediment.",
                          "Wetland Creation":"Constructed wetlands provide a sediment retention and nutrient removal system that uses natural chemical, physical, and biological processes involving wetland vegetation, soils, and their associated microbial populations to improve water quality. Constructed wetlands are designed to use water quality improvement processes occurring in natural wetlands, including high primary productivity, low flow conditions, and oxygen treatment to anaerobic sediment. Nutrient retention in wetlands systems occurs via sorption, precipitation, and incorporation."
                          }
                          
