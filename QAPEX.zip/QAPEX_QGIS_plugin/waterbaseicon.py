# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_hrus.ui'
#
# Created: Thu Aug 07 13:44:09 2014
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Icon:
    
    """Method for obtaining WaterBase icon."""
    
    @staticmethod
    def getIcon():
        """Return the WaterBase icon."""
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/plugins/qswat/icon_without_map.ico")), \
                       QtGui.QIcon.Normal, QtGui.QIcon.Off)
        return icon
