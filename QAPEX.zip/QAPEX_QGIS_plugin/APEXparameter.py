# -*- coding: utf-8 -*-

# Import the PyQt and QGIS libraries
from PyQt4.QtCore import * # @UnusedWildImport
from PyQt4.QtGui import * # @UnusedWildImport
from qgis.core import * # @UnusedWildImport
# Import the code for the dialog
from APEXparameterdialog import APEXParameterDialog
from SUBparameter import SUBParameter
from BMPparameter import BMPParameter



class APEXParameter(QObject):

    def __init__(self, iface, gv):
        QObject.__init__(self)
        self._iface = iface
        self._gv = gv
        self._dlg = APEXParameterDialog()
        self._dlg.setWindowFlags(self._dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint)

    def init(self):
        """Set connections to controls."""
        settings = QSettings()
        self._dlg.SUB_push.clicked.connect(self.SUB_parameter)
        self._dlg.BMP_push.clicked.connect(self.BMP_parameter)
        self._dlg.Okay_push.clicked.connect(self.doClose)
        self._dlg.Cancel_push.clicked.connect(self.doClose)
        
    def run(self):
        self.init()
        self._dlg.show()
        result = self._dlg.exec_()  # @UnusedVariable
        self._gv.delineatePos = self._dlg.pos()
        self._gv.writeMasterProgress(0,0)
        return 0

    def doClose(self):
        """Close form."""
        self._dlg.close()

    def SUB_parameter(self):
        APEX_SUB = SUBParameter(self._iface, self._gv)
        APEX_SUB.run()
        self._dlg.close()
        return

    def BMP_parameter(self):
        APEX_BMP = BMPParameter(self._iface, self._gv)
        APEX_BMP.run()
        self._dlg.close()
        return
 

