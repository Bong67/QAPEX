# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_elevationbands.ui'
#
# Created: Sat Jan 03 16:37:12 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_ElevatioBandsDialog(object):
    def setupUi(self, ElevatioBandsDialog):
        ElevatioBandsDialog.setObjectName(_fromUtf8("ElevatioBandsDialog"))
        ElevatioBandsDialog.resize(215, 185)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("QSWAT-Icon/QSWAT-Icon-SWAT-16.ico")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        ElevatioBandsDialog.setWindowIcon(icon)
        self.groupBox = QtGui.QGroupBox(ElevatioBandsDialog)
        self.groupBox.setGeometry(QtCore.QRect(20, 10, 171, 131))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.elevBandsThreshold = QtGui.QLineEdit(self.groupBox)
        self.elevBandsThreshold.setGeometry(QtCore.QRect(50, 50, 61, 20))
        self.elevBandsThreshold.setInputMethodHints(QtCore.Qt.ImhPreferNumbers)
        self.elevBandsThreshold.setObjectName(_fromUtf8("elevBandsThreshold"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setGeometry(QtCore.QRect(20, 30, 161, 16))
        self.label.setObjectName(_fromUtf8("label"))
        self.numElevBands = QtGui.QSpinBox(self.groupBox)
        self.numElevBands.setGeometry(QtCore.QRect(60, 100, 42, 22))
        self.numElevBands.setMinimum(2)
        self.numElevBands.setMaximum(10)
        self.numElevBands.setObjectName(_fromUtf8("numElevBands"))
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(30, 80, 136, 16))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.cancelButton = QtGui.QPushButton(ElevatioBandsDialog)
        self.cancelButton.setGeometry(QtCore.QRect(110, 150, 75, 23))
        self.cancelButton.setObjectName(_fromUtf8("cancelButton"))
        self.okButton = QtGui.QPushButton(ElevatioBandsDialog)
        self.okButton.setGeometry(QtCore.QRect(20, 150, 75, 23))
        self.okButton.setObjectName(_fromUtf8("okButton"))

        self.retranslateUi(ElevatioBandsDialog)
        QtCore.QMetaObject.connectSlotsByName(ElevatioBandsDialog)

    def retranslateUi(self, ElevatioBandsDialog):
        ElevatioBandsDialog.setWindowTitle(QtGui.QApplication.translate("ElevatioBandsDialog", "Elevation Bands", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("ElevatioBandsDialog", "Elevation bands settings", None, QtGui.QApplication.UnicodeUTF8))
        self.elevBandsThreshold.setToolTip(QtGui.QApplication.translate("ElevatioBandsDialog", "Elevation bands will be provided for subbasins whose maximum height exceeds this threshold.", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("ElevatioBandsDialog", "Threshold elevation (metres)", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("ElevatioBandsDialog", "Number of bands (2 - 10)", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelButton.setText(QtGui.QApplication.translate("ElevatioBandsDialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))
        self.okButton.setText(QtGui.QApplication.translate("ElevatioBandsDialog", "OK", None, QtGui.QApplication.UnicodeUTF8))

