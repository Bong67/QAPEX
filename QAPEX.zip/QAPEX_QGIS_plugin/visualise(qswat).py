# -*- coding: utf-8 -*-
'''
/***************************************************************************
 QSWAT
                                 A QGIS plugin
 Create SWAT inputs
                              -------------------
        begin                : 2014-07-18
        copyright            : (C) 2014 by Chris George
        email                : cgeorge@mcmaster.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
'''
# Import the PyQt and QGIS libraries
from PyQt4.QtCore import *  # @UnusedWildImport
from PyQt4.QtGui import *  # @UnusedWildImport
from qgis.core import * # @UnusedWildImport
from qgis.gui import * # @UnusedWildImport
import os.path
import random
import string
# Import the code for the dialog
from visualisedialog import VisualiseDialog
from QSWATUtils import QSWATUtils, fileWriter, FileTypes
from QSWATTopology import QSWATTopology
from swatgraph import SWATGraph
from parameters import Parameters
from osgeo.gdalconst import * # @UnusedWildImport
import glob
from datetime import date
#import subprocess

class Visualise(QObject):
    """Support visualisation of SWAT outputs, using data in SWAT output database."""
    
    _TOTALS = 'Totals'
    _DAILYMEANS = 'Daily means'
    _MONTHLYMEANS = 'Monthly means'
    _ANNUALMEANS = 'Annual means'
    _MAXIMA = 'Maxima'
    _MINIMA = 'Minima'
    _AREA = 'AREAkm2'
    _MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    
    def __init__(self, iface, gv):
        """Initialise class variables."""
        QObject.__init__(self)
        self._iface = iface
        self._gv = gv
        self._dlg = VisualiseDialog()
        self._dlg.setWindowFlags(self._dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint & Qt.WindowMinimizeButtonHint)
        self._dlg.move(self._gv.visualisePos)
        ## variables found in various tables that do not contain values used in results
        self.ignoredVars = ['LULC', 'HRU', '', 'SUB', 'RCH', 'YEAR', 'MON', 'DAY', Visualise._AREA, 'YYYYDDD', 'YYYYMM']
        ## current scenario
        self.scenario = ''
        ## Current output database
        self.db = ''
        ## Current connection
        self.conn = None
        ## Current table
        self.table = ''
        ## Number of subbasins in current watershed
        self.numSubbasins = 0
        ## Data read from db table
        #
        # data takes the form
        # subbasin_number -> variable_name -> year -> month -> value
        self.staticData = dict()
        ## Data to write to shapefile
        #
        # takes the form subbasin number -> variable_name -> value for static use
        # takes the form date -> subbasin number -> val for animation
        # where date is YYYY or YYYYMM or YYYYDDD according to period of input
        self.resultsData = dict()
        ## Areas of subbasins (drainage area for reaches)
        self.areas = dict()
        ## Flag to indicate areas available
        self.hasAreas = False
        # data from cio file
        ## number of years in simulation
        self.numYears = 0
        ## true if output is daily
        self.isDaily = False
        ## true if output is annual
        self.isAnnual = False
        ## julian start day
        self.julianStartDay = 0
        ## julian finish day
        self.julianFinishDay = 0
        ## start year of period (of output: includes any nyskip)
        self.startYear = 0
        ## start month of period
        self.startMonth = 0
        ## start day of period
        self.startDay = 0
        ## finish year of period
        self.finishYear = 0
        ## finish month of period
        self.finishMonth = 0
        ## finish day of period
        self.finishDay = 0
        ## length of simulation in days
        self.periodDays = 0
        ## length of simulation in months (may be fractional)
        self.periodMonths = 0
        ## length of simulation in years (may be fractional)
        self.periodYears = 0
        ## flag to decide if we need to create a new results file:
        # changes to summary method or result variable don't need a new file
        self.resultsFileUpToDate = False
        ## flag to decide if we need to reread data because period has changed
        self.periodsUpToDate = False
        ## current streams results layer
        self.rivResultsLayer = None
        ## current subbasins results layer
        self.subResultsLayer = None
        ## current HRUs results layer
        self.hruResultsLayer = None
        ## current resultsFile
        self.resultsFile = ''
        ## flag to indicate if summary has changed since last write to results file
        self.summaryChanged = True
        ## current animation layer
        self.animateLayer = None
        ## current animation file (a temporary file)
        self.animateFile = ''
        ## index of animation variable in results file
        self.animateIndex = -1
        ## all values involved in animation, for calculating Jenks breaks
        self.allAnimateVals = []
        ## timer used to run animation
        self.animateTimer = QTimer()
        ## flag to indicate if animation running
        self.animating = False
        ## flag to indicate if animation paused
        self.animationPaused = False
        ## animation variable
        self.animateVar = ''
        ## flag to indicate if stream renderer being changed by code
        self.internalChangeToRivRenderer = False
        ## flag to indicate if subbasin renderer being changed by code
        self.internalChangeToSubRenderer = False
        ## flag to indicate if HRU renderer being changed by code
        self.internalChangeToHRURenderer = False
        ## flag to indicate if colours for rendering streams should be inherited from existing results layer
        self.keepRivColours = False
        ## flag to indicate if colours for rendering subbasins should be inherited from existing results layer
        self.keepSubColours = False
        ## flag to indicate if colours for rendering HRUs should be inherited from existing results layer
        self.keepHRUColours = False
        ## flag for HRU results for current scenario: 0 for limited HRUs or multiple but no hru table; 1 for single HRUs; 2 for multiple
        self.HRUsSetting = 0
        ## table of numbers of HRU in each subbasin (empty if no hru table)
        self.hruNums = dict()
        ## file with observed data for plotting
        self.observedFileName = ''
        
    def init(self):
        """Initialise the visualise form."""
        self.setSummary()
        self.fillScenarios()
        self._dlg.scenariosCombo.activated.connect(self.setupDb)
        self._dlg.scenariosCombo.setCurrentIndex(self._dlg.scenariosCombo.findText('Default'))
        if self.db == '':
            self.setupDb()
        self._dlg.outputCombo.activated.connect(self.setVariables)
        self._dlg.summaryCombo.activated.connect(self.changeSummary)
        self._dlg.addButton.clicked.connect(self.addClick)
        self._dlg.allButton.clicked.connect(self.allClick)
        self._dlg.delButton.clicked.connect(self.delClick)
        self._dlg.clearButton.clicked.connect(self.clearClick)
        self._dlg.resultsFileButton.clicked.connect(self.setResultsFile)
        self._dlg.tabWidget.setCurrentIndex(0)
        self._dlg.saveButton.clicked.connect(self.makeResults)
        self._dlg.animationVariableCombo.activated.connect(self.setupAnimate)
        self._dlg.slider.valueChanged.connect(self.changeAnimate)
        self._dlg.slider.sliderPressed.connect(self.pressSlider)
        self._dlg.playCommand.clicked.connect(self.doPlay)
        self._dlg.pauseCommand.clicked.connect(self.doPause)
        self._dlg.rewindCommand.clicked.connect(self.doRewind)
        self._dlg.spinBox.valueChanged.connect(self.changeSpeed)
        self.animateTimer.timeout.connect(self.doStep)
        self.setupTable()
        self._dlg.subPlot.activated.connect(self.plotSetSub)
        self._dlg.hruPlot.activated.connect(self.plotSetHRU)
        self._dlg.variablePlot.activated.connect(self.plotSetVar)
        self._dlg.addPlot.clicked.connect(self.doAddPlot)
        self._dlg.deletePlot.clicked.connect(self.doDelPlot)
        self._dlg.copyPlot.clicked.connect(self.doCopyPlot)
        self._dlg.upPlot.clicked.connect(self.doUpPlot)
        self._dlg.downPlot.clicked.connect(self.doDownPlot)
        self._dlg.observedFileButton.clicked.connect(self.setObservedFile)
        self._dlg.addObserved.clicked.connect(self.addObervedPlot)
        self._dlg.plotButton.clicked.connect(self.writePlotData)
        self._dlg.closeButton.clicked.connect(self.doClose)
        self._dlg.destroyed.connect(self.doClose)
        # hide most layers and DEM
        li = self._iface.legendInterface()
        if self._gv.slopeGroupIndex >= 0:
            li.setGroupVisible(self._gv.slopeGroupIndex, False)
        if self._gv.soilGroupIndex >= 0:
            li.setGroupVisible(self._gv.soilGroupIndex, False)
        if self._gv.landuseGroupIndex >= 0:
            li.setGroupVisible(self._gv.landuseGroupIndex, False)
        demLayer = QSWATUtils.getLayerByLegend(FileTypes.legend(FileTypes._DEM), li.layers())
        if demLayer:
            li.setLayerVisible(demLayer, False)
        hillshadeLayer = QSWATUtils.getLayerByLegend(FileTypes.legend(FileTypes._HILLSHADE), li.layers())
        if hillshadeLayer:
            li.setLayerVisible(hillshadeLayer, False)
        actHRUsLayer = QSWATUtils.getLayerByLegend(QSWATUtils._ACTHRUSLEGEND, li.layers())
        if actHRUsLayer:
            li.setLayerVisible(actHRUsLayer, False)
        fullHRUsLayer = QSWATUtils.getLayerByLegend(QSWATUtils._FULLHRUSLEGEND, li.layers())
        if fullHRUsLayer:
            li.setLayerVisible(fullHRUsLayer, False)
        leftShortCut = QShortcut(QKeySequence(Qt.Key_Left), self._dlg)
        rightShortCut = QShortcut(QKeySequence(Qt.Key_Right), self._dlg)
        leftShortCut.activated.connect(self.animateStepLeft)
        rightShortCut.activated.connect(self.animateStepRight)
        proj = QgsProject.instance()
        title = proj.title()
        observedFileName, found = proj.readEntry(title, 'observed/observedFile', '')
        if found:
            self.observedFileName = observedFileName
            self._dlg.observedFileEdit.setText(observedFileName)
            
    def run(self):
        """Do visualisation."""
        self.init()
        self._dlg.show()
        self._dlg.exec_()
        self._gv.visualisePos = self._dlg.pos()
        
    def fillScenarios(self):
        """Put scenarios in scenariosCombo and months in start and finish month combos."""
        pattern = QSWATUtils.join(self._gv.scenariosDir, '*')
        for direc in glob.iglob(pattern):
            db = QSWATUtils.join(QSWATUtils.join(direc, Parameters._TABLESOUT), Parameters._OUTPUTDB)
            if os.path.exists(db):
                self._dlg.scenariosCombo.addItem(os.path.split(direc)[1])
        for month in Visualise._MONTHS:
            m = QSWATUtils.trans(month)
            self._dlg.startMonth.addItem(m)
            self._dlg.finishMonth.addItem(m)
        for i in range(31):
            self._dlg.startDay.addItem(str(i+1))
            self._dlg.finishDay.addItem(str(i+1))
    
    def setupDb(self):
        """Set current database and connection to it; put table names in outputCombo."""
        self.resultsFileUpToDate = False
        self.scenario = self._dlg.scenariosCombo.currentText()
        scenDir = QSWATUtils.join(self._gv.scenariosDir, self.scenario)
        outDir = QSWATUtils.join(scenDir, Parameters._TABLESOUT)
        self.db = QSWATUtils.join(outDir, Parameters._OUTPUTDB)
        txtInOutDir = QSWATUtils.join(scenDir, Parameters._TXTINOUT)
        cioFile = QSWATUtils.join(txtInOutDir, Parameters._CIO)
        if not os.path.exists(cioFile):
            QSWATUtils.error('Cannot find cio file {0}'.format(cioFile), self._gv.isBatch)
            return
        self.conn = self._gv.db.connectDb(self.db)
        if not self.conn:
            return
        self.readCio(cioFile)
        self._dlg.outputCombo.clear()
        self._dlg.outputCombo.addItem('')
        tables = []
        for row in self.conn.cursor().tables(tableType='TABLE'):
            tables.append(row.table_name)
        self.setHRUs(tables)
        for table in tables:
            if (self.HRUsSetting > 0 and table == 'hru') or table == 'rch' or table == 'sub' or table == 'sed' or table == 'wql':
                self._dlg.outputCombo.addItem(table)
        self._dlg.outputCombo.setCurrentIndex(0)
        self.table = ''
        self.plotSetSub()
        self._dlg.variablePlot.clear()
        self._dlg.variablePlot.addItem('')
        self.updateCurrentPlotRow(0)
        
    def setupTable(self):
        """Initialise the plot table."""
        self._dlg.tableWidget.setHorizontalHeaderLabels(['Scenario', 'Table', 'Sub', 'HRU', 'Variable'])
        self._dlg.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._dlg.tableWidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self._dlg.tableWidget.setColumnWidth(0, 100)
        self._dlg.tableWidget.setColumnWidth(1, 45)
        self._dlg.tableWidget.setColumnWidth(2, 45)
        self._dlg.tableWidget.setColumnWidth(3, 45)
        self._dlg.tableWidget.setColumnWidth(4, 90)
        
    def setVariables(self):
        """Fill variables combos from selected table; set default results file name."""
        table = self._dlg.outputCombo.currentText()
        if self.table == table:
            # no change: do nothing
            return
        self.table = table 
        if self.table == '':
            return
        if not self.conn:
            return
        scenDir = QSWATUtils.join(self._gv.scenariosDir, self.scenario)
        outDir = QSWATUtils.join(scenDir, Parameters._TABLESOUT)
        outFile = QSWATUtils.join(outDir, self.table + 'results.shp')
        self._dlg.resultsFileEdit.setText(outFile)
        self.resultsFileUpToDate = False
        self._dlg.variableCombo.clear()
        self._dlg.animationVariableCombo.clear()
        self._dlg.animationVariableCombo.addItem('')
        self._dlg.variablePlot.clear()
        self._dlg.variablePlot.addItem('')
        self._dlg.variableList.clear()
        cursor = self.conn.cursor()
        for row in cursor.columns(table=self.table):
            var = row.column_name
            if not var in self.ignoredVars:
                self._dlg.variableCombo.addItem(var)
                self._dlg.animationVariableCombo.addItem(var)
                self._dlg.variablePlot.addItem(var)
        self.updateCurrentPlotRow(1)
                
    def plotting(self):
        """Return true if plot tab open and plot table has a selected row."""
        if self._dlg.tabWidget.currentIndex() != 2:
            return False
        indexes = self._dlg.tableWidget.selectedIndexes()
        return indexes and len(indexes) > 0
                
    def setSummary(self):
        """Fill summary combo."""
        self._dlg.summaryCombo.clear()
        self._dlg.summaryCombo.addItem(Visualise._TOTALS)
        self._dlg.summaryCombo.addItem(Visualise._DAILYMEANS)
        self._dlg.summaryCombo.addItem(Visualise._MONTHLYMEANS)
        self._dlg.summaryCombo.addItem(Visualise._ANNUALMEANS)
        self._dlg.summaryCombo.addItem(Visualise._MAXIMA)
        self._dlg.summaryCombo.addItem(Visualise._MINIMA)
        
    def readCio(self, cioFile):
        """Read cio file to get period of run and print frequency."""
        with open(cioFile, 'r') as cio:
            # skip 7 lines
            for _ in xrange(7): cio.readline()
            nbyrLine = cio.readline()
            cioNumYears = int(nbyrLine[:20])
            iyrLine = cio.readline()
            cioStartYear = int(iyrLine[:20])
            idafLine = cio.readline()
            self.julianStartDay = int(idafLine[:20])
            idalLine = cio.readline()
            self.julianFinishDay = int(idalLine[:20])
            # skip 47 lines
            for _ in xrange(47): cio.readline()
            iprintLine = cio.readline()
            iprint = int(iprintLine[:20])
            self.isDaily = iprint == 1
            self.isAnnual = iprint == 2
            nyskipLine = cio.readline()
            nyskip = int(nyskipLine[:20])
            self.startYear = cioStartYear + nyskip
            self.numYears = cioNumYears - nyskip
        self.setDates()
        
    def setDates(self):
        """Set requested start and finish dates to smaller period of length of scenario and requested dates (if any)."""
        startDate = self.julianToDate(self.julianStartDay, self.startYear)
        finishYear = self.startYear + self.numYears - 1
        finishDate = self.julianToDate(self.julianFinishDay, finishYear)
        requestedStartDate = self.readStartDate()
        if not requestedStartDate:
            self.setStartDate(startDate)
        else:
            if requestedStartDate < startDate:
                QSWATUtils.information('Chosen period starts earlier than scenario {0} period: changing chosen start'.format(self.scenario), self._gv.isBatch)
                self.setStartDate(startDate)
        requestedFinishDate = self.readFinishDate()
        if not requestedFinishDate:
            self.setFinishDate(finishDate)
        else:
            if requestedFinishDate > finishDate:
                QSWATUtils.information('Chosen period finishes than scenario {0} period: changing chosen finish'.format(self.scenario), self._gv.isBatch)
                self.setFinishDate(finishDate)
        
    def setPeriods(self):
        """Define period of current scenario in days, months and years.  Return true if OK."""
        requestedStartDate = self.readStartDate()
        requestedFinishDate = self.readFinishDate()
        if not (requestedStartDate and requestedFinishDate):
            QSWATUtils.error('Cannot read chosen period', self._gv.isBatch)
            return False
        if requestedFinishDate <= requestedStartDate:
            QSWATUtils.error('Finish date must be later than start date', self._gv.isBatch)
            return False
        self.periodsUpToDate = self.startDay == requestedStartDate.day and \
        self.startMonth == requestedStartDate.month and \
        self.startYear == requestedStartDate.year and \
        self.finishDay == requestedFinishDate.day and \
        self.finishMonth == requestedFinishDate.month and \
        self.finishYear == requestedFinishDate.year
        if self.periodsUpToDate:
            return True
        self.startDay = requestedStartDate.day
        self.startMonth = requestedStartDate.month
        self.startYear = requestedStartDate.year
        self.finishDay = requestedFinishDate.day
        self.finishMonth = requestedFinishDate.month
        self.finishYear = requestedFinishDate.year
        self.julianStartDay = int(requestedStartDate.strftime('%j'))
        self.julianFinishDay = int(requestedFinishDate.strftime('%j'))
        self.periodDays = 0
        self.periodMonths = 0
        self.periodYears = 0
        for year in xrange(self.startYear, self.finishYear + 1):
            leapAdjust = 1 if self.isLeap(year) else 0
            yearDays = 365 + leapAdjust
            start = self.julianStartDay if year == self.startYear else 1
            finish = self.julianFinishDay if year == self.finishYear else yearDays
            numDays = finish - start + 1
            self.periodDays += numDays
            fracYear = float(numDays) / yearDays
            self.periodYears += fracYear
            self.periodMonths += fracYear * 12
        # QSWATUtils.loginfo('Period is {0} days, {1} months, {2} years'.format(self.periodDays, self.periodMonths, self.periodYears))
        return True
                
    def  readStartDate(self):
        """Return date from start date from form.  None if any problems."""
        try:
            day = int(self._dlg.startDay.currentText())
            month = Visualise._MONTHS.index(self._dlg.startMonth.currentText()) + 1
            year = int(self._dlg.startYear.text())
            return date(year, month, day)
        except:
            return None
                
    def  readFinishDate(self):
        """Return date from finish date from form.  None if any problems."""
        try:
            day = int(self._dlg.finishDay.currentText())
            month = Visualise._MONTHS.index(self._dlg.finishMonth.currentText()) + 1
            year = int(self._dlg.finishYear.text())
            return date(year, month, day)
        except:
            return None
        
    def setStartDate(self, date):
        """Set start date on form."""
        self._dlg.startDay.setCurrentIndex(date.day - 1)
        self._dlg.startYear.setText(str(date.year))
        self._dlg.startMonth.setCurrentIndex(date.month - 1)
            
    def setFinishDate(self, date):
        """Set finish date on form."""        
        self._dlg.finishDay.setCurrentIndex(date.day - 1)
        self._dlg.finishYear.setText(str(date.year))
        self._dlg.finishMonth.setCurrentIndex(date.month - 1)
            
        
    def addClick(self):
        """Append item to variableList."""
        self.resultsFileUpToDate = False
        var = self._dlg.variableCombo.currentText()
        items = self._dlg.variableList.findItems(var, Qt.MatchExactly)
        if not items or items == []:
            item = QListWidgetItem()
            item.setText(var)
            self._dlg.variableList.addItem(item)
            
    def allClick(self):
        """Clear variableList and insert all items from variableCombo."""
        self.resultsFileUpToDate = False
        self._dlg.variableList.clear()
        for i in range(self._dlg.variableCombo.count()):
            item = QListWidgetItem()
            item.setText(self._dlg.variableCombo.itemText(i))
            self._dlg.variableList.addItem(item)
        
    def delClick(self):
        """Delete item from variableList."""
        self.resultsFileUpToDate = False
        items = self._dlg.variableList.selectedItems()
        if len(items) > 0:
            row = self._dlg.variableList.indexFromItem(items[0]).row()
            self._dlg.variableList.takeItem(row)
    
    def clearClick(self):
        """Clear variableList."""
        self.resultsFileUpToDate = False
        self._dlg.variableList.clear()
        
    def doClose(self):
        """Close the db connection, timer, clean up from animation, and close the form."""
        self.conn = None
        self.animateTimer.stop()
        if self.animateLayer:
            try:
                QgsMapLayerRegistry.instance().removeMapLayer(self.animateLayer.id())
            except:
                # user may have removed
                self.animateLayer = None
        if self.animateFile and self.animateFile != '' and os.path.exists(self.animateFile):
            QSWATUtils.removeFiles(self.animateFile)
        self._dlg.close()
        
    def plotSetSub(self):
        """If the current table is 'hru', set the number of HRUs according to the subbasin.  Else set the hruPlot to '-'."""
        self._dlg.hruPlot.clear()
        if not self.table == 'hru':
            self._dlg.hruPlot.addItem('-')
            self.updateCurrentPlotRow(2)
            return
        self._dlg.hruPlot.addItem('')
        self.updateCurrentPlotRow(2)
        if not self.conn:
            return
        substr = self._dlg.subPlot.currentText()
        if substr == '':
            return
        sub = int(substr)
        # find maximum hru number in hru table for this subbasin
        maxHru = 0
        sql = self._gv.db.sqlSelect('hru', QSWATTopology._HRUGIS, '', 'SUB=?')
        for row in self.conn.cursor().execute(sql, sub):
            hru = int(row.HRUGIS[6:])
            maxHru = max(maxHru, hru)
        for i in range(maxHru):
            self._dlg.hruPlot.addItem(str(i+1))
            
    def plotSetHRU(self):
        """Update the HRU value in current plot row."""
        self.updateCurrentPlotRow(3)
        
    def plotSetVar(self):
        """Update the variable in the current plot row."""
        self.updateCurrentPlotRow(4)
        
    def writePlotData(self):
        """Write data for plot rows to csv file."""
        if not self.conn:
            return
        if not self.setPeriods():
            return
        numRows = self._dlg.tableWidget.rowCount()
        plotData = dict()
        labels = dict()
        dates = []
        datesDone = False
        for i in xrange(numRows):
            plotData[i] = []
            scenario = self._dlg.tableWidget.item(i, 0).text()
            table = self._dlg.tableWidget.item(i, 1).text()
            sub = self._dlg.tableWidget.item(i, 2).text()
            hru = self._dlg.tableWidget.item(i, 3).text()
            var = self._dlg.tableWidget.item(i, 4).text()
            if scenario == '' or table == '' or sub == '' or hru == '' or var == '':
                QSWATUtils.information('Row {0!s} is incomplete'.format(i+1), self._gv.isBatch)
                return
            if scenario == 'observed' and table == '-':
                if os.path.exists(self.observedFileName):
                    labels[i] = 'observed-{0}'.format(var.strip()) # last label has an attached newline, so strip it
                    plotData[i] = self.readObservedFile(var)
                else:
                    QSWATUtils.error('Cannot find observed data file {0}'.format(self.observedFileName), self._gv.isBatch)
                    return
            else:
                if table == 'hru':
                    hrugis = int(sub) * 10000 + int(hru)
                    # note that HRUGIS string as stored seems to have preceding space
                    where = "HRUGIS=' {0:09}'".format(hrugis)
                    num = hrugis if self.HRUsSetting == 2 else int(sub)
                elif table == 'rch' or table == 'sub':
                    where = 'SUB={0}'.format(sub)
                    num = int(sub)
                elif table == 'sed' or table == 'wql':
                    where = 'RCH={0}'.format(sub)
                    num = int(sub)
                else:
                    QSWATUtils.error('Unknown table {0) in row {1}'.format(table, i+1), self._gv.isBatch)
                    return
                labels[i] = '{0}-{1}-{2!s}-{3}'.format(scenario, table, num, var)
                self.readData(False, True, table, var, where)
                (year, mon) = self.startYearMon()
                (finishYear, finishMon) = self.finishYearMon()
                finished = False
                while not finished:
                    if not num in self.staticData:
                        if table == 'hru':
                            ref = 'HRU {0!s}'.format(sub)
                        else:
                            ref = 'subbasin {0!s}'.format(sub)
                        QSWATUtils.error('Insufficient data for {0} for plot {1!s}'.format(ref, i+1), self._gv.isBatch)
                        break
                    subData = self.staticData[num]
                    if not var in subData:
                        QSWATUtils.error('Insufficient data for variable {0} for plot {1!s}'.format(var, i+1), self._gv.isBatch)
                        break
                    varData = subData[var]
                    if not year in varData:
                        QSWATUtils.error('Insufficient data for year {0} for plot {1!s}'.format(year, i+1), self._gv.isBatch)
                        break
                    yearData = varData[year]
                    if not mon in yearData:
                        if self.isDaily or self.table == 'wql':
                            ref = 'day {0!s}'.format(mon)
                        elif self.isAnnual:
                            ref = 'year {0!s}'.format(mon)
                        else:
                            ref = 'month (0!s)'.format(mon)
                        QSWATUtils.error('Insufficient data for {0} of year {1} for plot {2!s}'.format(ref, year, i+1), self._gv.isBatch)
                        break
                    val = yearData[mon]
                    plotData[i].append('{:.3g}'.format(val))
                    if not datesDone:
                        if self.isDaily or self.table == 'wql':
                            dates.append(str(year * 1000 + mon))
                        elif self.isAnnual:
                            dates.append(str(year))
                        else:
                            dates.append(str(year) + '/' + str(mon))
                    finished = (year == finishYear and mon == finishMon)
                    (year, mon) = self.nextDate(year, mon)
                datesDone = True
        # data all collected: write csv file
        csvFile = QFileDialog.getSaveFileName(None, 'Choose a csv file', self._gv.scenariosDir, 'CSV files (*.csv)')
        if not csvFile:
            return
        with fileWriter(csvFile) as fw:
            fw.write('Date,')
            for i in xrange(numRows - 1):
                fw.write(labels[i])
                fw.write(',')
            fw.writeLine(labels[numRows - 1])
            for d in xrange(len(dates)):
                fw.write(dates[d])
                fw.write(',')
                for i in xrange(numRows):
                    if not i in plotData:
                        QSWATUtils.error('Missing data for plot {0!s}'.format(i+1), self._gv.isBatch)
                        fw.writeLine('')
                        return
                    if not d in range(len(plotData[i])):
                        QSWATUtils.error('Missing data for date {0} for plot {1!s}'.format(dates[d], i+1), self._gv.isBatch)
                        fw.writeLine('')
                        return
                    fw.write(plotData[i][d])
                    if i < numRows - 1:
                        fw.write(',')
                    else:
                        fw.writeLine('')
#         commands = []
#         settings = QSettings()
#         commands.append(QSWATUtils.join(QSWATUtils.join(settings.value('/QSWAT/SWATEditorDir'), Parameters._SWATGRAPH), Parameters._SWATGRAPH))
#         commands.append(csvFile)
#         subprocess.Popen(commands)
# above replaced with swatGraph form
        graph = SWATGraph(csvFile)
        graph.run()
    
    def readData(self, isStatic, isPlot, table, var, where):
        """Read data from database table into staticData."""
        if not self.conn:
            return
        # clear existing data
        self.staticData = dict()
        self.areas = dict()
        self.hasAreas = False
        self.resultsData = dict()
        if isStatic:
            varz = self.varList(True)
        elif isPlot:
            varz = ['[' + var + ']']
        else:
            self.animateVar = var
            varz = ['[' + var + ']']
        numVars = len(varz)
        if table == 'sub' or table == 'rch':
            if isStatic:
                preString = 'SUB, YEAR, MON, AREAkm2, '
                preLen = 4
                self.hasAreas = True
            else:
                preString = 'SUB, YEAR, MON, '
                preLen = 3
        elif table == 'hru':
            if isStatic:
                if self.HRUsSetting == 2:
                    preString = 'HRUGIS, YEAR, MON, AREAkm2, '
                else:
                    preString = 'SUB, YEAR, MON, AREAkm2, '
                preLen = 4
                self.hasAreas = True
            else:
                if self.HRUsSetting == 2:
                    preString = 'HRUGIS, YEAR, MON, '
                else:
                    preString = 'SUB, YEAR, MON, '
                preLen = 3
        elif table == 'sed':
            if isStatic:
                preString = 'RCH, YEAR, MON, AREAkm2, '
                preLen = 4
                self.hasAreas = True
            else:
                preString = 'RCH, YEAR, MON, '
                preLen = 3
        elif table == 'wql':
            preString = 'RCH, YEAR, DAY, '
            preLen = 3
            self.hasAreas = False
        else:
            # TODO: not yet supported
            return
        selectString = preString + ', '.join(varz)
        cursor = self.conn.cursor()
        sql = self._gv.db.sqlSelect(table, selectString, '', where)
        # QSWATUtils.information('SQL: {0}'.format(sql), self._gv.isBatch)
        for row in cursor.execute(sql):
            # index is subbasin number unless multiple hrus, when it is the integer parsing of HRUGIS
            index = int(row[0])
            year = int(row[1])
            mon = int(row[2])
            if not self.inPeriod(year, mon):
                continue
            if self.hasAreas:
                area = float(row[3])
            if isStatic and self.hasAreas and not index in self.areas:
                self.areas[index] = area
            if not index in self.staticData:
                self.staticData[index] = dict()
            for i in range(numVars):
                # remove square brackets from each var
                var = varz[i][1:-1]
                val = float(row[i+preLen])
                if not var in self.staticData[index]:
                    self.staticData[index][var] = dict()
                if not year in self.staticData[index][var]:
                    self.staticData[index][var][year] = dict()
                self.staticData[index][var][year][mon] = val
        self.summaryChanged = True
        
    def inPeriod(self, year, mon):
        """
        Return true if year and mon are within requested period.
        
        Assumes self.[julian]startYear/Month/Day and self.[julian]finishYear/Month/Day already set.
        Assumes mon is within 1..365/6 when daily, and within 1..12 when monthly.
        """
        if year < self.startYear or year > self.finishYear:
            return False
        if self.isAnnual:
            return True
        if self.isDaily or self.table == 'wql':
            if year == self.startYear:
                return mon >= self.julianStartDay
            if year == self.finishYear:
                return mon <= self.julianFinishDay
            return True
        # monthly
        if year == self.startYear:
            return mon >= self.startMonth
        if year == self.finishYear:
            return mon <= self.finishMonth
        return True
            
                
    def summariseData(self, isStatic):
        """if isStatic, summarise data in staticData, else store all data for animate variable, saving in resultsData."""
        if isStatic:
            for index, vym in self.staticData.iteritems():
                for var, ym in vym.iteritems():
                    val = self.summarise(ym)
                    if index not in self.resultsData:
                        self.resultsData[index] = dict()
                    self.resultsData[index][var] = val
        else:
            self.allAnimateVals = []
            for index, vym in self.staticData.iteritems():
                for ym in vym.itervalues():
                    for y, mval in ym.iteritems():
                        for m, val in mval.iteritems():
                            dat = self.makeDate(y, m)
                            if not dat in self.resultsData:
                                self.resultsData[dat] = dict()
                            self.resultsData[dat][index] = val
                            self.allAnimateVals.append(val)
                            
    def makeDate(self, year, mon):
        """
        Make date number from year and mon according to period.
        
        mon is MON field, which may be year, month or day according to period.
        """
        if self.isDaily or self.table == 'wql':
            return year * 1000 + mon
        elif self.isAnnual:
            return year
        else:
            return year * 100 + mon
        
    def startYearMon(self):
        """Return (year, mon) pair for start date according to period."""
        if self.isDaily or self.table == 'wql':
            return (self.startYear, self.julianStartDay)
        elif self.isAnnual:
            return (self.startYear, self.startYear)
        else:
            return (self.startYear, self.startMonth)
        
    def finishYearMon(self):
        """Return (year, mon) pair for finish date according to period."""
        if self.isDaily or self.table == 'wql':
            return (self.finishYear, self.julianFinishDay)
        elif self.isAnnual:
            return (self.finishYear, self.finishYear)
        else:
            return (self.finishYear, self.finishMonth)
            
        
    def nextDate(self, year, mon):
        """Get next (year, mon) pair according to period."""
        if self.isDaily or self.table == 'wql':
            leapAdjust = 1 if self.isLeap(year) else 0
            maxDays = 365 + leapAdjust
            if mon < maxDays:
                return (year, mon+1)
            else:
                return (year+1, 1)
        elif self.isAnnual:
            return (year+1, year+1)
        else:
            if mon < 12:
                return (year, mon+1)
            else:
                return (year+1, 1)
            
        
    def summarise(self, data):
        """Summarise values according to summary method."""
        if self._dlg.summaryCombo.currentText() == Visualise._TOTALS:
            return self.summariseTotal(data)
        elif self._dlg.summaryCombo.currentText() == Visualise._ANNUALMEANS:
            return self.summariseAnnual(data)
        elif self._dlg.summaryCombo.currentText() == Visualise._MONTHLYMEANS:
            return self.summariseMonthly(data)
        elif self._dlg.summaryCombo.currentText() == Visualise._DAILYMEANS:
            return self.summariseDaily(data)
        elif self._dlg.summaryCombo.currentText() == Visualise._MAXIMA:
            return self.summariseMaxima(data)
        elif self._dlg.summaryCombo.currentText() == Visualise._MINIMA:
            return self.summariseMinima(data)
        else:
            QSWATUtils.error('Internal error: unknown summary method: please report', self._gv.isBatch)
            
    def summariseTotal(self, data):
        """Sum values and return."""
        total = 0
        for mv in data.itervalues():
            for v in mv.itervalues():
                total += v
        return total
        
    def summariseAnnual(self, data):
        """Return total divided by period in years."""
        return float(self.summariseTotal(data)) / self.periodYears
        
    def summariseMonthly(self, data):
        """Return total divided by period in months."""
        return float(self.summariseTotal(data)) / self.periodMonths
        
    def summariseDaily(self, data):
        """Return total divided by period in days."""
        return float(self.summariseTotal(data)) / self.periodDays
        
    def summariseMaxima(self, data):
        """Return maximum of values."""
        maxv = 0
        for mv in data.itervalues():
            for v in mv.itervalues():
                maxv = max(maxv, v)
        return maxv
        
    def summariseMinima(self, data):
        """Return minimum of values."""
        minv = float('inf')
        for mv in data.itervalues():
            for v in mv.itervalues():
                minv = min(minv, v)
        return minv
                
    @staticmethod
    def isLeap(year):
        """Return true if year is a leap year."""
        if year % 4 == 0:
            if year % 100 == 0:
                return year % 400 == 0
            else:
                return True
        else:
            return False
        
    def setNumSubbasins(self, tables):
        """Set self.numSubbasins from one of tables."""
        if not self.conn:
            return
        self.numSubbasins = 0
        if 'sub' in tables:
            table = 'sub'
            subCol = 'SUB'
        elif 'rch' in tables:
            table = 'rch'
            subCol = 'SUB'
        elif 'sed' in tables:
            table = 'sed'
            subCol = 'RCH'
        elif 'wql' in tables:
            table = 'wql'
            subCol = 'RCH'
        else:
            QSWATUtils.error('Seem to be no complete tables in this scenario', self._gv.isBatch)
            return
        sql = self._gv.db.sqlSelect(table, subCol, '', '')
        for row in self.conn.cursor().execute(sql):
            self.numSubbasins = max(self.numSubbasins, int(row[0]))
            
    def setSubPlot(self):
        """Add subbasin numbers to subPlot combo."""
        self._dlg.subPlot.clear()
        self._dlg.subPlot.addItem('')
        for i in range(self.numSubbasins):
            self._dlg.subPlot.addItem(str(i+1))
                   
    def setHRUs(self, tables):
        """
        Set self.hruNums if hru table, plus HRUsSetting.  Also self.numSubbasins, and populate subPlot combo.
        
        HRUsSetting is 1 if only 1 HRU in each subbasin, else 0 if limited HRU output or no hru template shapefile, else 2 (meaning multiple HRUs).
        """
        if not self.conn:
            return
        if not 'hru' in tables:
            self.setNumSubbasins(tables)
            self.setSubPlot()
            return
        tablesOutDir = os.path.split(self.db)[0]
        HRUsFile = QSWATUtils.join(tablesOutDir, Parameters._HRUS) + '.shp'
        # find maximum hru number in hru table for each subbasin
        self.hruNums = dict()
        self.numSubbasins = 0
        maxHRU = 0
        maxSub = 0
        sql = self._gv.db.sqlSelect('hru', QSWATTopology._HRUGIS, '', '')
        for row in self.conn.cursor().execute(sql):
            hrugis = int(row.HRUGIS)
            hru = hrugis % 10000
            sub = hrugis / 10000
            maxHRU = max(maxHRU, hru)
            maxSub = max(maxSub, sub)
            self.hruNums[sub] = max(hru, self.hruNums.get(sub, 0))
        if maxSub > 1 and maxHRU == 1:
            self.HRUsSetting = 1
            self.numSubbasins = maxSub
        elif maxSub == 1 or not os.path.exists(HRUsFile):
            self.HRUsSetting = 0
            self.setNumSubbasins(tables)
        else:
            self.HRUsSetting = 2
            self.numSubbasins = maxSub
        self.setSubPlot()
            
    def varList(self, bracket):
        """Return variables in variableList as a list of strings, with square brackets if bracket is true."""
        result = []
        numRows = self._dlg.variableList.count()
        for row in xrange(numRows):
            var = self._dlg.variableList.item(row).text()
            # bracket variables when using in sql, to avoid reserved words and '/'
            if bracket:
                var = '[' + var + ']'
            result.append(var)
        return result
    
    def setResultsFile(self):
        """Set results file by asking user."""
        try:
            path = os.path.split(self._dlg.resultsFileEdit.text())[0]
        except:
            path = ''
        subsOrRiv = 'subs' if self.useSubs() else 'hrus' if self.useHRUs() else 'riv'
        resultsFileName = QFileDialog.getSaveFileName(None, subsOrRiv + 'results', path, QgsProviderRegistry.instance().fileVectorFilters())
        if not resultsFileName:
            return
        direc, name = os.path.split(resultsFileName)
        direcUp, direcName = os.path.split(direc)
        if direcName == Parameters._TABLESOUT:
            ## check we are not overwriting a template or using animate.shp
            direcUpUp = os.path.split(direcUp)[0]
            if QSWATUtils.samePath(direcUpUp, self._gv.scenariosDir):
                base = os.path.splitext(name)[0]
                if base == Parameters._SUBS or base == Parameters._RIVS or base == Parameters._HRUS:
                    QSWATUtils.information('The file {0} should not be overwritten: please choose another file name.'.format(os.path.splitext(resultsFileName)[0] + '.shp'), self._gv.isBatch)
                    return
                if base == Parameters._ANIMATE:
                    QSWATUtils.information('Please do not use {0} for results as it can be overwritten by animation.'.format(os.path.splitext(resultsFileName)[0] + '.shp'), self._gv.isBatch)
                    return
        self._dlg.resultsFileEdit.setText(resultsFileName)
        self.resultsFileUpToDate = False
        
    def setObservedFile(self):
        """Get an observed data file from the user."""
        try:
            path = os.path.split(self._dlg.observedFileEdit.text())[0]
        except:
            path = ''
        observedFileName = QFileDialog.getOpenFileName(None, 'Choose observed data file', path, 'CSV files (*.csv);;Any file (*.*)')
        if not observedFileName:
            return
        self.observedFileName = observedFileName
        self._dlg.observedFileEdit.setText(observedFileName)
        proj = QgsProject.instance()
        title = proj.title()
        proj.writeEntry(title, 'observed/observedFile', self.observedFileName)
        
    def useSubs(self):
        """Return true if should use subbasins map for results (else use streams or HRUs)."""
        return self.table == 'sub' or self.table == 'hru' and self.HRUsSetting == 1
    
    def useHRUs(self):
        """Return true if should use HRUs map."""
        return self.table == 'hru' and self.HRUsSetting ==  2
        
    def createResultsFile(self):
        """
        Create results shapefile.
        
        Assumes:
        - resultsFileEdit contains suitable text for results file name
        - one or more variables is selected in variableList (and uses the first one)
        - resultsData is suitably populated
        """
        self.resultsFile = self._dlg.resultsFileEdit.text()
        if os.path.exists(self.resultsFile):
            reply = QSWATUtils.question('Results file {0} already exists.  Do you wish to overwrite it?'.format(self.resultsFile), self._dlg, True)
            if reply != QMessageBox.Yes:
                return False
            QSWATUtils.removeLayerAndFiles(self.resultsFile, self._iface.legendInterface())
        tablesOutDir = os.path.split(self.db)[0]
        baseName = Parameters._SUBS if self.useSubs() else Parameters._HRUS if self.useHRUs() else Parameters._RIVS
        resultsBase = QSWATUtils.join(tablesOutDir, baseName) + '.shp'
        outdir, outfile = os.path.split(self.resultsFile)
        outbase = os.path.splitext(outfile)[0]
        QSWATUtils.copyShapefile(resultsBase, outbase, outdir)
        selectVar = self._dlg.variableList.selectedItems()[0].text()[:10]
        legend = '{0} {1} {2}'.format(self.scenario, selectVar, self._dlg.summaryCombo.currentText())
        if self.useSubs():
            self.subResultsLayer = QgsVectorLayer(self.resultsFile, legend, 'ogr')
            self.subResultsLayer.rendererChanged.connect(self.changeSubRenderer)
            self.internalChangeToSubRenderer = True
            self.keepSubColours = False
            layer = self.subResultsLayer
        elif self.useHRUs():
            self.hruResultsLayer = QgsVectorLayer(self.resultsFile, legend, 'ogr')
            self.hruResultsLayer.rendererChanged.connect(self.changeHRURenderer)
            self.internalChangeToHRURenderer = True
            self.keepHRUColours = False
            layer = self.hruResultsLayer
        else:
            self.rivResultsLayer = QgsVectorLayer(self.resultsFile, legend, 'ogr')
            self.rivResultsLayer.rendererChanged.connect(self.changeRivRenderer)
            self.internalChangeToRivRenderer = True
            self.keepRivColours = False
            layer = self.rivResultsLayer
        if self.hasAreas:
            field = QgsField(Visualise._AREA, QVariant.Double, len=20, prec=0)
            if not layer.dataProvider().addAttributes([field]):
                QSWATUtils.error('Could not add field {0} to results file {1}'.format(Visualise._AREA, self.resultsFile), self._gv.isBatch)
                return False
        varz = self.varList(False)
        for var in varz:
            field = QgsField(var, QVariant.Double)
            if not layer.dataProvider().addAttributes([field]):
                QSWATUtils.error('Could not add field {0} to results file {1}'.format(var, self.resultsFile), self._gv.isBatch)
                return False
        layer.updateFields()
        self.updateResultsFile() 
        layer = QgsMapLayerRegistry.instance().addMapLayer(layer)
        self._iface.legendInterface().moveLayer(layer, self._gv.resultsGroupIndex)
        if self.useSubs():
            self.subResultsLayer = layer
            # add labels
            self.subResultsLayer.loadNamedStyle(QSWATUtils.join(self._gv.plugin_dir, 'subresults.qml'))
            self.internalChangeToSubRenderer = False
        elif self.useHRUs():
            self.hruResultsLayer = layer
            self.internalChangeToHRURenderer = False
        else:
            self.rivResultsLayer = layer
            self.internalChangeToRivRenderer = False
        return True
        
    def updateResultsFile(self):
        """Write resultsData to resultsFile."""
        layer = self.subResultsLayer if self.useSubs() else self.hruResultsLayer if self.useHRUs() else self.rivResultsLayer
        varz = self.varList(False)
        varIndexes = dict()
        if self.hasAreas:
            varIndexes[Visualise._AREA] = self._gv.topo.getIndex(layer, Visualise._AREA)
        for var in varz:
            varIndexes[var] = self._gv.topo.getIndex(layer, var)
        layer.startEditing()
        for f in layer.getFeatures():
            fid = f.id()
            if self.useHRUs():
                # May be split HRUs; just use first
                # This is inadequate for some variables, but no way to know of correct val is sum of vals, mean, etc.
                sub = int(string.split(f.attribute(QSWATTopology._HRUGIS), ',')[0])
            else:
                sub = f.attribute(QSWATTopology._SUBBASIN)
            if self.hasAreas:
                if sub in self.areas:
                    area = self.areas[sub]
                else:
                    if self.useHRUs():
                        ref = 'HRU {0!s}'.format(sub)
                    else:
                        ref = 'subbasin {0!s}'.format(sub)
                    QSWATUtils.error('Cannot get area for {0}: have you run SWAT and saved data since running QSWAT'.format(ref), self._gv.isBatch)
                    return
                if not layer.changeAttributeValue(fid, varIndexes[Visualise._AREA], area):
                    QSWATUtils.error('Could not set attribute {0} in results file {1}'.format(Visualise._AREA, self.resultsFile), self._gv.isBatch)
                    return
            for var in varz:
                if sub in self.resultsData and var in self.resultsData[sub]:
                    data = self.resultsData[sub][var]
                else:
                    if self.useHRUs():
                        ref = 'HRU {0!s}'.format(sub)
                    else:
                        ref = 'subbasin {0!s}'.format(sub)
                    QSWATUtils.error('Cannot get data for variable {0} in {1}: have you run SWAT and saved data since running QSWAT'.format(var, ref), self._gv.isBatch)
                    return
                if not layer.changeAttributeValue(fid, varIndexes[var], data):
                    QSWATUtils.error('Could not set attribute {0} in results file {1}'.format(var, self.resultsFile), self._gv.isBatch)
                    return
        layer.commitChanges()
        self.summaryChanged = False
        
    def colourResultsFile(self):
        """
        Colour results layer according to current results variable and update legend.
        
        if createColour is false the existing colour ramp and number of classes can be reused
        """
        if self.useSubs():
            layer = self.subResultsLayer
            keepColours = self.keepSubColours
            symbol = QgsFillSymbolV2()
        elif self.useHRUs():
            layer = self.hruResultsLayer
            keepColours = self.keepHRUColours
            symbol = QgsFillSymbolV2()
        else:
            layer = self.rivResultsLayer
            keepColours = self.keepRivColours
            props = {'width_expression': QSWATTopology._PENWIDTH}
            symbol = QgsLineSymbolV2.createSimple(props)
        selectVar = self._dlg.variableList.selectedItems()[0].text()
        selectVarShort = selectVar[:10]
        layer.setLayerName('{0} {1} {2}'.format(self.scenario, selectVar, self._dlg.summaryCombo.currentText()))
        if not keepColours:
            count = 5
            transparency = 35 if self.useSubs() or self.useHRUs() else 0
        else:
            # same layer as currently - try to use same range size and colours, and same transparency
            try:
                oldRenderer = layer.rendererV2()
                oldRanges = oldRenderer.ranges()
                count = len(oldRanges)
                ramp = oldRenderer.sourceColorRamp()
                transparency = layer.layerTransparency()
                invert = oldRenderer.invertedColorRamp()
            except:
                # don't care if no suitable colours, so no message, just revert to defaults
                keepColours = False
                count = 5
                transparency = 35 if self.useSubs() or self.useHRUs() else 0
        if not keepColours:
            ramp, invert = self.chooseColorRamp(self.table, selectVar)
        labelFmt = QgsRendererRangeV2LabelFormat('%1 - %2', 0)
        renderer = QgsGraduatedSymbolRendererV2.createRenderer(layer, selectVarShort, count, QgsGraduatedSymbolRendererV2.Jenks, symbol, ramp, invert, labelFmt)
        renderer.calculateLabelPrecision()
        # previous line should be enough to update precision, but in practice seems we need to recreate renderer
        precision = renderer.labelFormat().precision()
        # QSWATUtils.information('Precision: {0}'.format(precision), self._gv.isBatch)
        labelFmt = QgsRendererRangeV2LabelFormat('%1 - %2', precision)
        renderer = QgsGraduatedSymbolRendererV2.createRenderer(layer, selectVarShort, count, QgsGraduatedSymbolRendererV2.Jenks, symbol, ramp, invert, labelFmt)
        if self.useSubs():
            self.internalChangeToSubRenderer = True
        elif self.useHRUs():
            self.internalChangeToHRURenderer = True
        else:
            self.internalChangeToRivRenderer = True
        layer.setRendererV2(renderer)
        layer.setLayerTransparency(transparency)
        layer.triggerRepaint()
        self._iface.legendInterface().refreshLayerSymbology(layer)
        if self.useSubs():
            self.internalChangeToSubRenderer = False
            self.keepSubColours = keepColours
        elif self.useHRUs():
            self.internalChangeToHRURenderer = False
            self.keepHRUColours = keepColours
        else:
            self.internalChangeToRivRenderer = False
            self.keepRivColours = keepColours
        
    def createAnimationFile(self):
        """
        Create animation shapefile.
        
        Assumes:
        - resultsFileEdit contains suitable text for animation file name
        - animation variable is set
        - resultsData is suitably populated
        """
        li = self._iface.legendInterface()
        makeColours = True
        count = 5
        transparency = 35 if self.useSubs() or self.useHRUs() else 0
        ramp, invert = self.chooseColorRamp(self.table, self.animateVar)
        if self.animateLayer:
            # we will try to reuse number of breaks and colours, and same transparency
            try:
                oldRenderer = self.animateLayer.rendererV2()
                oldRanges = oldRenderer.ranges()
                count = len(oldRanges)
                ramp = oldRenderer.sourceColorRamp()
                transparency = self.animateLayer.layerTransparency()
                invert = oldRenderer.invertedColorRamp()
                makeColours = False
            except:
                # don't care if no usable colour scheme of right kind
                pass
            try:
                QgsMapLayerRegistry.instance().removeMapLayer(self.animateLayer.id())
            except:
                # user deleted already
                self.animateLayer = None
        tablesOutDir = os.path.split(self.db)[0]
        base = Parameters._SUBS if self.useSubs() else Parameters._HRUS if self.useHRUs() else Parameters._RIVS
        resultsBase = QSWATUtils.join(tablesOutDir, base) + '.shp'
        if not self.animateFile or self.animateFile == '':
            self.animateFile = QSWATUtils.join(tablesOutDir, Parameters._ANIMATE + '.shp')
        outdir, outfile = os.path.split(self.animateFile)
        outbase = os.path.splitext(outfile)[0]
        QSWATUtils.copyShapefile(resultsBase, outbase, outdir)
        self.animateLayer = QgsVectorLayer(self.animateFile, 'Animate {0} {1}'.format(self.scenario, self.animateVar), 'ogr')
        field = QgsField(self.animateVar, QVariant.Double)
        if not self.animateLayer.dataProvider().addAttributes([field]):
            QSWATUtils.error('Could not add field {0} to animation file {1}'.format(self.animateVar, self.animateFile), self._gv.isBatch)
            return
        self.animateLayer.updateFields()
        self.animateIndex = self._gv.topo.getIndex(self.animateLayer, self.animateVar)
        self._dlg.slider.setValue(1)
        self.animateLayer = QgsMapLayerRegistry.instance().addMapLayer(self.animateLayer)
        self._iface.legendInterface().moveLayer(self.animateLayer, self._gv.resultsGroupIndex)
        # add labels if based on subbasins
        if self.useSubs():
            self.animateLayer.loadNamedStyle(QSWATUtils.join(self._gv.plugin_dir, 'subsresults.qml')) 
        # colour it 
        breaks, minimum = self.getJenksBreaks(self.allAnimateVals, count)
        QSWATUtils.loginfo('Breaks: {0!s}'.format(breaks))
        rangeList = []
        for i in xrange(count):
            minVal = minimum if i == 0 else breaks[i]
            maxVal = breaks[i+1]
            f = float(i)
            if makeColours:
                colourVal = (count - f) / (count - 1) if invert else f / (count - 1)
                colour = ramp.color(colourVal)
            else:
                colour = oldRanges[i].symbol().color()
            rangeList.append(self.makeSymbologyForRange(minVal, maxVal, colour))
        renderer = QgsGraduatedSymbolRendererV2(self.animateVar[:10], rangeList)
        renderer.setMode(QgsGraduatedSymbolRendererV2.Custom)
        self.animateLayer.setRendererV2(renderer)
        self.animateLayer.setLayerTransparency(transparency)
        li.refreshLayerSymbology(self.animateLayer)
        
    def changeAnimate(self):
        """
        Display animation data for current slider value.
        
        Get date from slider value; read animation data for date; write to animation file; redisplay.
        """
        try:
            if self._dlg.animationVariableCombo.currentText() == '':
                QSWATUtils.information('Please choose an animation variable', self._gv.isBatch)
                self.resetSlider()
                return
            dat = self.sliderValToDate()
            self._dlg.dateLabel.setText(self.dateToString(dat))
            data = self.resultsData[dat]
            self.animateLayer.startEditing()
            for f in self.animateLayer.getFeatures():
                fid = f.id()
                if self.useHRUs():
                    # May be split HRUs; just use first
                    # This is inadequate for some variables, but no way to know of correct val is sum of vals, mean, etc.
                    sub = int(string.split(f.attribute(QSWATTopology._HRUGIS), ',')[0])
                else:
                    sub = f.attribute(QSWATTopology._SUBBASIN)
                if sub in data:
                    val = data[sub]
                else:
                    if self.useHRUs():
                        ref = 'HRU {0!s}'.format(sub)
                    else:
                        ref = 'subbasin {0!s}'.format(sub)
                    QSWATUtils.error('Cannot get data for {0}: have you run SWAT and saved data since running QSWAT'.format(ref), self._gv.isBatch)
                    return
                if not self.animateLayer.changeAttributeValue(fid, self.animateIndex, val):
                    QSWATUtils.error('Could not set attribute {0} in animation file {1}'.format(self.animateVar, self.animateFile), self._gv.isBatch)
                    self.animating = False
                    return
            self.animateLayer.commitChanges()
            self.animateLayer.triggerRepaint()
            self._dlg.dateLabel.repaint()
        except:
            self.animating = False
            raise
        
        # no longer used
    #===========================================================================
    # def minMax(self, layer, var):
    #     """
    #     Return minimum and maximum of values for var in layer.
    #     
    #     Subbasin values of 0 indicate subbasins upstream from inlets and are ignored.
    #     """
    #     minv = float('inf')
    #     maxv = 0
    #     for f in layer.getFeatures():
    #         sub = f.attribute(QSWATTopology._SUBBASIN)
    #         if sub == 0:
    #             continue
    #         val = f.attribute(var)
    #         minv = min(minv, val)
    #         maxv = max(maxv, val)
    #     # increase/decrease by 1% to ensure no rounding errors cause values to be outside all ranges
    #     maxv *= 1.01
    #     minv *= 0.99
    #     return minv, maxv
    #===========================================================================
    
    def dataList(self, var):
        """Make list of data values for var from resultsData for creating Jenks breaks."""
        res = []
        for subvals in self.resultsData.itervalues():
            res.append(subvals[var])
        return res
    
    def makeSymbologyForRange(self, minv, maxv, colour):
        """Create a range from minv to maxv with the colour."""
        if self.useSubs() or self.useHRUs():
            symbol = QgsFillSymbolV2()
        else:
            props = {'width_expression': QSWATTopology._PENWIDTH}
            symbol = QgsLineSymbolV2.createSimple(props)
        symbol.setColor(colour)
        title = '{0!s} - {1!s}'.format(int(minv + 0.5), int(maxv + 0.5))
        rng = QgsRendererRangeV2(minv, maxv, symbol, title)
        return rng
    
    def chooseColorRamp(self, table, var):
        """Select a colour ramp and whether it should be inverted."""
        rchWater = ['FLOW_INcms', 'FLOW_OUTcms', 'EVAPcms', 'TLOSScms']
        subPrecip = ['PRECIPmm', 'PETmm', 'ETmm']
        subWater = ['SNOMELTmm', 'SWmm', 'PERCmm', 'SURQmm', 'GW_Qmm', 'WYLDmm']
        hruPrecip = ['PRECIPmm', 'SNOWFALLmm', 'PETmm', 'ETmm']
        hruWater = ['SNOWMELTmm', 'IRRmm', 'SW_INITmm', 'SW_ENDmm', 'PERCmm', \
                    'GW_RCHGmm', 'DA_RCHG', 'REVAP', 'SA_IRRmm', 'DA_IRRmm', 'SA_STmm', 'DA_STmm', 'SURQ_GENmm', \
                    'SURQ_CNTmm', 'TLOSSmm', 'LATQ_mm', 'GW_Qmm', 'WYLD_Qmm', 'SNOmm', 'QTILEmm']
        hruPollute = ['SYLDt_ha', 'USLEt_ha', 'ORGNkg_ha', 'ORGPkg_ha', 'SEDPkg_h', 'NSURQkg_ha', 'NLATQkg_ha', \
                      'NO3Lkg_ha', 'NO3GWkg_ha', 'SOLPkg_ha', 'P_GWkg_ha', 'BACTPct', 'BACTLPct', 'TNO3kg/ha', 'LNO3kg/ha']
        style = QgsStyleV2().defaultStyle()
        if table == 'sed' or table == 'wql' or \
        table == 'rch' and var not in rchWater or \
        table == 'sub' and var not in subPrecip and var not in subWater or \
        table == 'hru' and var in hruPollute:
            # sediments and pollutants
            return (style.colorRamp('RdYlGn'), True)
        elif table == 'rch' and var in rchWater or \
        table == 'sub' and var in subWater or \
        table == 'hru' and var in hruWater:
            # water
            return (style.colorRamp('YlGnBu'), False)
        elif table == 'sub' and var in subPrecip or \
        table == 'hru' and var in hruPrecip:
            # precipitation and transpiration:
            return (style.colorRamp('GnBu'), False)
        else:
            return (style.colorRamp('YlOrRd'), False)
            
    def makeResults(self):
        """
        Create a results file and display.
        
        Only creates a new file if the variables have changed.
        If variables unchanged, only makes and writes summary data if necessary.
        """
        if self.table == '':
            QSWATUtils.information('Please choose a SWAT output table', self._gv.isBatch)
            return
        if self._dlg.resultsFileEdit.text() == '':
            QSWATUtils.information('PLease choose a results file', self._gv.isBatch)
            return
        if self._dlg.variableList.count() == 0:
            QSWATUtils.information('Please choose some variables', self._gv.isBatch)
            return
        if len(self._dlg.variableList.selectedItems()) == 0:
            QSWATUtils.information('Please select a variable for display', self._gv.isBatch)
            return
        if not self.setPeriods():
            return
        if not self.resultsFileUpToDate or not self.periodsUpToDate:
            self.readData(True, False, self.table, '', '')
            self.periodsUpToDate = True
        if self.summaryChanged:
            self.summariseData(True)
        if self.resultsFileUpToDate:
            if self.summaryChanged:
                self.updateResultsFile()
        else:
            if self.createResultsFile():
                self.resultsFileUpToDate = True
            else:
                return
        self.colourResultsFile()
               
    def setupAnimate(self):
        """
        Set up for animation.
        
        Collect animation data from database table according to animation variable; 
        set slider minimum and maximum;
        create animation file;
        set speed accoring to spin box;
        set slider at minimum and display data for start time.
        """
        if self._dlg.animationVariableCombo.currentText() == '':
            return
        # can take a while so set a wait cursor
        self._dlg.setCursor(Qt.WaitCursor)
        self._dlg.calculateLabel.setText('Calculating breaks ...')
        self._dlg.repaint()
        try:
            if not self.setPeriods():
                return
            self.readData(False, False, self.table, self._dlg.animationVariableCombo.currentText(), '')
            self.summariseData(False)
            if self.isDaily or self.table == 'wql':
                animateLength = self.periodDays
            elif self.isAnnual:
                animateLength = int(self.periodYears + 0.5)
            else:
                animateLength = int(self.periodMonths + 0.5)
            self._dlg.slider.setMinimum(1)
            self._dlg.slider.setMaximum(animateLength)
            self.createAnimationFile()
            sleep = self._dlg.spinBox.value()
            self.changeSpeed(sleep)
            self.resetSlider()
            self.changeAnimate()
        finally:
            self._dlg.calculateLabel.setText('')
            self._dlg.setCursor(Qt.ArrowCursor)
        
    def doPlay(self):
        """Set animating and not pause."""
        self.animating = True
        self.animationPaused = False
        
    def doPause(self):
        """If animating change pause from on to off, or off to on."""
        if self.animating:
            self.animationPaused = not self.animationPaused
            
    def doRewind(self):
        """Turn off animating and pause and set slider to minimum."""
        self.animating = False
        self.animationPaused = False
        self.resetSlider()
        
    def doStep(self):
        """Move slide one step to right unless at maximum."""
        if self.animating and not self.animationPaused:
            val = self._dlg.slider.value()
            if val < self._dlg.slider.maximum():
                self._dlg.slider.setValue(val + 1)
                
    def animateStepLeft(self):
        """Stop any running animation and if possible move the animation slider one step left."""
        if self._dlg.tabWidget.currentIndex() == 1:
            self.animating = False
            self.animationPaused = False
            val = self._dlg.slider.value()
            if val > self._dlg.slider.minimum():
                self._dlg.slider.setValue(val - 1)
                
    def animateStepRight(self):
        """Stop any running animation and if possible move the animation slider one step right."""
        if self._dlg.tabWidget.currentIndex() == 1:
            self.animating = False
            self.animationPaused = False
            val = self._dlg.slider.value()
            if val < self._dlg.slider.maximum():
                self._dlg.slider.setValue(val + 1)
    
    def changeSpeed(self, val):
        """
        Starts or restarts the timer with speed set to val.
        
        Runs in a try ... except so that timer gets stopped if any exception.
        """
        try:
            self.animateTimer.start(1000 / val)
        except:
            self.animating = False
            self.animateTimer.stop()
            # raise last exception again
            raise
           
    def pressSlider(self):
        """Turn off animating and pause."""
        self.animating = False
        self.animationPaused = False
        
    def resetSlider(self):
        """Move slide to minimum."""
        self._dlg.slider.setValue(self._dlg.slider.minimum())
        
    def sliderValToDate(self):
        """Convert slider value to date."""
        if self.isDaily or self.table == 'wql':
            return self.addDays( self.julianStartDay + self._dlg.slider.value() - 1,  self.startYear)
        elif self.isAnnual:
            return  self.startYear + self._dlg.slider.value() - 1
        else:
            totalMonths =  self.startMonth + self._dlg.slider.value() - 2
            year = totalMonths / 12
            month = totalMonths % 12 + 1
            return ( self.startYear + year) * 100 + month
            
    def addDays(self, days, year):
        """Make Julian date from year + days."""
        leapAdjust = 1 if self.isLeap(year) else 0
        lenYear = 365 + leapAdjust
        if days <= lenYear:
            return (year) * 1000 + days
        else:
            return self.addDays(days - lenYear, year + 1)
            
    def julianToDate(self, day, year):
        """
        Return datetime.date from year and number of days.
        
        The day may exceed the length of year, in which case a later year
        will be returned.
        """
        if day <= 31:
            return date(year, 1, day)
        day -= 31
        leapAdjust = 1 if self.isLeap(year) else 0
        if day <= 28 + leapAdjust:
            return date(year, 2, day)
        day -= 28 + leapAdjust
        if day <= 31:
            return date(year, 3, day)
        day -= 31
        if day <= 30:
            return date(year, 4, day)
        day -= 30
        if day <= 31:
            return date(year, 5, day)
        day -= 31
        if day <= 30:
            return date(year, 6, day)
        day -= 30
        if day <= 31:
            return date(year, 7, day)
        day -= 31
        if day <= 31:
            return date(year, 8, day)
        day -= 31
        if day <= 30:
            return date(year, 9, day)
        day -= 30
        if day <= 31:
            return date(year, 10, day)
        day -= 31
        if day <= 30:
            return date(year, 11, day)
        day -= 30
        if day <= 31:
            return date(year, 12, day)
        else:
            return self.julianToDate(day - 31, year + 1)
        
    def dateToString(self, dat):
        """Convert integer date to string."""
        if self.isDaily or self.table == 'wql':
            return self.julianToDate(dat%1000, dat/1000).strftime("%d %B %Y")
        if self.isAnnual:
            return str(dat)
        return date(dat/100, dat%100, 1).strftime("%B %Y")
    
    def changeSummary(self):
        """Flag change to summary method."""
        self.summaryChanged = True
        
    def changeRivRenderer(self):
        """If user changes the stream renderer, flag to retain colour scheme."""
        if not self.internalChangeToRivRenderer:
            self.keepRivColours = True
        
    def changeSubRenderer(self):
        """If user changes the subbasin renderer, flag to retain colour scheme."""
        if not self.internalChangeToSubRenderer:
            self.keepSubColours = True
        
    def changeHRURenderer(self):
        """If user changes the subbasin renderer, flag to retain colour scheme."""
        if not self.internalChangeToHRURenderer:
            self.keepHRUColours = True
            
    def updateCurrentPlotRow(self, colChanged):
        """
        Update current plot row according to the colChanged index.
        
        If there are no rows, first makes one.
        """
        if not self.plotting():
            return
        indexes = self._dlg.tableWidget.selectedIndexes()
        if not indexes or indexes == []:
            self.doAddPlot()
            indexes = self._dlg.tableWidget.selectedIndexes()
        row = indexes[0].row()
        if colChanged == 0:
            self._dlg.tableWidget.item(row, 0).setText(self.scenario)
        elif colChanged == 1:
            if self._dlg.tableWidget.item(row, 1).text() == '-':
                # observed plot: do not change
                return
            self._dlg.tableWidget.item(row, 1).setText(self.table)
            if self.table == 'hru':
                self._dlg.tableWidget.item(row, 3).setText('')
            else:
                self._dlg.tableWidget.item(row, 3).setText('-')
            self._dlg.tableWidget.item(row, 4).setText('')
        elif colChanged == 2:
            self._dlg.tableWidget.item(row, 2).setText(self._dlg.subPlot.currentText())
            if self._dlg.tableWidget.item(row, 1).text() == 'hru':
                self._dlg.tableWidget.item(row, 3).setText('')
            else:
                self._dlg.tableWidget.item(row, 3).setText('-')
        elif colChanged == 3:
            self._dlg.tableWidget.item(row, 3).setText(self._dlg.hruPlot.currentText())
        else:
            self._dlg.tableWidget.item(row, 4).setText(self._dlg.variablePlot.currentText())
            
    def doAddPlot(self):
        """Add a plot row and make it current."""
        sub = self._dlg.subPlot.currentText()
        hru = self._dlg.hruPlot.currentText()
        size = self._dlg.tableWidget.rowCount()
        if size > 0 and self._dlg.tableWidget.item(size-1, 1).text() == '-':
            # last plot was observed: need to reset variables
            self.table = ''
            self.setVariables()
        var = self._dlg.variablePlot.currentText()
        self._dlg.tableWidget.insertRow(size)
        self._dlg.tableWidget.setItem(size, 0, QTableWidgetItem(self.scenario))
        self._dlg.tableWidget.setItem(size, 1, QTableWidgetItem(self.table))
        self._dlg.tableWidget.setItem(size, 2, QTableWidgetItem(sub))
        self._dlg.tableWidget.setItem(size, 3, QTableWidgetItem(hru))
        self._dlg.tableWidget.setItem(size, 4, QTableWidgetItem(var))
        for col in xrange(5):
            self._dlg.tableWidget.item(size, col).setTextAlignment(Qt.AlignCenter)
        self._dlg.tableWidget.selectRow(size)
        
    def doDelPlot(self):
        """Delete current plot row."""
        indexes = self._dlg.tableWidget.selectedIndexes()
        if not indexes or indexes == []:
            QSWATUtils.information('Please select a row for deletion', self._gv.isBatch)
            return
        row = indexes[0].row()
        if row in xrange(self._dlg.tableWidget.rowCount()):
            self._dlg.tableWidget.removeRow(row)
        
    def doCopyPlot(self):
        """Add a copy of the current plot row and make it current."""
        indexes = self._dlg.tableWidget.selectedIndexes()
        if not indexes or indexes == []:
            QSWATUtils.information('Please select a row to copy', self._gv.isBatch)
            return
        row = indexes[0].row()
        size = self._dlg.tableWidget.rowCount()
        if row in xrange(size):
            self._dlg.tableWidget.insertRow(size)
            for col in xrange(5):
                self._dlg.tableWidget.setItem(size, col, QTableWidgetItem(self._dlg.tableWidget.item(row, col)))
        self._dlg.tableWidget.selectRow(size)
        
    def doUpPlot(self):
        """Move current plot row up 1 place and keep it current."""
        indexes = self._dlg.tableWidget.selectedIndexes()
        if not indexes or indexes == []:
            QSWATUtils.information('Please select a row to move up', self._gv.isBatch)
            return
        row = indexes[0].row()
        if 1 <= row < self._dlg.tableWidget.rowCount():
            for col in xrange(5):
                item = self._dlg.tableWidget.takeItem(row, col)
                self._dlg.tableWidget.setItem(row, col, self._dlg.tableWidget.takeItem(row-1, col))
                self._dlg.tableWidget.setItem(row-1, col, item)
        self._dlg.tableWidget.selectRow(row-1)
                
    def doDownPlot(self):
        """Move current plot row down 1 place and keep it current."""
        indexes = self._dlg.tableWidget.selectedIndexes()
        if not indexes or indexes == []:
            QSWATUtils.information('Please select a row to move down', self._gv.isBatch)
            return
        row = indexes[0].row()
        if 0 <= row < self._dlg.tableWidget.rowCount() - 1:
            for col in xrange(5):
                item = self._dlg.tableWidget.takeItem(row, col)
                self._dlg.tableWidget.setItem(row, col, self._dlg.tableWidget.takeItem(row+1, col))
                self._dlg.tableWidget.setItem(row+1, col, item)
        self._dlg.tableWidget.selectRow(row+1)
        
    def addObervedPlot(self):
        """Add a row for an observed plot, and make it current."""
        if not os.path.exists(self.observedFileName):
            return
        self.setObservedVars()
        size = self._dlg.tableWidget.rowCount()
        self._dlg.tableWidget.insertRow(size)
        self._dlg.tableWidget.setItem(size, 0, QTableWidgetItem('observed'))
        self._dlg.tableWidget.setItem(size, 1, QTableWidgetItem('-'))
        self._dlg.tableWidget.setItem(size, 2, QTableWidgetItem('-'))
        self._dlg.tableWidget.setItem(size, 3, QTableWidgetItem('-'))
        self._dlg.tableWidget.setItem(size, 4, QTableWidgetItem(self._dlg.variablePlot.currentText()))
        for col in xrange(5):
            self._dlg.tableWidget.item(size, col).setTextAlignment(Qt.AlignHCenter)
        self._dlg.tableWidget.selectRow(size)
        
    def setObservedVars(self):
        """Add variables from 1st line of observed data file, ignoring 'date' if it occurs as the first column."""
        with open(self.observedFileName, 'r') as obs:
            line = obs.readline()
        varz = line.split(',')
        if len(varz) == 0:
            QSWATUtils.error('Cannot find variables in first line of observed data file {0}'.format(self.observedFileName), self._gv.isBatch)
            return
        col1 = string.lower(varz[0])
        start = 1 if col1 == 'date' else 0
        self._dlg.variablePlot.clear()
        for var in varz[start:]:
            self._dlg.variablePlot.addItem(var)
            
    def readObservedFile(self, var):
        """
        Read data for var from observed data file, returning a list of data as strings.
        
        Note that dates are not checked even if present in the observed data file.
        """
        result = []
        with open(self.observedFileName, 'r') as obs:
            line = obs.readline()
            varz = line.split(',')
            if len(varz) == 0:
                QSWATUtils.error('Cannot find variables in first line of observed data file {0}'.format(self.observedFileName), self._gv.isBatch)
                return result
            try:
                idx = varz.index(var)
            except:
                QSWATUtils.error('Cannot find variable {0} in first line of observed data file {1}'.format(var, self.observedFileName), self._gv.isBatch)
                return result
            while line:
                line = obs.readline()
                vals = line.split(',')
                if 0 <= idx < len(vals):
                    result.append(vals[idx].strip()) # strip any newline
                else:
                    break # finish if e.g. a blank line
        return result
        
        
    # code from http://danieljlewis.org/files/2010/06/Jenks.pdf
    # described at http://danieljlewis.org/2010/06/07/jenks-natural-breaks-algorithm-in-python/
    # amended following style of http://www.macwright.org/simple-statistics/docs/simple_statistics.html#section-116
 
    @staticmethod
    def getJenksBreaks( dataList, numClass ):
        """Return Jenks breaks for dataList with numClass classes."""
        if not dataList:
            return [], 0
        # Use of sample unfortunate because gives poor animation results.
        # Tends to overestimate lower limit and underestimate upper limit, and areas go white in animation.
        # But can take a long time to calculate!
        # QGIS internal code uses 1000 here but 4000 runs in reasonable time
        maxSize = 4000
        # use a sample if size exceeds maxSize
        size = len(dataList)
        if size > maxSize:
            origSize = size
            size = max(maxSize, size / 10)
            QSWATUtils.loginfo('Jenks breaks: using a sample of size {0!s} from {1!s}'.format(size, origSize))
            sample = random.sample(dataList, size)
        else:
            sample = dataList
        sample.sort()
        # at most one class: return singleton list
        if numClass <= 1:
            return [sample.last()]
        if numClass >= size:
            # nothing useful to do
            return sample
        lowerClassLimits = []
        varianceCombinations = []
        variance = 0
        for i in range(0,size+1):
            temp1 = []
            temp2 = []
            # initialize with lists of zeroes
            for j in range(0,numClass+1):
                temp1.append(0)
                temp2.append(0)
            lowerClassLimits.append(temp1)
            varianceCombinations.append(temp2)
        for i in range(1,numClass+1):
            lowerClassLimits[1][i] = 1
            varianceCombinations[1][i] = 0
            for j in range(2,size+1):
                varianceCombinations[j][i] = float('inf')
        for l in range(2,size+1):
            # sum of values seen so far
            summ = 0
            # sum of squares of values seen so far
            sumSquares = 0
            # for each potential number of classes. w is the number of data points considered so far
            w = 0
            i4 = 0
            for m in range(1,l+1):
                lowerClassLimit = l - m + 1
                val = float(sample[lowerClassLimit-1])
                w += 1
                summ += val
                sumSquares += val * val
                variance = sumSquares - (summ * summ) / w
                i4 = lowerClassLimit - 1
                if i4 != 0:
                    for j in range(2,numClass+1):
                        # if adding this element to an existing class will increase its variance beyond the limit, 
                        # break the class at this point, setting the lower_class_limit.
                        if varianceCombinations[l][j] >= (variance + varianceCombinations[i4][j - 1]):
                            lowerClassLimits[l][j] = lowerClassLimit
                            varianceCombinations[l][j] = variance + varianceCombinations[i4][j - 1]
            lowerClassLimits[l][1] = 1
            varianceCombinations[l][1] = variance
        k = size
        kclass = []
        for i in range(0,numClass+1):
            kclass.append(0)
        kclass[numClass] = float(sample[size - 1])
        countNum = numClass
        while countNum >= 2:#print "rank = " + str(lowerClassLimits[k][countNum])
            idx = int((lowerClassLimits[k][countNum]) - 2)
            #print "val = " + str(sample[idx])
            kclass[countNum - 1] = sample[idx]
            k = int((lowerClassLimits[k][countNum] - 1))
            countNum -= 1
        return kclass, sample[0]
    
    # copied like above but not used
#===============================================================================
#     @staticmethod
#     def getGVF( sample, numClass ):
#         """
#         The Goodness of Variance Fit (GVF) is found by taking the
#         difference between the squared deviations
#         from the array mean (SDAM) and the squared deviations from the
#         class means (SDCM), and dividing by the SDAM
#         """
#         breaks = Visualise.getJenksBreaks(sample, numClass)
#         sample.sort()
#         size = len(sample)
#         listMean = sum(sample)/size
#         print listMean
#         SDAM = 0.0
#         for i in range(0,size):
#             sqDev = (sample[i] - listMean)**2
#             SDAM += sqDev
#         SDCM = 0.0
#         for i in range(0,numClass):
#             if breaks[i] == 0:
#                 classStart = 0
#             else:
#                 classStart = sample.index(breaks[i])
#             classStart += 1
#             classEnd = sample.index(breaks[i+1])
#             classList = sample[classStart:classEnd+1]
#         classMean = sum(classList)/len(classList)
#         print classMean
#         preSDCM = 0.0
#         for j in range(0,len(classList)):
#             sqDev2 = (classList[j] - classMean)**2
#             preSDCM += sqDev2
#             SDCM += preSDCM
#         return (SDAM - SDCM)/SDAM
# 
#     # written by Drew
#     # used after running getJenksBreaks()
#     @staticmethod
#     def classify(value, breaks):
#         """
#         Return index of value in breaks.
#         
#         Returns i such that
#         breaks = [] and i = -1, or
#         value < breaks[1] and i = 1, or 
#         breaks[i-1] <= value < break[i], or
#         value >= breaks[len(breaks) - 1] and i = len(breaks) - 1
#         """
#         for i in range(1, len(breaks)):
#             if value < breaks[i]:
#                 return i
#         return len(breaks) - 1 
#===============================================================================


       
    
