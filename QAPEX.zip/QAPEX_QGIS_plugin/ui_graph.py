# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_graph.ui'
#
# Created: Sat Jan 09 18:26:00 2016
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_GraphDlg(object):
    def setupUi(self, GraphDlg):
        GraphDlg.setObjectName(_fromUtf8("GraphDlg"))
        GraphDlg.resize(1118, 590)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/plugins/qswat/QSWAT-Icon/QSWAT-Icon-SWAT-16.ico")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        GraphDlg.setWindowIcon(icon)
        GraphDlg.setSizeGripEnabled(True)
        self.gridLayout = QtGui.QGridLayout(GraphDlg)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.table = QtGui.QTableWidget(GraphDlg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.table.sizePolicy().hasHeightForWidth())
        self.table.setSizePolicy(sizePolicy)
        self.table.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setObjectName(_fromUtf8("table"))
        self.table.setColumnCount(0)
        self.table.setRowCount(0)
        self.table.verticalHeader().setVisible(False)
        self.gridLayout.addWidget(self.table, 3, 1, 1, 1)
        self.widget = QtGui.QWidget(GraphDlg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.widget.sizePolicy().hasHeightForWidth())
        self.widget.setSizePolicy(sizePolicy)
        self.widget.setMinimumSize(QtCore.QSize(201, 251))
        self.widget.setFocusPolicy(QtCore.Qt.WheelFocus)
        self.widget.setObjectName(_fromUtf8("widget"))
        self.newFile = QtGui.QPushButton(self.widget)
        self.newFile.setGeometry(QtCore.QRect(20, 90, 82, 23))
        self.newFile.setObjectName(_fromUtf8("newFile"))
        self.closeForm = QtGui.QPushButton(self.widget)
        self.closeForm.setGeometry(QtCore.QRect(110, 90, 75, 23))
        self.closeForm.setObjectName(_fromUtf8("closeForm"))
        self.lineOrBar = QtGui.QComboBox(self.widget)
        self.lineOrBar.setGeometry(QtCore.QRect(20, 50, 82, 20))
        self.lineOrBar.setMaxVisibleItems(2)
        self.lineOrBar.setObjectName(_fromUtf8("lineOrBar"))
        self.label = QtGui.QLabel(self.widget)
        self.label.setGeometry(QtCore.QRect(20, 30, 82, 16))
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName(_fromUtf8("label"))
        self.updateButton = QtGui.QPushButton(self.widget)
        self.updateButton.setGeometry(QtCore.QRect(110, 50, 75, 23))
        self.updateButton.setObjectName(_fromUtf8("updateButton"))
        self.gridLayout.addWidget(self.widget, 3, 2, 2, 1)
        self.coeffs = QtGui.QTextBrowser(GraphDlg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.coeffs.sizePolicy().hasHeightForWidth())
        self.coeffs.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Segoe UI"))
        font.setPointSize(9)
        self.coeffs.setFont(font)
        self.coeffs.setObjectName(_fromUtf8("coeffs"))
        self.gridLayout.addWidget(self.coeffs, 4, 1, 1, 1)
        self.graph = QtGui.QWidget(GraphDlg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.graph.sizePolicy().hasHeightForWidth())
        self.graph.setSizePolicy(sizePolicy)
        self.graph.setObjectName(_fromUtf8("graph"))
        self.graphvl = QtGui.QVBoxLayout(self.graph)
        self.graphvl.setMargin(0)
        self.graphvl.setObjectName(_fromUtf8("graphvl"))
        self.gridLayout.addWidget(self.graph, 2, 1, 1, 2)

        self.retranslateUi(GraphDlg)
        QtCore.QMetaObject.connectSlotsByName(GraphDlg)

    def retranslateUi(self, GraphDlg):
        GraphDlg.setWindowTitle(QtGui.QApplication.translate("GraphDlg", "SWATGraph", None, QtGui.QApplication.UnicodeUTF8))
        self.newFile.setText(QtGui.QApplication.translate("GraphDlg", "New File to Plot", None, QtGui.QApplication.UnicodeUTF8))
        self.closeForm.setText(QtGui.QApplication.translate("GraphDlg", "Close", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("GraphDlg", "Chart Type", None, QtGui.QApplication.UnicodeUTF8))
        self.updateButton.setText(QtGui.QApplication.translate("GraphDlg", "Update", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
