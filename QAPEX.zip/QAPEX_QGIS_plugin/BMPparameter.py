# -*- coding: utf-8 -*-

# Import the PyQt and QGIS libraries
from PyQt4.QtCore import * # @UnusedWildImport
from PyQt4.QtGui import * # @UnusedWildImport
from qgis.core import * # @UnusedWildImport
# Import the code for the dialog
from BMPparameterdialog import BMPParameterDialog
import takeapex, Termdict
from QSWATUtils import QSWATUtils
import os.path, re



class BMPParameter(QObject):

    def __init__(self, iface, gv):
        QObject.__init__(self)
        self._iface = iface
        self._gv = gv
        self._dlg = BMPParameterDialog()
        self._dlg.setWindowFlags(self._dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self._set = takeapex.SuperClass()
        
        self._dict = Termdict.Term_Dict()
        self._Des_dict = self._dict._Des_dict

    def init(self):
        """Set connections to controls."""
        settings = QSettings()

        #HLU Combobox add
        self._dlg.comboBox.clear()
        BMPParameter._path = self._gv.projDir
        f = open(BMPParameter._path+"/Source/MDB_path.txt", "r")
        BMPParameter._MDB_path = f.readline()
        f.close()
        
        Read = self._set.Read_MDB(BMPParameter._MDB_path, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(BMPParameter._path+"/Scenarios/sample/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x] #g_line[1] = WINAPEX.SUB

        f = open(BMPParameter._path+"/Scenarios/sample/"+g_line[1],"r")
        f_lines = f.readlines()
        f.close()
        
        count = 0
        self._Subbasin_sub = []
        self._Subbasin_list = [[x,[]] for x in range(1, len(f_lines)/12+1)]
        for n in range(0,len(f_lines)):
            count += 1
            if count % 12 == 1:
                if count + 5 <len(f_lines):
                    f_line_strip = f_lines[n].strip().split(" ")
                    f_line = [x for x in f_line_strip if x]

                    self._Subbasin_list[int(f_line[5])-1][1].append(f_line[0])
                    self._Subbasin_sub.append(int(f_line[5]))
        self._Subbasin_sub = list(set(self._Subbasin_sub))
        self._Subbasin_sub.sort()

        for Subbasin in self._Subbasin_sub:
            self._dlg.comboBox.addItem(str(Subbasin))

        count = 0
        for remove_list in self._Subbasin_list:
            count += 1
            if count > len(self._Subbasin_sub):
                self._Subbasin_list.remove(self._Subbasin_list[count-1])

        self._dlg.comboBox.currentIndexChanged.connect(self.Subbasin_set)
        self._dlg.Set_push.clicked.connect(self.APEXSUB_set)
        self._dlg.listWidget.itemSelectionChanged.connect(self.Select_BMP)
        self._dlg.Save_pushButton.clicked.connect(self.doSave)
        self._dlg.Cancel_pushButton.clicked.connect(self.doClose)
        self._dlg.Notes_push.clicked.connect(self.Describe)


    def run(self):
        self.init()

        self._dlg.CheckDam_Group.setVisible(False)
        self._dlg.DiversionDike_Group.setVisible(False)
        self._dlg.FilterStrips_Group.setVisible(False)
        self._dlg.GradeStabilizationStructure_Group.setVisible(False)
        self._dlg.GrassedWaterway_Group.setVisible(False)
        self._dlg.RainGarden_Group.setVisible(False)
        self._dlg.PipeSlopeDrain_Group.setVisible(False)
        self._dlg.SedimentBasin_Group.setVisible(False)
        self._dlg.SiltFence_Group.setVisible(False)
        self._dlg.Terraces_Group.setVisible(False)
        self._dlg.TriangularSedimentDike_Group.setVisible(False)
        self._dlg.WetlandCreation_Group.setVisible(False)
        self._dlg.show()

        result = self._dlg.exec_()  # @UnusedVariable
        self._gv.delineatePos = self._dlg.pos()
        self._gv.writeMasterProgress(0,0)
        return 0

    def Subbasin_set(self):
        self._dlg.HLU_comboBox.clear()
        self._Subbasin_num = str(self._dlg.comboBox.currentText())
        #HRU_sub = [HRU_1, HRU_2, ... , HRU_9999]
        #Subbasin_sub = [Subbasin_1, Subbasin_2, ... , Subbasin_9999]
        #Subbasin_list = [[subbasin_1, [HRU_1, HRU_2], [subbasin_2, [HRU_1, HRU_2, HRU_3]]]        for Subbasin in Subbasin_list

        for Subbasin in self._Subbasin_list:
            if str(Subbasin[0]) == self._Subbasin_num:
                for Subbasin_add in Subbasin[1]:
                    self._dlg.HLU_comboBox.addItem(str(Subbasin_add))
        self._dlg.HLU_comboBox.setCurrentIndex(0)

    def Select_BMP(self):
        self._BMP = self._dlg.listWidget.currentItem()

        #self._dlg.Subarea_Group.setVisible(True)
        self._dlg.CheckDam_Group.setVisible(False)
        self._dlg.DiversionDike_Group.setVisible(False)
        self._dlg.FilterStrips_Group.setVisible(False)
        self._dlg.GradeStabilizationStructure_Group.setVisible(False)
        self._dlg.GrassedWaterway_Group.setVisible(False)
        self._dlg.RainGarden_Group.setVisible(False)
        self._dlg.PipeSlopeDrain_Group.setVisible(False)
        self._dlg.SedimentBasin_Group.setVisible(False)
        self._dlg.SiltFence_Group.setVisible(False)
        self._dlg.Terraces_Group.setVisible(False)
        self._dlg.TriangularSedimentDike_Group.setVisible(False)
        self._dlg.WetlandCreation_Group.setVisible(False)

        if self._BMP.text() == "Check Dam":
            self._dlg.CheckDam_Group.setVisible(True)
        elif self._BMP.text() == "Diversion Dike":
            self._dlg.DiversionDike_Group.setVisible(True)
        elif self._BMP.text() == "Filter Strips":
            self._dlg.FilterStrips_Group.setVisible(True)            
        elif self._BMP.text() == "Grade Stabilization Structure":
            self._dlg.GradeStabilizationStructure_Group.setVisible(True)            
        elif self._BMP.text() == "Grassed Waterway":
            self._dlg.GrassedWaterway_Group.setVisible(True)            
        elif self._BMP.text() == "Interceptor Swale/Rain Garden":
            self._dlg.RainGarden_Group.setVisible(True)            
        elif self._BMP.text() == "Pipe Slope Drain":
            self._dlg.PipeSlopeDrain_Group.setVisible(True)            
        elif self._BMP.text() == "Sediment Basin":
            self._dlg.SedimentBasin_Group.setVisible(True)            
        elif self._BMP.text() == "Silt Fence":
            self._dlg.SiltFence_Group.setVisible(True)            
        elif self._BMP.text() == "Terraces":
            self._dlg.Terraces_Group.setVisible(True)            
        elif self._BMP.text() == "Triangular Sediment Dike":
            self._dlg.TriangularSedimentDike_Group.setVisible(True)            
        elif self._BMP.text() == "Wetland Creation":
            self._dlg.WetlandCreation_Group.setVisible(True)


    def doSave(self):
        #Read WINAPEX.SUB
        Read = self._set.Read_MDB(BMPParameter._MDB_path, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(BMPParameter._path+"/Scenarios/sample/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x] #g_line[1] = WINAPEX.SUB

        f = open(BMPParameter._path+"/Scenarios/sample/"+g_line[1],"r")
        lines = f.readlines()
        f.close()

        os.remove(BMPParameter._path+"/Scenarios/sample/"+g_line[1])
        
        #Change the BMP Parameter
        for n in range(0, len(lines)):
            if (n % 12 == 0 and len(lines) > n+7):
                g_1_strip = lines[n].strip().split(" ")
                g_1 = [x for x in g_1_strip if x]
                
                if str(g_1[0]) == self._num:
                    g_2_strip = lines[n+1].strip().split(" ")
                    g_3_strip = lines[n+2].strip().split(" ")
                    g_4_strip = lines[n+3].strip().split(" ")
                    g_5_strip = lines[n+4].strip().split(" ")
                    g_6_strip = lines[n+5].strip().split(" ")
                    g_7_strip = lines[n+6].strip().split(" ")
                    g_8_strip = lines[n+7].strip().split(" ")
                    g_9_strip = lines[n+8].strip().split(" ")
                    g_10_strip = lines[n+9].strip().split(" ")
                    g_11_strip = lines[n+10].strip().split(" ")
                    g_12_strip = lines[n+11].strip().split(" ")
                    g_2 = [x for x in g_2_strip if x]
                    g_3 = [x for x in g_3_strip if x]
                    g_4 = [x for x in g_4_strip if x]
                    g_5 = [x for x in g_5_strip if x]
                    g_6 = [x for x in g_6_strip if x]
                    g_7 = [x for x in g_7_strip if x]
                    g_8 = [x for x in g_8_strip if x]
                    g_9 = [x for x in g_9_strip if x]
                    g_10 = [x for x in g_10_strip if x]
                    g_11 = [x for x in g_11_strip if x]
                    g_12 = [x for x in g_12_strip if x]

                    self._BMP_parm = [g_1, g_2, g_3, g_4, g_5, g_6, g_7, g_8, g_9, g_10, g_11, g_12]
                    
        #self._BMP_parm = [[0, 0, 0, 0, 0, 0, 0, 0, 0]]
        
        #(BMP_sub[0][2] = self._dlg.XTP1_line.text())
        f = open("d:/before.txt", "w")
        f.write(str(self._BMP_parm))
        f.close()
                    
        if self._BMP.text() == "Check Dam":
            self._BMP_parm[5][0] = self._dlg.CheckDam_line_RSEE.text()
            self._BMP_parm[5][1] = self._dlg.CheckDam_line_RSAE.text()
            self._BMP_parm[5][2] = self._dlg.CheckDam_line_RSVE.text()
            self._BMP_parm[5][3] = self._dlg.CheckDam_line_RSEP.text()
            self._BMP_parm[5][4] = self._dlg.CheckDam_line_RSAP.text()
            self._BMP_parm[5][5] = self._dlg.CheckDam_line_RSVP.text()
            self._BMP_parm[5][6] = self._dlg.CheckDam_line_RSV.text()
            self._BMP_parm[5][7] = self._dlg.CheckDam_line_RSRR.text()
            self._BMP_parm[5][8] = self._dlg.CheckDam_line_RSYS.text()
            self._BMP_parm[5][9] = self._dlg.CheckDam_line_RSYN.text()
            self._BMP_parm[6][0] = self._dlg.CheckDam_line_RSHC.text()
            self._BMP_parm[6][1] = self._dlg.CheckDam_line_RSDP.text()
            self._BMP_parm[6][2] = self._dlg.CheckDam_line_RSBD.text()
            
        elif self._BMP.text() == "Diversion Dike":
            self._BMP_parm[4][0] = self._dlg.DiversionDike_line_RCHL.text()
            self._BMP_parm[4][1] = self._dlg.DiversionDike_line_RCHD.text()
            self._BMP_parm[5][2] = self._dlg.DiversionDike_line_RSVE.text()
            self._BMP_parm[5][3] = self._dlg.DiversionDike_line_RSEP.text()
            self._BMP_parm[5][4] = self._dlg.DiversionDike_line_RSAP.text()
            
        elif self._BMP.text() == "Filter Strips":
            self._BMP_parm[3][1] = self._dlg.FilterStrips_line_CHL.text()
            self._BMP_parm[3][2] = self._dlg.FilterStrips_line_CHD.text()
            self._BMP_parm[3][3] = self._dlg.FilterStrips_line_CHS.text()
            self._BMP_parm[3][4] = self._dlg.FilterStrips_line_CHN.text()
            self._BMP_parm[3][5] = self._dlg.FilterStrips_line_SLP.text()
            self._BMP_parm[3][6] = self._dlg.FilterStrips_line_SPLG.text()
            self._BMP_parm[3][7] = self._dlg.FilterStrips_line_UPN.text()
            self._BMP_parm[3][8] = self._dlg.FilterStrips_line_FFPQ.text()
            self._BMP_parm[4][0] = self._dlg.FilterStrips_line_RCHL.text()
            self._BMP_parm[4][1] = self._dlg.FilterStrips_line_RCHD.text()
            self._BMP_parm[4][2] = self._dlg.FilterStrips_line_RCBW.text()
            self._BMP_parm[4][3] = self._dlg.FilterStrips_line_RCTW.text()
            self._BMP_parm[4][4] = self._dlg.FilterStrips_line_RCHS.text()
            self._BMP_parm[4][5] = self._dlg.FilterStrips_line_RCHN.text()
            self._BMP_parm[4][6] = self._dlg.FilterStrips_line_RCHC.text()
            self._BMP_parm[4][7] = self._dlg.FilterStrips_line_RCHK.text()
            self._BMP_parm[4][8] = self._dlg.FilterStrips_line_RFPW.text()
            self._BMP_parm[4][9] = self._dlg.FilterStrips_line_RFPL.text()
            self._BMP_parm[6][4] = self._dlg.FilterStrips_line_BCOF.text()
            self._BMP_parm[6][5] = self._dlg.FilterStrips_line_BWTH.text()
            self._BMP_parm[1][1] = self._dlg.FilterStrips_line_IOPS.text()
            self._BMP_parm[1][10] = self._dlg.FilterStrips_line_LUNS.text()
            
        elif self._BMP.text() == "Grade Stabilization Structure":
            self._BMP_parm[4][4] = self._dlg.GradeStabilizationStructure_line_RCHS.text()
            
        elif self._BMP.text() == "Grassed Waterway":
            self._BMP_parm[4][1] = self._dlg.GrassedWaterway_line_RCHD.text()
            self._BMP_parm[4][2] = self._dlg.GrassedWaterway_line_RCBW.text()
            self._BMP_parm[4][3] = self._dlg.GrassedWaterway_line_RCTW.text()
            self._BMP_parm[4][4] = self._dlg.GrassedWaterway_line_RCHS.text()
            self._BMP_parm[4][5] = self._dlg.GrassedWaterway_line_RCHN.text()
            self._BMP_parm[4][6] = self._dlg.GrassedWaterway_line_RCHC.text()
            self._BMP_parm[4][7] = self._dlg.GrassedWaterway_line_RCHK.text()
            self._BMP_parm[1][1] = self._dlg.GrassedWaterway_line_IOPS.text()
            self._BMP_parm[1][10] = self._dlg.GrassedWaterway_line_LUNS.text()
            
        elif self._BMP.text() == "Interceptor Swale/Rain Garden":
            self._BMP_parm[3][1] = self._dlg.RainGarden_line_CHL.text()
            self._BMP_parm[3][2] = self._dlg.RainGarden_line_CHD.text()
            self._BMP_parm[3][3] = self._dlg.RainGarden_line_CHS.text()
            self._BMP_parm[3][4] = self._dlg.RainGarden_line_CHN.text()
            self._BMP_parm[3][5] = self._dlg.RainGarden_line_SLP.text()
            self._BMP_parm[3][6] = self._dlg.RainGarden_line_SPLG.text()
            self._BMP_parm[3][7] = self._dlg.RainGarden_line_UPN.text()
            self._BMP_parm[3][8] = self._dlg.RainGarden_line_FFPQ.text()
            self._BMP_parm[4][0] = self._dlg.RainGarden_line_RCHL.text()
            self._BMP_parm[4][1] = self._dlg.RainGarden_line_RCHD.text()
            self._BMP_parm[4][2] = self._dlg.RainGarden_line_RCBW.text()
            self._BMP_parm[4][3] = self._dlg.RainGarden_line_RCTW.text()
            self._BMP_parm[4][4] = self._dlg.RainGarden_line_RCHS.text()
            self._BMP_parm[4][5] = self._dlg.RainGarden_line_RCHN.text()
            self._BMP_parm[4][6] = self._dlg.RainGarden_line_RCHC.text()
            self._BMP_parm[4][7] = self._dlg.RainGarden_line_RCHK.text()
            self._BMP_parm[4][8] = self._dlg.RainGarden_line_RFPW.text()
            self._BMP_parm[4][9] = self._dlg.RainGarden_line_RFPL.text()
            self._BMP_parm[7][5] = self._dlg.RainGarden_line_IDR.text()
            self._BMP_parm[8][8] = self._dlg.RainGarden_line_DRT.text()
            self._BMP_parm[1][1] = self._dlg.RainGarden_line_IOPS.text()
            self._BMP_parm[1][10] = self._dlg.RainGarden_line_LUNS.text()
            
        elif self._BMP.text() == "Pipe Slope Drain":
            self._BMP_parm[1][9] = self._dlg.PipeSlopeDrain_line_ISAO.text()
            
        elif self._BMP.text() == "Sediment Basin":
            self._BMP_parm[5][0] = self._dlg.SedimentBasin_line_RSEE.text()
            self._BMP_parm[5][1] = self._dlg.SedimentBasin_line_RSAE.text()
            self._BMP_parm[5][2] = self._dlg.SedimentBasin_line_RSVE.text()
            self._BMP_parm[5][3] = self._dlg.SedimentBasin_line_RSEP.text()
            self._BMP_parm[5][4] = self._dlg.SedimentBasin_line_RSAP.text()
            self._BMP_parm[5][5] = self._dlg.SedimentBasin_line_RSVP.text()
            self._BMP_parm[5][6] = self._dlg.SedimentBasin_line_RSV.text()
            self._BMP_parm[5][7] = self._dlg.SedimentBasin_line_RSRR.text()
            self._BMP_parm[5][8] = self._dlg.SedimentBasin_line_RSYS.text()
            self._BMP_parm[5][9] = self._dlg.SedimentBasin_line_RSYN.text()
            self._BMP_parm[6][0] = self._dlg.SedimentBasin_line_RSHC.text()
            self._BMP_parm[6][1] = self._dlg.SedimentBasin_line_RSDP.text()
            self._BMP_parm[6][2] = self._dlg.SedimentBasin_line_RSBD.text()
            self._BMP_parm[6][3] = self._dlg.SedimentBasin_line_PCOF.text()
          
        elif self._BMP.text() == "Silt Fence":
            self._BMP_parm[5][0] = self._dlg.SiltFence_line_RSEE.text()
            self._BMP_parm[5][1] = self._dlg.SiltFence_line_RSAE.text()
            self._BMP_parm[5][2] = self._dlg.SiltFence_line_RSVE.text()
            self._BMP_parm[5][3] = self._dlg.SiltFence_line_RSEP.text()
            self._BMP_parm[5][4] = self._dlg.SiltFence_line_RSAP.text()
            self._BMP_parm[5][5] = self._dlg.SiltFence_line_RSVP.text()
            self._BMP_parm[5][6] = self._dlg.SiltFence_line_RSV.text()
            self._BMP_parm[5][7] = self._dlg.SiltFence_line_RSRR.text()
            self._BMP_parm[5][8] = self._dlg.SiltFence_line_RSYS.text()
            self._BMP_parm[5][9] = self._dlg.SiltFence_line_RSYN.text()
            self._BMP_parm[6][0] = self._dlg.SiltFence_line_RSHC.text()
            self._BMP_parm[6][1] = self._dlg.SiltFence_line_RSDP.text()
            self._BMP_parm[6][2] = self._dlg.SiltFence_line_RSBD.text()
            
        elif self._BMP.text() == "Terraces":
            self._BMP_parm[3][1] = self._dlg.Terraces_line_CHL.text()
            self._BMP_parm[3][2] = self._dlg.Terraces_line_CHD.text()
            self._BMP_parm[3][3] = self._dlg.Terraces_line_CHS.text()
            self._BMP_parm[3][4] = self._dlg.Terraces_line_CHN.text()
            self._BMP_parm[3][5] = self._dlg.Terraces_line_SLP.text()
            self._BMP_parm[3][6] = self._dlg.Terraces_line_SPLG.text()
            self._BMP_parm[3][7] = self._dlg.Terraces_line_UPN.text()
            self._BMP_parm[4][0] = self._dlg.Terraces_line_RCHL.text()
            self._BMP_parm[4][1] = self._dlg.Terraces_line_RCHD.text()
            self._BMP_parm[4][2] = self._dlg.Terraces_line_RCBW.text()
            self._BMP_parm[4][3] = self._dlg.Terraces_line_RCTW.text()
            self._BMP_parm[4][4] = self._dlg.Terraces_line_RCHS.text()
            self._BMP_parm[4][5] = self._dlg.Terraces_line_RCHN.text()
            self._BMP_parm[4][6] = self._dlg.Terraces_line_RCHC.text()
            self._BMP_parm[4][7] = self._dlg.Terraces_line_RCHK.text()
            self._BMP_parm[9][0] = self._dlg.Terraces_line_PEC.text()
            self._BMP_parm[1][10] = self._dlg.Terraces_line_LUNS.text()
            
        elif self._BMP.text() == "Triangular Sediment Dike":
            self._BMP_parm[5][0] = self._dlg.TriangularSedimentDike_line_RSEE.text()
            self._BMP_parm[5][1] = self._dlg.TriangularSedimentDike_line_RSAE.text()
            self._BMP_parm[5][2] = self._dlg.TriangularSedimentDike_line_RSVE.text()
            self._BMP_parm[5][3] = self._dlg.TriangularSedimentDike_line_RSEP.text()
            self._BMP_parm[5][4] = self._dlg.TriangularSedimentDike_line_RSAP.text()
            self._BMP_parm[5][5] = self._dlg.TriangularSedimentDike_line_RSVP.text()
            self._BMP_parm[5][6] = self._dlg.TriangularSedimentDike_line_RSV.text()
            self._BMP_parm[5][7] = self._dlg.TriangularSedimentDike_line_RSRR.text()
            self._BMP_parm[5][8] = self._dlg.TriangularSedimentDike_line_RSYS.text()
            self._BMP_parm[5][9] = self._dlg.TriangularSedimentDike_line_RSYN.text()
            self._BMP_parm[6][0] = self._dlg.TriangularSedimentDike_line_RSHC.text()
            self._BMP_parm[6][1] = self._dlg.TriangularSedimentDike_line_RSDP.text()
            self._BMP_parm[6][2] = self._dlg.TriangularSedimentDike_line_RSBD.text()
            
        elif self._BMP.text() == "Wetland Creation":
            self._BMP_parm[5][0] = self._dlg.WetlandCreation_line_RSEE.text()
            self._BMP_parm[5][1] = self._dlg.WetlandCreation_line_RSAE.text()
            self._BMP_parm[5][2] = self._dlg.WetlandCreation_line_RSVE.text()
            self._BMP_parm[5][3] = self._dlg.WetlandCreation_line_RSEP.text()
            self._BMP_parm[5][4] = self._dlg.WetlandCreation_line_RSAP.text()
            self._BMP_parm[5][5] = self._dlg.WetlandCreation_line_RSVP.text()
            self._BMP_parm[5][6] = self._dlg.WetlandCreation_line_RSV.text()
            self._BMP_parm[5][7] = self._dlg.WetlandCreation_line_RSRR.text()
            self._BMP_parm[5][8] = self._dlg.WetlandCreation_line_RSYS.text()
            self._BMP_parm[5][9] = self._dlg.WetlandCreation_line_RSYN.text()
            self._BMP_parm[6][0] = self._dlg.WetlandCreation_line_RSHC.text()
            self._BMP_parm[6][1] = self._dlg.WetlandCreation_line_RSDP.text()
            self._BMP_parm[6][2] = self._dlg.WetlandCreation_line_RSBD.text()
            self._BMP_parm[1][1] = self._dlg.WetlandCreation_line_IOPS.text()
            self._BMP_parm[1][10] = self._dlg.WetlandCreation_line_LUNS.text()

        g = open("d:/after.txt", "w")
        g.write(str(self._BMP_parm))
        g.close()

        except_num = -12
        g = open(BMPParameter._path+"/Scenarios/sample/"+g_line[1],"a")
        for n in range(0, len(lines)):
            if (n % 12 == 0 and len(lines) > n+7):
                g_1_strip = lines[n].strip().split(" ")
                g_1 = [x for x in g_1_strip if x]
                
                if str(g_1[0]) == self._num:
                    except_num = n
                    g.write("{:>8d}{:>8d}{:>8d} {}  {} ! {}\n".format(int(self._BMP_parm[0][0]),int(self._BMP_parm[0][1]),int(self._BMP_parm[0][2]),self._BMP_parm[0][3]+" "+self._BMP_parm[0][4],int(self._BMP_parm[0][5]),self._BMP_parm[0][6]))
                    g.write("{:>8d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}\n".format(int(self._BMP_parm[1][0]),int(self._BMP_parm[1][1]),int(self._BMP_parm[1][2]),int(self._BMP_parm[1][3]),int(self._BMP_parm[1][4]),int(self._BMP_parm[1][5]),int(self._BMP_parm[1][6]),int(self._BMP_parm[1][7]),int(self._BMP_parm[1][8]),int(self._BMP_parm[1][9]),int(self._BMP_parm[1][10]),int(self._BMP_parm[1][11])))
                    g.write("{:>12.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(float(self._BMP_parm[2][0]),float(self._BMP_parm[2][1]),float(self._BMP_parm[2][2]),float(self._BMP_parm[2][3]),float(self._BMP_parm[2][4]),float(self._BMP_parm[2][5]),float(self._BMP_parm[2][6]),float(self._BMP_parm[2][7])))
                    g.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.4f}{:>13.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._BMP_parm[3][0]),float(self._BMP_parm[3][1]),float(self._BMP_parm[3][2]),float(self._BMP_parm[3][3]),float(self._BMP_parm[3][4]),float(self._BMP_parm[3][5]),float(self._BMP_parm[3][6]),float(self._BMP_parm[3][7]),float(self._BMP_parm[3][8]),float(self._BMP_parm[3][9])))
                    g.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.5f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._BMP_parm[4][0]),float(self._BMP_parm[4][1]),float(self._BMP_parm[4][2]),float(self._BMP_parm[4][3]),float(self._BMP_parm[4][4]),float(self._BMP_parm[4][5]),float(self._BMP_parm[4][6]),float(self._BMP_parm[4][7]),float(self._BMP_parm[4][8]),float(self._BMP_parm[4][9])))
                    g.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._BMP_parm[5][0]),float(self._BMP_parm[5][1]),float(self._BMP_parm[5][2]),float(self._BMP_parm[5][3]),float(self._BMP_parm[5][4]),float(self._BMP_parm[5][5]),float(self._BMP_parm[5][6]),float(self._BMP_parm[5][7]),float(self._BMP_parm[5][8]),float(self._BMP_parm[5][9])))
                    g.write("{:>12.6f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._BMP_parm[6][0]),float(self._BMP_parm[6][1]),float(self._BMP_parm[6][2]),float(self._BMP_parm[6][3]),float(self._BMP_parm[6][4]),float(self._BMP_parm[6][5])))
                    g.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(self._BMP_parm[7][0]),int(self._BMP_parm[7][1]),int(self._BMP_parm[7][2]),int(self._BMP_parm[7][3]),int(self._BMP_parm[7][4]),int(self._BMP_parm[7][5]),int(self._BMP_parm[7][6]),int(self._BMP_parm[7][7]),int(self._BMP_parm[7][8]),int(self._BMP_parm[7][9]),int(self._BMP_parm[7][10]),int(self._BMP_parm[7][11]),int(self._BMP_parm[7][12])))
                    g.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._BMP_parm[8][0]),float(self._BMP_parm[8][1]),float(self._BMP_parm[8][2]),float(self._BMP_parm[8][3]),float(self._BMP_parm[8][4]),float(self._BMP_parm[8][5]),float(self._BMP_parm[8][6]),float(self._BMP_parm[8][7]),float(self._BMP_parm[8][8]),float(self._BMP_parm[8][9])))
                    g.write("{:>12.4f}{:>13.2f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(float(self._BMP_parm[9][0]),float(self._BMP_parm[9][1]),float(self._BMP_parm[9][2]),float(self._BMP_parm[9][3]),float(self._BMP_parm[9][4]),float(self._BMP_parm[9][5]),float(self._BMP_parm[9][6]),float(self._BMP_parm[9][7]),float(self._BMP_parm[9][8]),float(self._BMP_parm[9][9])))
                    g.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(self._BMP_parm[10][0]),int(self._BMP_parm[10][1]),int(self._BMP_parm[10][2]),int(self._BMP_parm[10][3]),int(self._BMP_parm[10][4]),int(self._BMP_parm[10][5]),int(self._BMP_parm[10][6]),int(self._BMP_parm[10][7]),int(self._BMP_parm[10][8]),int(self._BMP_parm[10][9])))
                    g.write("{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}\n".format(float(self._BMP_parm[11][0]),float(self._BMP_parm[11][1]),float(self._BMP_parm[11][2]),float(self._BMP_parm[11][3]),float(self._BMP_parm[11][4]),float(self._BMP_parm[11][5]),float(self._BMP_parm[11][6]),float(self._BMP_parm[11][7]),float(self._BMP_parm[11][8]),float(self._BMP_parm[11][9])))
                else:
                    g.write(lines[n])
            elif except_num < n and n < except_num+12:
                continue
            else:
                g.write(lines[n])
        g.close()
        

    def APEXSUB_set(self):
        Read = self._set.Read_MDB(BMPParameter._MDB_path, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(BMPParameter._path+"/Scenarios/sample/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x] #g_line[1] = WINAPEX.SUB

        f = open(BMPParameter._path+"/Scenarios/sample/"+g_line[1],"r")
        lines = f.readlines()
        f.close()

        self._num = str(self._dlg.comboBox.currentText())
        for n in range(0, len(lines)):
            if (n % 12 == 0 and len(lines) > n+7):
                g_1_strip = lines[n].strip().split(" ")
                g_1 = [x for x in g_1_strip if x]
                
                if str(g_1[0]) == self._num:
                    g_2_strip = lines[n+1].strip().split(" ")
                    g_3_strip = lines[n+2].strip().split(" ")
                    g_4_strip = lines[n+3].strip().split(" ")
                    g_5_strip = lines[n+4].strip().split(" ")
                    g_6_strip = lines[n+5].strip().split(" ")
                    g_7_strip = lines[n+6].strip().split(" ")
                    g_8_strip = lines[n+7].strip().split(" ")
                    g_9_strip = lines[n+8].strip().split(" ")
                    g_10_strip = lines[n+9].strip().split(" ")
                    g_11_strip = lines[n+10].strip().split(" ")
                    g_12_strip = lines[n+11].strip().split(" ")
                    g_2 = [x for x in g_2_strip if x]
                    g_3 = [x for x in g_3_strip if x]
                    g_4 = [x for x in g_4_strip if x]
                    g_5 = [x for x in g_5_strip if x]
                    g_6 = [x for x in g_6_strip if x]
                    g_7 = [x for x in g_7_strip if x]
                    g_8 = [x for x in g_8_strip if x]
                    g_9 = [x for x in g_9_strip if x]
                    g_10 = [x for x in g_10_strip if x]
                    g_11 = [x for x in g_11_strip if x]
                    g_12 = [x for x in g_12_strip if x]

                    origin_parm = [g_1, g_2, g_3, g_4, g_5, g_6, g_7, g_8, g_9, g_10, g_11, g_12]


        self._dlg.CheckDam_line_RSEE.setText(origin_parm[5][0])
        self._dlg.CheckDam_line_RSAE.setText(origin_parm[5][1])
        self._dlg.CheckDam_line_RSVE.setText(origin_parm[5][2])
        self._dlg.CheckDam_line_RSEP.setText(origin_parm[5][3])
        self._dlg.CheckDam_line_RSAP.setText(origin_parm[5][4])
        self._dlg.CheckDam_line_RSVP.setText(origin_parm[5][5])
        self._dlg.CheckDam_line_RSV.setText(origin_parm[5][6])
        self._dlg.CheckDam_line_RSRR.setText(origin_parm[5][7])
        self._dlg.CheckDam_line_RSYS.setText(origin_parm[5][8])
        self._dlg.CheckDam_line_RSYN.setText(origin_parm[5][9])
        self._dlg.CheckDam_line_RSHC.setText(origin_parm[6][0])
        self._dlg.CheckDam_line_RSDP.setText(origin_parm[6][1])
        self._dlg.CheckDam_line_RSBD.setText(origin_parm[6][2])
        
        self._dlg.DiversionDike_line_RCHL.setText(origin_parm[4][0])
        self._dlg.DiversionDike_line_RCHD.setText(origin_parm[4][1])
        self._dlg.DiversionDike_line_RSVE.setText(origin_parm[5][2])
        self._dlg.DiversionDike_line_RSEP.setText(origin_parm[5][3])
        self._dlg.DiversionDike_line_RSAP.setText(origin_parm[5][4])
        
        self._dlg.FilterStrips_line_CHL.setText(origin_parm[3][1])
        self._dlg.FilterStrips_line_CHD.setText(origin_parm[3][2])
        self._dlg.FilterStrips_line_CHS.setText(origin_parm[3][3])
        self._dlg.FilterStrips_line_CHN.setText(origin_parm[3][4])
        self._dlg.FilterStrips_line_SLP.setText(origin_parm[3][5])
        self._dlg.FilterStrips_line_SPLG.setText(origin_parm[3][6])
        self._dlg.FilterStrips_line_UPN.setText(origin_parm[3][7])
        self._dlg.FilterStrips_line_FFPQ.setText(origin_parm[3][8])
        self._dlg.FilterStrips_line_RCHL.setText(origin_parm[4][0])
        self._dlg.FilterStrips_line_RCHD.setText(origin_parm[4][1])
        self._dlg.FilterStrips_line_RCBW.setText(origin_parm[4][2])
        self._dlg.FilterStrips_line_RCTW.setText(origin_parm[4][3])
        self._dlg.FilterStrips_line_RCHS.setText(origin_parm[4][4])
        self._dlg.FilterStrips_line_RCHN.setText(origin_parm[4][5])
        self._dlg.FilterStrips_line_RCHC.setText(origin_parm[4][6])
        self._dlg.FilterStrips_line_RCHK.setText(origin_parm[4][7])
        self._dlg.FilterStrips_line_RFPW.setText(origin_parm[4][8])
        self._dlg.FilterStrips_line_RFPL.setText(origin_parm[4][9])
        self._dlg.FilterStrips_line_BCOF.setText(origin_parm[6][4])
        self._dlg.FilterStrips_line_BWTH.setText(origin_parm[6][5])
        self._dlg.FilterStrips_line_IOPS.setText(origin_parm[1][1])
        self._dlg.FilterStrips_line_LUNS.setText(origin_parm[1][10])
        
        self._dlg.GradeStabilizationStructure_line_RCHS.setText(origin_parm[4][4])
        
        self._dlg.GrassedWaterway_line_RCHD.setText(origin_parm[4][1])
        self._dlg.GrassedWaterway_line_RCBW.setText(origin_parm[4][2])
        self._dlg.GrassedWaterway_line_RCTW.setText(origin_parm[4][3])
        self._dlg.GrassedWaterway_line_RCHS.setText(origin_parm[4][4])
        self._dlg.GrassedWaterway_line_RCHN.setText(origin_parm[4][5])
        self._dlg.GrassedWaterway_line_RCHC.setText(origin_parm[4][6])
        self._dlg.GrassedWaterway_line_RCHK.setText(origin_parm[4][7])
        self._dlg.GrassedWaterway_line_IOPS.setText(origin_parm[1][1])
        self._dlg.GrassedWaterway_line_LUNS.setText(origin_parm[1][10])
        
        self._dlg.RainGarden_line_CHL.setText(origin_parm[3][1])
        self._dlg.RainGarden_line_CHD.setText(origin_parm[3][2])
        self._dlg.RainGarden_line_CHS.setText(origin_parm[3][3])
        self._dlg.RainGarden_line_CHN.setText(origin_parm[3][4])
        self._dlg.RainGarden_line_SLP.setText(origin_parm[3][5])
        self._dlg.RainGarden_line_SPLG.setText(origin_parm[3][6])
        self._dlg.RainGarden_line_UPN.setText(origin_parm[3][7])
        self._dlg.RainGarden_line_FFPQ.setText(origin_parm[3][8])
        self._dlg.RainGarden_line_RCHL.setText(origin_parm[4][0])
        self._dlg.RainGarden_line_RCHD.setText(origin_parm[4][1])
        self._dlg.RainGarden_line_RCBW.setText(origin_parm[4][2])
        self._dlg.RainGarden_line_RCTW.setText(origin_parm[4][3])
        self._dlg.RainGarden_line_RCHS.setText(origin_parm[4][4])
        self._dlg.RainGarden_line_RCHN.setText(origin_parm[4][5])
        self._dlg.RainGarden_line_RCHC.setText(origin_parm[4][6])
        self._dlg.RainGarden_line_RCHK.setText(origin_parm[4][7])
        self._dlg.RainGarden_line_RFPW.setText(origin_parm[4][8])
        self._dlg.RainGarden_line_RFPL.setText(origin_parm[4][9])
        self._dlg.RainGarden_line_IDR.setText(origin_parm[7][5])
        self._dlg.RainGarden_line_DRT.setText(origin_parm[8][8])
        self._dlg.RainGarden_line_IOPS.setText(origin_parm[1][1])
        self._dlg.RainGarden_line_LUNS.setText(origin_parm[1][10])
        
        self._dlg.PipeSlopeDrain_line_ISAO.setText(origin_parm[1][9])
        
        self._dlg.SedimentBasin_line_RSEE.setText(origin_parm[5][0])
        self._dlg.SedimentBasin_line_RSAE.setText(origin_parm[5][1])
        self._dlg.SedimentBasin_line_RSVE.setText(origin_parm[5][2])
        self._dlg.SedimentBasin_line_RSEP.setText(origin_parm[5][3])
        self._dlg.SedimentBasin_line_RSAP.setText(origin_parm[5][4])
        self._dlg.SedimentBasin_line_RSVP.setText(origin_parm[5][5])
        self._dlg.SedimentBasin_line_RSV.setText(origin_parm[5][6])
        self._dlg.SedimentBasin_line_RSRR.setText(origin_parm[5][7])
        self._dlg.SedimentBasin_line_RSYS.setText(origin_parm[5][8])
        self._dlg.SedimentBasin_line_RSYN.setText(origin_parm[5][9])
        self._dlg.SedimentBasin_line_RSHC.setText(origin_parm[6][0])
        self._dlg.SedimentBasin_line_RSDP.setText(origin_parm[6][1])
        self._dlg.SedimentBasin_line_RSBD.setText(origin_parm[6][2])
        self._dlg.SedimentBasin_line_PCOF.setText(origin_parm[6][3])
        
        self._dlg.SiltFence_line_RSEE.setText(origin_parm[5][0])
        self._dlg.SiltFence_line_RSAE.setText(origin_parm[5][1])
        self._dlg.SiltFence_line_RSVE.setText(origin_parm[5][2])
        self._dlg.SiltFence_line_RSEP.setText(origin_parm[5][3])
        self._dlg.SiltFence_line_RSAP.setText(origin_parm[5][4])
        self._dlg.SiltFence_line_RSVP.setText(origin_parm[5][5])
        self._dlg.SiltFence_line_RSV.setText(origin_parm[5][6])
        self._dlg.SiltFence_line_RSRR.setText(origin_parm[5][7])
        self._dlg.SiltFence_line_RSYS.setText(origin_parm[5][8])
        self._dlg.SiltFence_line_RSYN.setText(origin_parm[5][9])
        self._dlg.SiltFence_line_RSHC.setText(origin_parm[6][0])
        self._dlg.SiltFence_line_RSDP.setText(origin_parm[6][1])
        self._dlg.SiltFence_line_RSBD.setText(origin_parm[6][2])
        
        self._dlg.Terraces_line_CHL.setText(origin_parm[3][1])
        self._dlg.Terraces_line_CHD.setText(origin_parm[3][2])
        self._dlg.Terraces_line_CHS.setText(origin_parm[3][3])
        self._dlg.Terraces_line_CHN.setText(origin_parm[3][4])
        self._dlg.Terraces_line_SLP.setText(origin_parm[3][5])
        self._dlg.Terraces_line_SPLG.setText(origin_parm[3][6])
        self._dlg.Terraces_line_UPN.setText(origin_parm[3][7])
        self._dlg.Terraces_line_RCHL.setText(origin_parm[4][0])
        self._dlg.Terraces_line_RCHD.setText(origin_parm[4][1])
        self._dlg.Terraces_line_RCBW.setText(origin_parm[4][2])
        self._dlg.Terraces_line_RCTW.setText(origin_parm[4][3])
        self._dlg.Terraces_line_RCHS.setText(origin_parm[4][4])
        self._dlg.Terraces_line_RCHN.setText(origin_parm[4][5])
        self._dlg.Terraces_line_RCHC.setText(origin_parm[4][6])
        self._dlg.Terraces_line_RCHK.setText(origin_parm[4][7])
        self._dlg.Terraces_line_PEC.setText(origin_parm[9][0])
        self._dlg.Terraces_line_LUNS.setText(origin_parm[1][10])
        
        self._dlg.TriangularSedimentDike_line_RSEE.setText(origin_parm[5][0])
        self._dlg.TriangularSedimentDike_line_RSAE.setText(origin_parm[5][1])
        self._dlg.TriangularSedimentDike_line_RSVE.setText(origin_parm[5][2])
        self._dlg.TriangularSedimentDike_line_RSEP.setText(origin_parm[5][3])
        self._dlg.TriangularSedimentDike_line_RSAP.setText(origin_parm[5][4])
        self._dlg.TriangularSedimentDike_line_RSVP.setText(origin_parm[5][5])
        self._dlg.TriangularSedimentDike_line_RSV.setText(origin_parm[5][6])
        self._dlg.TriangularSedimentDike_line_RSRR.setText(origin_parm[5][7])
        self._dlg.TriangularSedimentDike_line_RSYS.setText(origin_parm[5][8])
        self._dlg.TriangularSedimentDike_line_RSYN.setText(origin_parm[5][9])
        self._dlg.TriangularSedimentDike_line_RSHC.setText(origin_parm[6][0])
        self._dlg.TriangularSedimentDike_line_RSDP.setText(origin_parm[6][1])
        self._dlg.TriangularSedimentDike_line_RSBD.setText(origin_parm[6][2])
        
        self._dlg.WetlandCreation_line_RSEE.setText(origin_parm[5][0])
        self._dlg.WetlandCreation_line_RSAE.setText(origin_parm[5][1])
        self._dlg.WetlandCreation_line_RSVE.setText(origin_parm[5][2])
        self._dlg.WetlandCreation_line_RSEP.setText(origin_parm[5][3])
        self._dlg.WetlandCreation_line_RSAP.setText(origin_parm[5][4])
        self._dlg.WetlandCreation_line_RSVP.setText(origin_parm[5][5])
        self._dlg.WetlandCreation_line_RSV.setText(origin_parm[5][6])
        self._dlg.WetlandCreation_line_RSRR.setText(origin_parm[5][7])
        self._dlg.WetlandCreation_line_RSYS.setText(origin_parm[5][8])
        self._dlg.WetlandCreation_line_RSYN.setText(origin_parm[5][9])
        self._dlg.WetlandCreation_line_RSHC.setText(origin_parm[6][0])
        self._dlg.WetlandCreation_line_RSDP.setText(origin_parm[6][1])
        self._dlg.WetlandCreation_line_RSBD.setText(origin_parm[6][2])
        self._dlg.WetlandCreation_line_IOPS.setText(origin_parm[1][1])
        self._dlg.WetlandCreation_line_LUNS.setText(origin_parm[1][10])

    
        
    def doClose(self):
        """Close form."""
        self._dlg.close()

    def Describe(self):
        try:
            self._dlg.Notes_text.setText(self._Des_dict[str(self._dlg.Notes_lineEdit.text())])
        except KeyError:
            self._dlg.Notes_text.setText(" ")
        return
    


