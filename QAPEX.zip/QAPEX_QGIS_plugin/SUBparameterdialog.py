# -*- coding: utf-8 -*-

from PyQt4 import QtGui
from ui_SUBparameter import Ui_ParmDialog

class SUBParameterDialog(QtGui.QDialog, Ui_ParmDialog):
    """Set up dialog from designer."""
    def __init__(self):
        """Constructor."""
        QtGui.QDialog.__init__(self)
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
