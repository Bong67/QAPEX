# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_exempt.ui'
#
# Created: Sat Jan 03 16:37:12 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_ExemptDialog(object):
    def setupUi(self, ExemptDialog):
        ExemptDialog.setObjectName(_fromUtf8("ExemptDialog"))
        ExemptDialog.resize(249, 219)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/plugins/qswat/QSWAT-Icon/QSWAT-Icon-SWAT-16.ico")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        ExemptDialog.setWindowIcon(icon)
        self.buttonBox = QtGui.QDialogButtonBox(ExemptDialog)
        self.buttonBox.setGeometry(QtCore.QRect(-100, 180, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.groupBox = QtGui.QGroupBox(ExemptDialog)
        self.groupBox.setGeometry(QtCore.QRect(10, 10, 231, 161))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.exemptBox = QtGui.QListWidget(self.groupBox)
        self.exemptBox.setGeometry(QtCore.QRect(130, 60, 91, 91))
        self.exemptBox.setObjectName(_fromUtf8("exemptBox"))
        self.cancelExemptionButton = QtGui.QPushButton(self.groupBox)
        self.cancelExemptionButton.setGeometry(QtCore.QRect(30, 100, 71, 35))
        self.cancelExemptionButton.setObjectName(_fromUtf8("cancelExemptionButton"))
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(10, 20, 96, 31))
        self.label_2.setInputMethodHints(QtCore.Qt.ImhNone)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label_3 = QtGui.QLabel(self.groupBox)
        self.label_3.setGeometry(QtCore.QRect(130, 30, 101, 21))
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.chooseBox = QtGui.QComboBox(self.groupBox)
        self.chooseBox.setGeometry(QtCore.QRect(20, 60, 69, 22))
        self.chooseBox.setInsertPolicy(QtGui.QComboBox.InsertAlphabetically)
        self.chooseBox.setObjectName(_fromUtf8("chooseBox"))

        self.retranslateUi(ExemptDialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), ExemptDialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), ExemptDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(ExemptDialog)

    def retranslateUi(self, ExemptDialog):
        ExemptDialog.setWindowTitle(QtGui.QApplication.translate("ExemptDialog", "Exempt Landuses", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonBox.setToolTip(QtGui.QApplication.translate("ExemptDialog", "Save exemptions (OK) or leave exemptions the same as when this form was opened (Cancel).", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("ExemptDialog", "Landuse threshold exemptions", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelExemptionButton.setToolTip(QtGui.QApplication.translate("ExemptDialog", "Remove the selected landuse from the list of exempt landuses.", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelExemptionButton.setText(QtGui.QApplication.translate("ExemptDialog", "Cancel\n"
"exemption", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("ExemptDialog", "Select landuse\n"
"to be exempt", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("ExemptDialog", "Exempt landuses", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
