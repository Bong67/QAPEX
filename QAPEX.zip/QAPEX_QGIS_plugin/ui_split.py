# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_split.ui'
#
# Created: Sat Jan 03 16:37:12 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_SplitDialog(object):
    def setupUi(self, SplitDialog):
        SplitDialog.setObjectName(_fromUtf8("SplitDialog"))
        SplitDialog.resize(321, 341)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/plugins/qswat/QSWAT-Icon/QSWAT-Icon-SWAT-16.ico")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        SplitDialog.setWindowIcon(icon)
        self.table = QtGui.QTableWidget(SplitDialog)
        self.table.setGeometry(QtCore.QRect(100, 100, 200, 131))
        self.table.setColumnCount(3)
        self.table.setObjectName(_fromUtf8("table"))
        self.table.setColumnCount(3)
        self.table.setRowCount(0)
        self.table.verticalHeader().setVisible(True)
        self.table.verticalHeader().setDefaultSectionSize(20)
        self.table.verticalHeader().setMinimumSectionSize(19)
        self.label_2 = QtGui.QLabel(SplitDialog)
        self.label_2.setGeometry(QtCore.QRect(15, 20, 91, 31))
        self.label_2.setInputMethodHints(QtCore.Qt.ImhNone)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.newCombo = QtGui.QComboBox(SplitDialog)
        self.newCombo.setGeometry(QtCore.QRect(15, 60, 91, 22))
        self.newCombo.setInsertPolicy(QtGui.QComboBox.InsertAlphabetically)
        self.newCombo.setObjectName(_fromUtf8("newCombo"))
        self.splitCombo = QtGui.QComboBox(SplitDialog)
        self.splitCombo.setGeometry(QtCore.QRect(180, 60, 91, 22))
        self.splitCombo.setInsertPolicy(QtGui.QComboBox.InsertAlphabetically)
        self.splitCombo.setObjectName(_fromUtf8("splitCombo"))
        self.addButton = QtGui.QPushButton(SplitDialog)
        self.addButton.setGeometry(QtCore.QRect(15, 100, 76, 35))
        self.addButton.setObjectName(_fromUtf8("addButton"))
        self.deleteButton = QtGui.QPushButton(SplitDialog)
        self.deleteButton.setGeometry(QtCore.QRect(15, 140, 76, 35))
        self.deleteButton.setObjectName(_fromUtf8("deleteButton"))
        self.deleteSplitButton = QtGui.QPushButton(SplitDialog)
        self.deleteSplitButton.setGeometry(QtCore.QRect(15, 180, 76, 35))
        self.deleteSplitButton.setObjectName(_fromUtf8("deleteSplitButton"))
        self.cancelEditButton = QtGui.QPushButton(SplitDialog)
        self.cancelEditButton.setGeometry(QtCore.QRect(120, 240, 71, 35))
        self.cancelEditButton.setObjectName(_fromUtf8("cancelEditButton"))
        self.saveEditButton = QtGui.QPushButton(SplitDialog)
        self.saveEditButton.setGeometry(QtCore.QRect(200, 240, 71, 35))
        self.saveEditButton.setObjectName(_fromUtf8("saveEditButton"))
        self.label_3 = QtGui.QLabel(SplitDialog)
        self.label_3.setGeometry(QtCore.QRect(180, 20, 91, 31))
        self.label_3.setInputMethodHints(QtCore.Qt.ImhNone)
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.cancelButton = QtGui.QPushButton(SplitDialog)
        self.cancelButton.setGeometry(QtCore.QRect(230, 290, 71, 35))
        self.cancelButton.setObjectName(_fromUtf8("cancelButton"))
        self.saveSplitsButton = QtGui.QPushButton(SplitDialog)
        self.saveSplitsButton.setGeometry(QtCore.QRect(150, 290, 71, 35))
        self.saveSplitsButton.setObjectName(_fromUtf8("saveSplitsButton"))

        self.retranslateUi(SplitDialog)
        QtCore.QMetaObject.connectSlotsByName(SplitDialog)

    def retranslateUi(self, SplitDialog):
        SplitDialog.setWindowTitle(QtGui.QApplication.translate("SplitDialog", "Split Landuses", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("SplitDialog", "Select landuse\n"
"to split", None, QtGui.QApplication.UnicodeUTF8))
        self.addButton.setToolTip(QtGui.QApplication.translate("SplitDialog", "Add a sub-landuse to the split in the table.", None, QtGui.QApplication.UnicodeUTF8))
        self.addButton.setText(QtGui.QApplication.translate("SplitDialog", "Add\n"
"sub-landuse", None, QtGui.QApplication.UnicodeUTF8))
        self.deleteButton.setToolTip(QtGui.QApplication.translate("SplitDialog", "Remove the selected row from the table.  You can select a row by clicking in the table.", None, QtGui.QApplication.UnicodeUTF8))
        self.deleteButton.setText(QtGui.QApplication.translate("SplitDialog", "Delete\n"
"sub-landuse", None, QtGui.QApplication.UnicodeUTF8))
        self.deleteSplitButton.setToolTip(QtGui.QApplication.translate("SplitDialog", "Clear the table and remove the split from the current list of landuses to split.", None, QtGui.QApplication.UnicodeUTF8))
        self.deleteSplitButton.setText(QtGui.QApplication.translate("SplitDialog", "Delete\n"
"split landuse", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelEditButton.setToolTip(QtGui.QApplication.translate("SplitDialog", "Clear the table.", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelEditButton.setText(QtGui.QApplication.translate("SplitDialog", "Cancel\n"
"edits", None, QtGui.QApplication.UnicodeUTF8))
        self.saveEditButton.setToolTip(QtGui.QApplication.translate("SplitDialog", "Save the table as a landuse to be split.  You must edit the percentages first so they sum to 100.", None, QtGui.QApplication.UnicodeUTF8))
        self.saveEditButton.setText(QtGui.QApplication.translate("SplitDialog", "Save\n"
"edits", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("SplitDialog", "Select split landuse\n"
"to edit", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelButton.setToolTip(QtGui.QApplication.translate("SplitDialog", "Leave the set of panduses to spliut as they were when this form was opened and exit.", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelButton.setText(QtGui.QApplication.translate("SplitDialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))
        self.saveSplitsButton.setToolTip(QtGui.QApplication.translate("SplitDialog", "Save the current set of split landuses and exit.", None, QtGui.QApplication.UnicodeUTF8))
        self.saveSplitsButton.setText(QtGui.QApplication.translate("SplitDialog", "Save\n"
"splits", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
