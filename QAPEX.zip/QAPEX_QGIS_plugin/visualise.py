# -*- coding: utf-8 -*-

# Import the PyQt and QGIS libraries
from PyQt4.QtCore import * # @UnusedWildImport
from PyQt4.QtGui import * # @UnusedWildImport
from qgis.core import * # @UnusedWildImport
# Import the code for the dialog
from visualisedialog import VisualiseDialog
from QSWATUtils import QSWATUtils

import pylab as plt
from matplotlib.dates import DateFormatter, DayLocator
import os, time, datetime, takeapex, csv



class Visualise(QObject):
    
    
    def __init__(self, iface, gv):
        QObject.__init__(self)
        self._iface = iface
        self._gv = gv
        self._dlg = VisualiseDialog()
        self._dlg.setWindowFlags(self._dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self._set = takeapex.SuperClass()

    def init(self):
        """Set connections to controls."""
        settings = QSettings()

        self._dlg.Scenario_comboBox.clear()
        self._dlg.Subbasin_comboBox.clear()
        self._dlg.HLU_comboBox.clear()
        self._dlg.Variable_comboBox.clear()
        self._dlg.LDC_comboBox.clear()
        self._dlg.SubScenario_comboBox.clear()
        self._dlg.SubSubbasin_comboBox.clear()
        self._dlg.SubHLU_comboBox.clear()
        self._dlg.SubVariable_comboBox.clear()
        self._dlg.Variable_table.clear()
        self._dlg.Variable_table.setHorizontalHeaderLabels(["Scenario-HLU", "Variable"]) 
        self._FDCCMS_min = 0.004

        self._path = self._gv.projDir

        #add scenarios combobox
        self._dlg.Scenario_comboBox.addItem("")
        self._dlg.SubScenario_comboBox.addItem("")
        for Scenario_list in os.listdir(self._path + "/Scenarios"):
            if not Scenario_list == "Default":
                self._dlg.Scenario_comboBox.addItem(Scenario_list)
                self._dlg.SubScenario_comboBox.addItem(Scenario_list)

        Variable_comboBox_add = open(self._path+"/Scenarios/sample/Winapex.RCH", "r")
        Variable_list = Variable_comboBox_add.readlines()
        Variable_comboBox_add.close()
        
        Variable_sub_strip = Variable_list[8].strip().split(" ")
        self.Variable_sub = [x for x in Variable_sub_strip if x]

        self._dlg.Variable_comboBox.addItem("")
        self._dlg.SubVariable_comboBox.addItem("")
        self._dlg.LDC_comboBox.addItem("")
        for Variable_comboBox_list in self.Variable_sub:
            if Variable_comboBox_list.endswith(("RCID","GIS","TIME")):
                continue
            else:
                self._dlg.Variable_comboBox.addItem(Variable_comboBox_list)
                if not Variable_comboBox_list.endswith(("WSAha","QIm3/s","QOm3/s","WYLIm3/s","WYLOm3/s","ETm3/s","FPFm3/s")):
                    self._dlg.LDC_comboBox.addItem(Variable_comboBox_list)
                
        self._dlg.Scenario_comboBox.currentIndexChanged.connect(self.Scenario_set)
        self._dlg.Subbasin_comboBox.currentIndexChanged.connect(self.Subbasin_set)
        
        self._dlg.SubScenario_comboBox.currentIndexChanged.connect(self.SubScenario_set)
        self._dlg.SubSubbasin_comboBox.currentIndexChanged.connect(self.SubSubbasin_set)
        self._dlg.SubHLU_comboBox.currentIndexChanged.connect(self.SubHLU_set)
        self._dlg.SubVariable_comboBox.currentIndexChanged.connect(self.SubVariable_set)

        self._dlg.ObservedPush_General.clicked.connect(self.General_set)
        self._dlg.ObservedPush_FDC.clicked.connect(self.FDC_set)
        self._dlg.ObservedPush_LDC.clicked.connect(self.LDC_set)

        self._dlg.Variable_comboBox.currentIndexChanged.connect(self.Variable_set)
        self._dlg.Delete_push.clicked.connect(self.doDelPlot)
        self._dlg.Up_push.clicked.connect(self.doUpPlot)
        self._dlg.Down_push.clicked.connect(self.doDownPlot)

        self._dlg.General_Plot.clicked.connect(self.doGeneralPlot) 
        self._dlg.FDC_Plot.clicked.connect(self.doFDCPlot) 
        self._dlg.LDC_Plot.clicked.connect(self.doLDCPlot)

        self._dlg.Cancel_pushButton.clicked.connect(self.doClose)
        
        """
        self._dlg.MDB_pushButton.clicked.connect(self.MDB_set)
        self._dlg.Weather_pushButton.clicked.connect(self.Weather_set)
        self._dlg.OPS_pushButton.clicked.connect(self.OPS_set)
        self._dlg.Run_pushButton.clicked.connect(self.Run_APEX)
        self._dlg.Cancel_pushButton.clicked.connect(self.doClose)
        self._dlg.APEXCONT_pushButton.clicked.connect(self.APEXCONT_set)
        self._dlg.parm_pushButton.clicked.connect(self.Parm_set)
        self._dlg.Set_pushButton.clicked.connect(self.APEX_set)
        """
        

    def run(self):
        self.init()
        self._dlg.show()
        result = self._dlg.exec_()  # @UnusedVariable
        self._gv.delineatePos = self._dlg.pos()
        self._gv.writeMasterProgress(0,0)
        return 0

    def Scenario_set(self):
     if not self._dlg.Scenario_comboBox.currentText() == "":
        self._Scenario = str(self._dlg.Scenario_comboBox.currentText())
        f = open(self._path+"/Source/MDB_path.txt", "r")
        self._MDB_path = f.readline()
        f.close()

        Read = self._set.Read_MDB(self._MDB_path, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(self._path+"/Scenarios/"+self._Scenario+"/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x]

        f = open(self._path+"/Scenarios/"+self._Scenario+"/"+g_line[1],"r")
        f_lines = f.readlines()
        f.close()
        
        count = 0
        self._Subbasin_sub = []
        self._Subbasin_list = [[x,[]] for x in range(1, len(f_lines)/12+1)]
        for n in range(0,len(f_lines)):
            count += 1
            if count % 12 == 1:
                if count + 5 <len(f_lines):
                    f_line_strip = f_lines[n].strip().split(" ")
                    f_line = [x for x in f_line_strip if x]

                    self._Subbasin_list[int(f_line[5])-1][1].append(f_line[0])
                    self._Subbasin_sub.append(int(f_line[5]))
        self._Subbasin_sub = list(set(self._Subbasin_sub))
        self._Subbasin_sub.sort()

        for Subbasin in self._Subbasin_sub:
            self._dlg.Subbasin_comboBox.addItem(str(Subbasin))

        count = 0
        for remove_list in self._Subbasin_list:
            count += 1
            if count > len(self._Subbasin_sub):
                self._Subbasin_list.remove(self._Subbasin_list[count-1])

        f = open(self._path+"/Scenarios/"+self._Scenario+"/APEXCONT.DAT", "r")
        f_lines = f.readlines()
        f.close()

        f_line_strip = f_lines[0].strip().split(" ")
        f_line = [x for x in f_line_strip if x]

        
        start_date  = datetime.datetime.strptime('{}{:02}{:02}'.format(int(f_line[0][-4:]),int(f_line[1]),int(f_line[2])),"%Y%m%d")
        finish_date = datetime.datetime.strptime('{}{:02}{:02}'.format(int(f_line[0][-4:])+int(f_line[0][:-4]),int(f_line[1]),int(f_line[2])),"%Y%m%d") - datetime.timedelta(days = 1)
        
        self._dlg.Start_line.setText('{}-{:02}-{:02}'.format(int(start_date.year), start_date.month, start_date.day))
        self._dlg.Finish_line.setText('{}-{:02}-{:02}'.format(int(finish_date.year), finish_date.month, finish_date.day))



    def Subbasin_set(self):
        self._dlg.HLU_comboBox.clear()
        self._Subbasin = str(self._dlg.Subbasin_comboBox.currentText())
        #HLU_sub = [HLU_1, HLU_2, ... , HLU_9999]
        #Subbasin_sub = [Subbasin_1, Subbasin_2, ... , Subbasin_9999]
        #Subbasin_list = [[subbasin_1, [HLU_1, HLU_2], [subbasin_2, [HLU_1, HLU_2, HLU_3]]]        for Subbasin in Subbasin_list

        for Subbasin in self._Subbasin_list:
            if str(Subbasin[0]) == self._Subbasin:
                for Subbasin_add in Subbasin[1]:
                    self._dlg.HLU_comboBox.addItem(str(Subbasin_add))
        self._dlg.HLU_comboBox.setCurrentIndex(0)      

    def SubScenario_set(self):
     if not self._dlg.SubScenario_comboBox.currentText() == "":
        self._SubScenario = str(self._dlg.SubScenario_comboBox.currentText())
        f = open(self._path+"/Source/MDB_path.txt", "r")
        self._MDB_path = f.readline()
        f.close()

        Read = self._set.Read_MDB(self._MDB_path, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(self._path+"/Scenarios/"+self._SubScenario+"/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x]

        f = open(self._path+"/Scenarios/"+self._SubScenario+"/"+g_line[1],"r")
        f_lines = f.readlines()
        f.close()
        
        count = 0
        self._SubSubbasin_sub = []
        self._SubSubbasin_list = [[x,[]] for x in range(1, len(f_lines)/12+1)]
        for n in range(0,len(f_lines)):
            count += 1
            if count % 12 == 1:
                if count + 5 <len(f_lines):
                    f_line_strip = f_lines[n].strip().split(" ")
                    f_line = [x for x in f_line_strip if x]

                    self._SubSubbasin_list[int(f_line[5])-1][1].append(f_line[0])
                    self._SubSubbasin_sub.append(int(f_line[5]))
        self._SubSubbasin_sub = list(set(self._SubSubbasin_sub))
        self._SubSubbasin_sub.sort()

        for Subbasin in self._SubSubbasin_sub:
            self._dlg.SubSubbasin_comboBox.addItem(str(Subbasin))

        count = 0
        for remove_list in self._SubSubbasin_list:
            count += 1
            if count > len(self._SubSubbasin_sub):
                self._SubSubbasin_list.remove(self._SubSubbasin_list[count-1])

    def SubSubbasin_set(self):
        self._dlg.SubHLU_comboBox.clear()
        self._SubSubbasin = str(self._dlg.SubSubbasin_comboBox.currentText())
        #HLU_sub = [HLU_1, HLU_2, ... , HLU_9999]
        #Subbasin_sub = [Subbasin_1, Subbasin_2, ... , Subbasin_9999]
        #Subbasin_list = [[subbasin_1, [HLU_1, HLU_2], [subbasin_2, [HLU_1, HLU_2, HLU_3]]]        for Subbasin in Subbasin_list

        for Subbasin in self._SubSubbasin_list:
            if str(Subbasin[0]) == self._SubSubbasin:
                for Subbasin_add in Subbasin[1]:
                    self._dlg.SubHLU_comboBox.addItem(str(Subbasin_add))
        self._dlg.SubHLU_comboBox.setCurrentIndex(0)

    def SubHLU_set(self):
        self._dlg.SubVariable_comboBox.clear()
        self._dlg.SubVariable_comboBox.addItem("")
        for Variable_comboBox_list in self.Variable_sub:
            if Variable_comboBox_list == "RCID" or Variable_comboBox_list == "GIS" or Variable_comboBox_list == "TIME":
                continue
            else:
                self._dlg.SubVariable_comboBox.addItem(Variable_comboBox_list)

    def General_set(self):
        self._ObservedFile_General = QFileDialog.getOpenFileName(None, 'Select a Observed data file', 'C:\\', "CSV files (*.csv)")
        self._dlg.General_ObservedEdit.setText(self._ObservedFile_General)

    def FDC_set(self):
        self._ObservedFile_FDC = QFileDialog.getOpenFileName(None, 'Select a Observed data file', 'C:\\', "CSV files (*.csv)")
        self._dlg.FDC_ObservedEdit.setText(self._ObservedFile_FDC)

    def LDC_set(self):
        self._ObservedFile_LDC = QFileDialog.getOpenFileName(None, 'Select a Observed data file', 'C:\\', "CSV files (*.csv)")
        self._dlg.LDC_ObservedEdit.setText(self._ObservedFile_LDC)

    def Variable_set(self):
        self._Variable = str(self._dlg.Variable_comboBox.currentText())
        if not self._Variable == "":
            self._Scenario = str(self._dlg.Scenario_comboBox.currentText())
            self._Subbasin = str(self._dlg.Subbasin_comboBox.currentText())
            self._HLU = str(self._dlg.HLU_comboBox.currentText())
            if self._Scenario == "":
                QSWATUtils.information('Please select the scenario', self._gv.isBatch)
                return

            size = self._dlg.Variable_table.rowCount()
            self._dlg.Variable_table.insertRow(size)
            self._dlg.Variable_table.setItem(size, 0, QTableWidgetItem(self._Scenario + "-"+self._HLU))
            self._dlg.Variable_table.setItem(size, 1, QTableWidgetItem(self._Variable))

    def SubVariable_set(self):
        self._SubVariable = str(self._dlg.SubVariable_comboBox.currentText())
        if not self._SubVariable == "":
            self._SubScenario = str(self._dlg.SubScenario_comboBox.currentText())
            self._SubSubbasin = str(self._dlg.SubSubbasin_comboBox.currentText())
            self._SubHLU = str(self._dlg.SubHLU_comboBox.currentText())

            size = self._dlg.Variable_table.rowCount()
            self._dlg.Variable_table.insertRow(size)
            self._dlg.Variable_table.setItem(size, 0, QTableWidgetItem(self._SubScenario + "-"+self._SubHLU))
            self._dlg.Variable_table.setItem(size, 1, QTableWidgetItem(self._SubVariable))

    def doDelPlot(self):
        """Delete current plot row."""
        indexes = self._dlg.Variable_table.selectedIndexes()
        if not indexes or indexes == []:
            QSWATUtils.information('Please select a row for deletion', self._gv.isBatch)
            return
        row = indexes[0].row()
        if row in xrange(self._dlg.Variable_table.rowCount()):
            self._dlg.Variable_table.removeRow(row)

    def doUpPlot(self):
        """Move current plot row up 1 place and keep it current."""
        indexes = self._dlg.Variable_table.selectedIndexes()
        if not indexes or indexes == []:
            QSWATUtils.information('Please select a row to move up', self._gv.isBatch)
            return
        row = indexes[0].row()
        if 1 <= row < self._dlg.Variable_table.rowCount():
            for col in xrange(2):
                item = self._dlg.Variable_table.takeItem(row, col)
                self._dlg.Variable_table.setItem(row, col, self._dlg.Variable_table.takeItem(row-1, col))
                self._dlg.Variable_table.setItem(row-1, col, item)
        self._dlg.Variable_table.selectRow(row-1)

    def doDownPlot(self):
        """Move current plot row down 1 place and keep it current."""
        indexes = self._dlg.Variable_table.selectedIndexes()
        if not indexes or indexes == []:
            QSWATUtils.information('Please select a row to move down', self._gv.isBatch)
            return
        row = indexes[0].row()
        if 0 <= row < self._dlg.Variable_table.rowCount() - 1:
            for col in xrange(2):
                item = self._dlg.Variable_table.takeItem(row, col)
                self._dlg.Variable_table.setItem(row, col, self._dlg.Variable_table.takeItem(row+1, col))
                self._dlg.Variable_table.setItem(row+1, col, item)
        self._dlg.Variable_table.selectRow(row+1)

    def doGeneralPlot(self):
        self._Scenario = str(self._dlg.Scenario_comboBox.currentText())
        self._Subbasin = str(self._dlg.Subbasin_comboBox.currentText())
        self._HLU = str(self._dlg.HLU_comboBox.currentText())
        self._Start_date = str(self._dlg.Start_line.text())
        self._Finish_date = str(self._dlg.Finish_line.text())
        #add variable_table        
        self._Plotlist = []
        self._Generalplot_list = []
        



        table_result = []
        num_rows, num_cols = self._dlg.Variable_table.rowCount(), self._dlg.Variable_table.columnCount()
        for row in range(num_rows):
            rows = []
            for col in range(num_cols):
                item = self._dlg.Variable_table.item(row, col)
                rows.append(item.text() if item else '')
            table_result.append(rows)
        
        for x in table_result:
            v1_sub1 = x[0].split("-")
            v2 = v1_sub1[-1]
            v1_sub2 = [xx for xx in v1_sub1[:-1]]
            v1 = ''
            for v1_sub3 in v1_sub2:
                v1 += v1_sub3
            self._Generalplot_list.append([v1, v2, x[1]])

        for x in self._Generalplot_list:
            self.GeneralPlot_sub(x[0], x[1], x[2])



        #plot
        fig, ax = plt.subplots(1, 1, figsize=(15,6))
        plt.axes(ax)
        for plot_data in self._Plotlist:
            plt.plot(plot_data[2], plot_data[3], label = plot_data[0] + "("+plot_data[1]+"): "+plot_data[4])  #= plot_data[4] + "__"+plot_data[0] + "("+plot_data[1]+")") #color, marker = '^'

        #Observed data
        if not self._dlg.General_ObservedEdit.text() == "":
            f = open(self._dlg.General_ObservedEdit.text(), "rb")
            csvReader = csv.reader(f)
            Date_list = []
            Value_list = []
            count = 0
            for line in csvReader:
                count += 1
                if count == 1:
                    try:
                        Observed_label = str(line[1])
                    except:
                        Observed_label = ''
                elif count > 1:
                    Date_list.append(datetime.datetime.strptime(line[0],"%Y-%m-%d"))
                    Value_list.append(line[1])
            plt.plot(Date_list, Value_list, label = "Observed " + Observed_label, color = 'r', marker = '.',linestyle='')

        ax.xaxis.set_major_formatter(DateFormatter("%Y/%m/%d"))
        plt.legend(loc='upper right')
        #ax.xaxis.set_major_locator(DayLocator())
        
        plt.title('General Plot\n', size = 15)
        plt.xlabel('Date', size = 15)
        plt.ylabel('Value', size = 15)
        plt.yscale('linear', nonposy='clip')
        #ax.set_ylim([0., 2.])
        #ax.set_xlim
        plt.show()
    
    def GeneralPlot_sub(self, Scenario, HLU, Variable):
        f = open(self._path+"/Scenarios/"+Scenario+"/APEXCONT.DAT", "r")
        IPD = f.readline()
        IPD_strip = IPD.strip().split(" ")
        IPD = [x for x in IPD_strip if x]
        IPD = int(IPD[3])
        f.close()

        f = open(self._path + "/Scenarios/"+Scenario+"/Winapex.RCH", "r")
        self._RCH_lines = f.readlines()
        f.close()
        
        Variable_index_strip = self._RCH_lines[8].strip().split(" ")
        Variable_index_sub = [x for x in Variable_index_strip if x]
        Variable_index = Variable_index_sub.index(Variable)+1

        count = 0
        b = 0
        Date_list = []
        Variable_list = []

        for RCH_line in self._RCH_lines:
            count += 1
            if RCH_line.startswith("REACH"):
                RCH_line_strip = RCH_line.strip().split(" ")
                RCH_line = [x for x in RCH_line_strip if x]
                if RCH_line[1] == HLU:
                    start_date = datetime.datetime.strptime(self._Start_date, "%Y-%m-%d")
                    finish_date = datetime.datetime.strptime(self._Finish_date, "%Y-%m-%d")
                    if IPD >= 0 and IPD < 3:
                        date_sub = datetime.datetime.strptime(RCH_line[3],"%Y")
                    elif IPD >= 3 and IPD < 6:
                        date_sub = datetime.datetime.strptime(RCH_line[2]+RCH_line[3],"%Y%m")
                    elif IPD >= 6:
                        date_sub = datetime.datetime.strptime(RCH_line[2]+RCH_line[3],"%Y%j")

                    if start_date <= date_sub <= finish_date:
                        Date_list.append(date_sub)
                        Variable_list.append(str(float(RCH_line[Variable_index])))
                        
        if Date_list == []:
            Date_list = [x for x in range(1, len(Variable_list)+1)]

        return self._Plotlist.append([Scenario, HLU, Date_list, Variable_list, Variable])

    def FDC_csv(self, csv_name):
        self._FDC_sort = []

        self.GeneralPlot_sub(self._Scenario, self._HLU, "WYLOm3/s")
        #self._Plotlist.append([Scenario, HLU, Date_list, Variable_list, Variable])

        for sort_v in self._Plotlist:
            for n in range(0, len(sort_v[2])):
                if float(sort_v[3][n]) >= self._FDCCMS_min: #remove WYLOm3/s < 0.0001
                    self._FDC_sort.append([float(sort_v[3][n]), sort_v[2][n]]) #"WYLOm3/s", date

        #csv_name = 'FDC_{}({}-{})_{}_{}.csv'.format(self._Scenario,self._Subbasin,self._HLU,self._Start_date,self._Finish_date)
        self._FDC_sort.sort(reverse = True)
        for n in range(0, len(self._FDC_sort)):
            self._FDC_sort[n].append(n+1)  #"WYLOm3/s", date, rank

        self._x_value = []
        self._y_value = []
        f = open(self._path+"/Scenarios/"+self._Scenario+"/"+csv_name,"wb")
        wr = csv.writer(f)
        wr.writerow(["Rank", "WYLOm3/s", "Percentile", "Date"])  #(0.123, Date, 1)
        for csv_row in self._FDC_sort:
            Percentile = (float(csv_row[2])/float(len(self._FDC_sort)))*100
            wr.writerow([csv_row[2], csv_row[0], Percentile, str(csv_row[1]).split(" ")[0]])
            self._x_value.append(Percentile)
            self._y_value.append(csv_row[0])
        f.close()

    def doFDCPlot(self):
        self._Scenario = str(self._dlg.Scenario_comboBox.currentText())
        self._Subbasin = str(self._dlg.Subbasin_comboBox.currentText())
        self._HLU = str(self._dlg.HLU_comboBox.currentText())
        self._Start_date = str(self._dlg.Start_line.text())
        self._Finish_date = str(self._dlg.Finish_line.text())
        #add variable_table        
        self._Plotlist = []

        self._FDC_csv_name = 'FDC_{}({}-{})_{}_{}.csv'.format(self._Scenario,self._Subbasin,self._HLU,self._Start_date,self._Finish_date)
        self.FDC_csv(self._FDC_csv_name)
        #Observed_data file
        #f = open(self._path+"/Scenarios/"+self._Scenario+"/"+csv_name,"wb")
        FDC_Observed_x_value = []
        FDC_Observed_y_value = []
        if not self._dlg.FDC_ObservedEdit.text() == '':
            fig, ax = plt.subplots(2, 1, figsize=(15,10))
            
            ax[0].plot(self._x_value,self._y_value, label = 'Estimated')#'{}({})'.format(self._Scenario, self._HLU)) #self._Subbasin, 
            ax[0].legend(loc='upper right')
            ax[0].set_title('{}({})\nFlow Duration Curve'.format(self._Scenario, self._HLU), size = 15) # self._Subbasin,
            ax[0].set_xlabel('Flow Exceedance Percentile (%)', size = 15)
            ax[0].set_ylabel('WYLO(CMS)', size = 15)
            ax[0].set_yscale('log', nonposy='clip')
            ax[0].set_xlim([0,100])
            ax[0].set_ylim([0,1000])
            ax[0].set_xticks([0,10,20,30,40,50,60,70,80,90,100])
            #set_xticklabels(['1','2'...])
            
            #"WYLOm3/s", date, rank
            
            f = open(self._dlg.FDC_ObservedEdit.text(), "r")
            f_lines = f.readlines()
            f.close()

            Observed_list = []
            Observed_x = []
            Observed_y = []
            n = 0
            for f_line in f_lines:
                n += 1
                f_line = f_line.split("\n")
                f_line = f_line[0].split(",")
                if n > 1:
                    Observed_list.append([float(f_line[1]), f_line[0]])  #flow, date
            Observed_list.sort(reverse=True)
            for n in range(0, len(Observed_list)):
                p = (float((n+1))/float(len(Observed_list)))*100
                Observed_list[n].append(str(p))
                Observed_list[n].append(str(n+1))   #flow, date, percentile, rank

            for n in Observed_list:
                Observed_x.append(n[2])
                Observed_y.append(n[0])
                
            ax[1].plot(Observed_x,Observed_y, label = 'Observed', color = 'r')
            ax[1].legend(loc='upper right')
            title_ID = self._dlg.FDC_ObservedEdit.text().split("/")
            title_ID = title_ID[-1].split(".")
            ax[1].set_title('{}\nFlow Duration Curve'.format(title_ID[0]), size = 15)
            ax[1].set_xlabel('Flow Exceedance Percentile (%)', size = 15)
            ax[1].set_ylabel('Flow(CMS)', size = 15)
            ax[1].set_yscale('log', nonposy='clip')
            ax[1].set_xlim([0,100])
            ax[1].set_ylim([0,1000])
            ax[1].set_xticks([0,10,20,30,40,50,60,70,80,90,100])

            plt.tight_layout()
            plt.show()
        
        else: 
            fig, ax = plt.subplots(1, 1, figsize=(15,6))
            plt.axes(ax)
            plt.plot(self._x_value,self._y_value)
            plt.legend(loc='upper right')
            plt.title('{}({}-{})\nFlow Duration Curve'.format(self._Scenario, self._Subbasin, self._HLU), size = 15)
            plt.xlabel('Flow Exceedance Percentile (%)', size = 15)
            plt.ylabel('WYLO(CMS)', size = 15)
            plt.yscale('log', nonposy='clip')
            plt.xlim([0,100])
            plt.ylim([0,1000])
            plt.xticks([0,10,20,30,40,50,60,70,80,90,100])
            plt.show()
        return
        
    def LDC_csv(self, csv_name, Variable_x):
        self._LDC_sort = []

        self.GeneralPlot_sub(self._Scenario, self._HLU, "WYLOm3/s")
        self.GeneralPlot_sub(self._Scenario, self._HLU, Variable_x)
        #self._Plotlist.append([Scenario, HLU, Date_list, Variable_list, Variable])

        count = 0
        for sort_v in self._Plotlist:
            count += 1
            for n in range(0, len(sort_v[2])):
                if count == 1:
                    self._LDC_sort.append([float(sort_v[3][n]),sort_v[2][n]])
                else:
                    if Variable_x == "CYppm":
                        self._LDC_sort[n].insert(1, float(sort_v[3][n]) * float(self._LDC_sort[n][0]) * 86.4) #kg/day
                    else:
                        self._LDC_sort[n].insert(1, sort_v[3][n])
                        #["WYLOm3/s", Variable_x, date]
        #remove WYLOm3/s < 0.0001
        N = []
        for n in range(0, len(self._LDC_sort)):
            if float(self._LDC_sort[n][0]) <= self._FDCCMS_min:
                N.append(self._LDC_sort[n])
        for n in N:
            self._LDC_sort.remove(n)

        #csv_name = 'LDC_{}({}-{})_{}_{}.csv'.format(self._Scenario,self._Subbasin,self._HLU,self._Start_date,self._Finish_date)
        self._LDC_sort.sort(reverse = True)
        for n in range(0, len(self._LDC_sort)):
            self._LDC_sort[n].append(n+1)  #"WYLOm3/s", Variable_x, date, rank

        self._x_value = []
        self._y_value = []
        f = open(self._path+"/Scenarios/"+self._Scenario+"/"+csv_name,"w")
        f.write("Rank,WYLOm3/s,"+Variable_x+",Percentile,Date\n")  #(0.123, Date, 1)
        for csv_row in self._LDC_sort:
            Percentile = (float(csv_row[3])/float(len(self._LDC_sort)))*100
            #wr.writerow([csv_row[3], csv_row[0], csv_row[1], Percentile, str(csv_row[2]).split(" ")[0]])  
            f.write(str(csv_row[3])+","+str(csv_row[0])+","+str(csv_row[1])+","+str(Percentile)+","+str(csv_row[2]).split(" ")[0]+"\n")
            self._x_value.append(Percentile)
            self._y_value.append(csv_row[1])
        f.close()

    def doLDCPlot(self):
        self._Scenario = str(self._dlg.Scenario_comboBox.currentText())
        self._Subbasin = str(self._dlg.Subbasin_comboBox.currentText())
        self._HLU = str(self._dlg.HLU_comboBox.currentText())
        self._Start_date = str(self._dlg.Start_line.text())
        self._Finish_date = str(self._dlg.Finish_line.text())
        Target_value = self._dlg.Target_line.text()
        LDC_Variable = self._dlg.LDC_comboBox.currentText()
        #Create_FDC    
        self._Plotlist = []
        self._LDC_csv_name = 'LDC({})_{}({}-{})_{}_{}.csv'.format(LDC_Variable, self._Scenario,self._Subbasin,self._HLU,self._Start_date,self._Finish_date)
        self.LDC_csv(self._LDC_csv_name, LDC_Variable)

        #"Rank", "WYLOm3/s", Variable_x, "Percentile", "Date"
        #Create_LDC
        f = open(self._path+"/Scenarios/"+self._Scenario+"/"+self._LDC_csv_name, "r")
        f_lines = f.readlines()
        f.close()
        
        Percentile_list = []
        Estimated_list = []
        Target_load_list = []
        count = 0
        unit_check = ""
        for f_line in f_lines:
            count += 1
            f_line = f_line.split("\n")
            f_line = f_line[0].split("\r")
            f_line = f_line[0].split(",")
            if count > 1:
                Percentile_list.append(f_line[3])
                Estimated_list.append(float(f_line[2]))
                if LDC_Variable.endswith(("YIt","YOt")):
                    Target_load_list.append(float(f_line[1]) * float(self._dlg.Target_line.text()) * 0.0864) 
                    unit_check = "(ton/day)"
                elif LDC_Variable.endswith(("QPSIg","QPSOg","YPSIg","YPSOg","RPSTg","VPSTg","DPSTg")):
                    Target_load_list.append(float(f_line[1]) * float(self._dlg.Target_line.text()) * 86400)
                    unit_check = "(g/day)"
                else:
                    Target_load_list.append(float(f_line[1]) * float(self._dlg.Target_line.text()) * 86.4)
                    unit_check = "(kg/day)"
                #.append(None)

        if not self._dlg.LDC_ObservedEdit.text() == '':
            f = open(self._dlg.LDC_ObservedEdit.text(), "r")
            f_lines = f.readlines()
            f.close()

            count = 0
            ob_list = []
            ob_date = []
            ob_flow = []
            ob_variable = []
            ob_percentile = []
            for f_line in f_lines:
                count += 1
                f_line = f_line.split("\n")
                f_line = f_line[0].split("\r")
                f_line = f_line[0].split(",")
                if count == 1:
                    ob_flowname = f_line[1]
                    ob_variablename = f_line[2]
                else:
                    if f_line[2] == '':
                        ob_list.append([float(f_line[1]), None, f_line[0]])
                    else:
                        ob_list.append([float(f_line[1]), f_line[2], f_line[0]])
            ob_list.sort(reverse=True)
            for n in range(0, len(ob_list)):
                ob_list[n].append((float(n+1)/len(ob_list))*100)
                ob_list[n].append(n+1)        #Flow, Variable, Date, Percentile, Rank

                ob_percentile.append(ob_list[n][3])
                ob_variable.append(ob_list[n][1])
                #ob_targetload.append(float(ob_list[n][0])*float(self._dlg.Target_line.text()) * 86.4)                
                if LDC_Variable.endswith(("YIt","YOt")):
                    ob_targetload.append(float(ob_list[n][0])*float(self._dlg.Target_line.text()) * 0.0864)
                elif LDC_Variable.endswith(("QPSIg","QPSOg","YPSIg","YPSOg","RPSTg","VPSTg","DPSTg")):
                    ob_targetload.append(float(ob_list[n][0])*float(self._dlg.Target_line.text()) * 86400)
                else:
                    ob_targetload.append(float(ob_list[n][0])*float(self._dlg.Target_line.text()) * 86.4)
                    
            fig, ax = plt.subplots(2, 1, figsize=(15,6))
            ax[0].plot(Percentile_list,Target_load_list, label = 'Target load')
            ax[0].plot(Percentile_list,Estimated_list, label = 'Estimated', linestyle = '', color = 'r', marker = '.')
            ax[0].legend(loc='upper right')
            ax[0].set_title('{}({})\nLoad Duration Curve'.format(self._Scenario, self._HLU), size = 15) #self._Subbasin,
            ax[0].set_xlabel('Flow Exceedance Percentile (%)', size = 15)
            ax[0].set_ylabel('Load'+unit_check, size = 15)
            ax[0].set_yscale('log', nonposy='clip')
            ax[0].set_xlim([0,100])
            #ax[0].set_ylim([0,1000])
            ax[0].set_xticks([0,10,20,30,40,50,60,70,80,90,100])

            ax[1].plot(ob_percentile,ob_targetload, label = 'Target load')
            ax[1].plot(ob_percentile,ob_variable, label = 'Observed', linestyle = '', color = 'r', marker = '.')
            ax[1].legend(loc='upper right')
            ax[1].set_title('{}({})\nLoad Duration Curve'.format(self._Scenario, self._HLU), size = 15) #self._Subbasin,
            ax[1].set_xlabel('Flow Exceedance Percentile (%)', size = 15)
            ax[1].set_ylabel('Load'+unit_check, size = 15)
            ax[1].set_yscale('log', nonposy='clip')
            ax[1].set_xlim([0,100])
            #ax[1].set_ylim([0,1000])
            ax[1].set_xticks([0,10,20,30,40,50,60,70,80,90,100])

            plt.tight_layout()
            plt.show()

        else:
            fig, ax = plt.subplots(1, 1, figsize=(15,6))
            plt.axes(ax)
            plt.plot(Percentile_list,Target_load_list, label = 'Target load')  #LDC_Variable
            plt.plot(Percentile_list,Estimated_list, label = LDC_Variable, linestyle = '', color = 'r', marker = 'o')
            plt.legend(loc='upper right')
            plt.title('{}({})\nLoad Duration Curve'.format(self._Scenario, self._HLU), size = 15) #self._Subbasin,
            plt.xlabel('Flow Exceedance Percentile (%)', size = 15)
            plt.ylabel('Load'+unit_check, size = 15)
            plt.yscale('log', nonposy='clip')
            plt.xlim([0,100])
            plt.ylim([0.1,10000])
            plt.xticks([0,10,20,30,40,50,60,70,80,90,100])
            plt.show()


    def doClose(self):
        self._dlg.close()
    #def Form에서 self._FDCCMS_min 변경가능하게 하기. (Form => option?)
    
    

#>>> wr = csv.writer(f)
#>>> wr.writerow([1, "asd", False])
#>>> wr.writerow([2, "ccc", False])

#>>> f = open("d:/c.csv", "rb")
#>>> rdr = csv.reader(f)
#>>> for line in rdr:
#	print line
	
