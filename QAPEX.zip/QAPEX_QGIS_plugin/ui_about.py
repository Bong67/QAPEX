# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_about.ui'
#
# Created: Sun Jan 25 17:56:44 2015
#      by: PyQt4 UI code generator 4.8.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_aboutQSWAT(object):
    def setupUi(self, aboutQSWAT):
        aboutQSWAT.setObjectName(_fromUtf8("aboutQSWAT"))
        aboutQSWAT.resize(245, 251)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("MS Shell Dlg 2"))
        font.setWeight(50)
        font.setItalic(False)
        font.setBold(False)
        aboutQSWAT.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8(":/plugins/qswat/QSWAT-Icon/QSWAT-Icon-SWAT-16.ico")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        aboutQSWAT.setWindowIcon(icon)
        aboutQSWAT.setSizeGripEnabled(False)
        self.gridLayout_2 = QtGui.QGridLayout(aboutQSWAT)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.gridLayout_2.addLayout(self.gridLayout, 0, 0, 3, 3)
        self.textBrowser = QtGui.QTextBrowser(aboutQSWAT)
        self.textBrowser.setObjectName(_fromUtf8("textBrowser"))
        self.gridLayout_2.addWidget(self.textBrowser, 1, 1, 1, 2)
        self.SWATHomeButton = QtGui.QPushButton(aboutQSWAT)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("MS Shell Dlg 2"))
        font.setWeight(50)
        font.setItalic(False)
        font.setBold(False)
        self.SWATHomeButton.setFont(font)
        self.SWATHomeButton.setObjectName(_fromUtf8("SWATHomeButton"))
        self.gridLayout_2.addWidget(self.SWATHomeButton, 2, 1, 1, 1)
        self.closeButton = QtGui.QPushButton(aboutQSWAT)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("MS Shell Dlg 2"))
        font.setWeight(50)
        font.setItalic(False)
        font.setBold(False)
        self.closeButton.setFont(font)
        self.closeButton.setObjectName(_fromUtf8("closeButton"))
        self.gridLayout_2.addWidget(self.closeButton, 2, 2, 1, 1)

        self.retranslateUi(aboutQSWAT)
        QtCore.QMetaObject.connectSlotsByName(aboutQSWAT)

    def retranslateUi(self, aboutQSWAT):
        aboutQSWAT.setWindowTitle(QtGui.QApplication.translate("aboutQSWAT", "About QSWAT", None, QtGui.QApplication.UnicodeUTF8))
        self.SWATHomeButton.setText(QtGui.QApplication.translate("aboutQSWAT", "SWAT home page", None, QtGui.QApplication.UnicodeUTF8))
        self.closeButton.setText(QtGui.QApplication.translate("aboutQSWAT", "Close", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
