# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'edit_0523.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_EditDialog(object):
    def setupUi(self, EditDialog):
        EditDialog.setObjectName(_fromUtf8("EditDialog"))
        EditDialog.resize(369, 261)
        self.Weather_lineEdit = QtGui.QLineEdit(EditDialog)
        self.Weather_lineEdit.setGeometry(QtCore.QRect(20, 80, 271, 20))
        self.Weather_lineEdit.setObjectName(_fromUtf8("Weather_lineEdit"))
        self.Weather_pushButton = QtGui.QPushButton(EditDialog)
        self.Weather_pushButton.setGeometry(QtCore.QRect(300, 80, 51, 23))
        self.Weather_pushButton.setObjectName(_fromUtf8("Weather_pushButton"))
        self.OPS_lineEdit = QtGui.QLineEdit(EditDialog)
        self.OPS_lineEdit.setGeometry(QtCore.QRect(20, 130, 271, 20))
        self.OPS_lineEdit.setObjectName(_fromUtf8("OPS_lineEdit"))
        self.OPS_pushButton = QtGui.QPushButton(EditDialog)
        self.OPS_pushButton.setGeometry(QtCore.QRect(300, 130, 51, 23))
        self.OPS_pushButton.setObjectName(_fromUtf8("OPS_pushButton"))
        self.Weather_label = QtGui.QLabel(EditDialog)
        self.Weather_label.setGeometry(QtCore.QRect(20, 60, 161, 16))
        self.Weather_label.setObjectName(_fromUtf8("Weather_label"))
        self.OPS_label = QtGui.QLabel(EditDialog)
        self.OPS_label.setGeometry(QtCore.QRect(20, 110, 161, 16))
        self.OPS_label.setObjectName(_fromUtf8("OPS_label"))
        self.Run_pushButton = QtGui.QPushButton(EditDialog)
        self.Run_pushButton.setGeometry(QtCore.QRect(200, 220, 71, 31))
        self.Run_pushButton.setObjectName(_fromUtf8("Run_pushButton"))
        self.Cancel_pushButton = QtGui.QPushButton(EditDialog)
        self.Cancel_pushButton.setGeometry(QtCore.QRect(280, 220, 71, 31))
        self.Cancel_pushButton.setObjectName(_fromUtf8("Cancel_pushButton"))
        self.parm_pushButton = QtGui.QPushButton(EditDialog)
        self.parm_pushButton.setGeometry(QtCore.QRect(20, 220, 71, 31))
        self.parm_pushButton.setObjectName(_fromUtf8("parm_pushButton"))
        self.Set_pushButton = QtGui.QPushButton(EditDialog)
        self.Set_pushButton.setGeometry(QtCore.QRect(300, 180, 51, 23))
        self.Set_pushButton.setObjectName(_fromUtf8("Set_pushButton"))
        self.APEXCONT_comboBox = QtGui.QComboBox(EditDialog)
        self.APEXCONT_comboBox.setGeometry(QtCore.QRect(90, 180, 201, 22))
        self.APEXCONT_comboBox.setObjectName(_fromUtf8("APEXCONT_comboBox"))
        self.APEXCONT_label = QtGui.QLabel(EditDialog)
        self.APEXCONT_label.setGeometry(QtCore.QRect(20, 160, 111, 16))
        self.APEXCONT_label.setObjectName(_fromUtf8("APEXCONT_label"))
        self.MDB_label = QtGui.QLabel(EditDialog)
        self.MDB_label.setGeometry(QtCore.QRect(20, 10, 191, 16))
        self.MDB_label.setObjectName(_fromUtf8("MDB_label"))
        self.MDB_lineEdit = QtGui.QLineEdit(EditDialog)
        self.MDB_lineEdit.setGeometry(QtCore.QRect(20, 30, 271, 20))
        self.MDB_lineEdit.setObjectName(_fromUtf8("MDB_lineEdit"))
        self.MDB_pushButton = QtGui.QPushButton(EditDialog)
        self.MDB_pushButton.setGeometry(QtCore.QRect(300, 30, 51, 23))
        self.MDB_pushButton.setObjectName(_fromUtf8("MDB_pushButton"))
        self.APEXCONT_pushButton = QtGui.QPushButton(EditDialog)
        self.APEXCONT_pushButton.setGeometry(QtCore.QRect(20, 180, 61, 23))
        self.APEXCONT_pushButton.setObjectName(_fromUtf8("APEXCONT_pushButton"))
        self.Scenario_lineEdit = QtGui.QLineEdit(EditDialog)
        self.Scenario_lineEdit.setGeometry(QtCore.QRect(100, 230, 91, 20))
        self.Scenario_lineEdit.setObjectName(_fromUtf8("Scenario_lineEdit"))
        self.Scenario_label = QtGui.QLabel(EditDialog)
        self.Scenario_label.setGeometry(QtCore.QRect(100, 210, 91, 16))
        self.Scenario_label.setObjectName(_fromUtf8("Scenario_label"))

        self.retranslateUi(EditDialog)
        QtCore.QMetaObject.connectSlotsByName(EditDialog)
        EditDialog.setTabOrder(self.MDB_lineEdit, self.MDB_pushButton)
        EditDialog.setTabOrder(self.MDB_pushButton, self.Weather_lineEdit)
        EditDialog.setTabOrder(self.Weather_lineEdit, self.Weather_pushButton)
        EditDialog.setTabOrder(self.Weather_pushButton, self.OPS_lineEdit)
        EditDialog.setTabOrder(self.OPS_lineEdit, self.OPS_pushButton)
        EditDialog.setTabOrder(self.OPS_pushButton, self.APEXCONT_pushButton)
        EditDialog.setTabOrder(self.APEXCONT_pushButton, self.APEXCONT_comboBox)
        EditDialog.setTabOrder(self.APEXCONT_comboBox, self.Set_pushButton)
        EditDialog.setTabOrder(self.Set_pushButton, self.parm_pushButton)
        EditDialog.setTabOrder(self.parm_pushButton, self.Scenario_lineEdit)
        EditDialog.setTabOrder(self.Scenario_lineEdit, self.Run_pushButton)
        EditDialog.setTabOrder(self.Run_pushButton, self.Cancel_pushButton)

    def retranslateUi(self, EditDialog):
        EditDialog.setWindowTitle(QtGui.QApplication.translate("EditDialog", "QAPEX", None, QtGui.QApplication.UnicodeUTF8))
        self.Weather_pushButton.setText(QtGui.QApplication.translate("EditDialog", ". . .", None, QtGui.QApplication.UnicodeUTF8))
        self.OPS_pushButton.setText(QtGui.QApplication.translate("EditDialog", ". . .", None, QtGui.QApplication.UnicodeUTF8))
        self.Weather_label.setText(QtGui.QApplication.translate("EditDialog", "Select weather folder", None, QtGui.QApplication.UnicodeUTF8))
        self.OPS_label.setText(QtGui.QApplication.translate("EditDialog", "Select OPS folder", None, QtGui.QApplication.UnicodeUTF8))
        self.Run_pushButton.setText(QtGui.QApplication.translate("EditDialog", "Run", None, QtGui.QApplication.UnicodeUTF8))
        self.Cancel_pushButton.setText(QtGui.QApplication.translate("EditDialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))
        self.parm_pushButton.setText(QtGui.QApplication.translate("EditDialog", "Edit parms", None, QtGui.QApplication.UnicodeUTF8))
        self.Set_pushButton.setText(QtGui.QApplication.translate("EditDialog", "Apply", None, QtGui.QApplication.UnicodeUTF8))
        self.APEXCONT_label.setText(QtGui.QApplication.translate("EditDialog", "Select APEXCONT", None, QtGui.QApplication.UnicodeUTF8))
        self.MDB_label.setText(QtGui.QApplication.translate("EditDialog", "Select APEX MDB File", None, QtGui.QApplication.UnicodeUTF8))
        self.MDB_pushButton.setText(QtGui.QApplication.translate("EditDialog", ". . .", None, QtGui.QApplication.UnicodeUTF8))
        self.APEXCONT_pushButton.setText(QtGui.QApplication.translate("EditDialog", "New", None, QtGui.QApplication.UnicodeUTF8))
        self.Scenario_label.setText(QtGui.QApplication.translate("EditDialog", "Scenario name", None, QtGui.QApplication.UnicodeUTF8))

