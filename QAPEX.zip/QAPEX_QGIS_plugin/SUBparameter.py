# -*- coding: utf-8 -*-

# Import the PyQt and QGIS libraries
from PyQt4.QtCore import * # @UnusedWildImport
from PyQt4.QtGui import * # @UnusedWildImport
from qgis.core import * # @UnusedWildImport
# Import the code for the dialog
from SUBparameterdialog import SUBParameterDialog
import takeapex, Termdict
from QSWATUtils import QSWATUtils
import os.path, re



class SUBParameter(QObject):

    def __init__(self, iface, gv):
        QObject.__init__(self)
        self._iface = iface
        self._gv = gv
        self._dlg = SUBParameterDialog()
        self._dlg.setWindowFlags(self._dlg.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self._set = takeapex.SuperClass()
        
        self._dict = Termdict.Term_Dict()
        self._Des_dict = self._dict._Des_dict
        self._Subbasin_num = "0"
        self._Subbasin_list = []

    def init(self):
        """Set connections to controls."""
        settings = QSettings()

        #HLU Combobox add
        self._dlg.comboBox.clear()
        self._dlg.HLU_comboBox.clear()
        SUBParameter._path = self._gv.projDir
        f = open(SUBParameter._path+"/Source/MDB_path.txt", "r")
        SUBParameter._MDB_path = f.readline()
        f.close()
        
        Read = self._set.Read_MDB(SUBParameter._MDB_path, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(SUBParameter._path+"/Scenarios/sample/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x] #g_line[1] = WINAPEX.SUB

        f = open(SUBParameter._path+"/Scenarios/sample/"+g_line[1],"r")
        SUBParameter._lines = f.readlines()
        f.close()
        
        count = 0
        self._Subbasin_sub = []
        self._Subbasin_list = [[x,[]] for x in range(1, len(SUBParameter._lines)/12+1)]#
        for n in range(0,len(SUBParameter._lines)):
            count += 1
            if count % 12 == 1:
                if count + 5 <len(SUBParameter._lines):
                    f_line_strip = SUBParameter._lines[n].strip().split(" ")
                    f_line = [x for x in f_line_strip if x]

                    self._Subbasin_list[int(f_line[5])-1][1].append(f_line[0])#
                    self._Subbasin_sub.append(int(f_line[5]))
                #des. [[subbasin_1, [HRU_1, HRU_2], [subbasin_2, [HRU_1, HRU_2, HRU_3]], extra_subbasin...] 

        self._Subbasin_sub = list(set(self._Subbasin_sub))
        self._Subbasin_sub.sort()
        #des. HRU_sub = [HRU_1, HRU_2, ... , HRU_9999]
        #des. Subbasin_sub = [Subbasin_1, Subbasin_2, ... , Subbasin_9999]

        for Subbasin in self._Subbasin_sub:
            self._dlg.comboBox.addItem(str(Subbasin))
            
        self._dlg.comboBox.addItem("all")
       
        count = 0
        for remove_list in self._Subbasin_list:
            count += 1
            if count > len(self._Subbasin_sub):
                self._Subbasin_list.remove(self._Subbasin_list[count-1])
            #des. Subbasin_list = [[subbasin_1, [HRU_1, HRU_2], [subbasin_2, [HRU_1, HRU_2, HRU_3]]]

        self._dlg.comboBox.currentIndexChanged.connect(self.Subbasin_set)
        self._dlg.Set_push.clicked.connect(self.APEXSUB_set)
        self._dlg.Save_pushButton.clicked.connect(self.doSave)
        self._dlg.Cancel_pushButton.clicked.connect(self.doClose)
        self._dlg.Notes_push.clicked.connect(self.Describe)

    def run(self):
        self.init()
        self._dlg.show()

        result = self._dlg.exec_()  # @UnusedVariable
        self._gv.delineatePos = self._dlg.pos()
        self._gv.writeMasterProgress(0,0)
        return 0

    def Subbasin_set(self):
        self._dlg.HLU_comboBox.clear()
        self._Subbasin_num = str(self._dlg.comboBox.currentText())
        #HRU_sub = [HRU_1, HRU_2, ... , HRU_9999]
        #Subbasin_sub = [Subbasin_1, Subbasin_2, ... , Subbasin_9999]
        #Subbasin_list = [[subbasin_1, [HRU_1, HRU_2], [subbasin_2, [HRU_1, HRU_2, HRU_3]]]        for Subbasin in Subbasin_list

        for Subbasin in self._Subbasin_list:
            if str(Subbasin[0]) == self._Subbasin_num:
                for Subbasin_add in Subbasin[1]:
                    self._dlg.HLU_comboBox.addItem(str(Subbasin_add))
                    
        if self._Subbasin_num == "all":
            self._dlg.HLU_comboBox.addItem("all")
            
        self._dlg.HLU_comboBox.setCurrentIndex(0)
        
    """
    def HRU_set(self):
        self._dlg.comboBox.clear()
        self._HRU_num = str(self._dlg.HLU_comboBox.currentText())
        for Subbasin in self._Subbasin_list:
            for HRU in Subbasin[1]:
                if str(HRU) == self._HRU_num:
                    Subbasin_index = self._dlg.comboBox.findText(str(Subbasin), QtCore.Qt.MatchFixedString)
                    self._dlg.comboBox.setCurrentIndex(Subbasin_index)
    """
    

    def APEXSUB_set(self): #comboBOX 읽어서 12*n 으로 계산하기(불러오기). + all 일때
        Read = self._set.Read_MDB(SUBParameter._MDB_path, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(SUBParameter._path+"/Scenarios/sample/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x] #g_line[1] = WINAPEX.SUB
            
        f = open(SUBParameter._path+"/Scenarios/sample/"+g_line[1],"r")
        f_lines = f.readlines()
        f.close()

        self._Subbasin_num = str(self._dlg.HLU_comboBox.currentText()) 
        if self._Subbasin_num == "all":
            self._dlg.SNUM_line.setText("-")
            self._dlg.TNUM_line.setText("-")
            self._dlg.WSID_line.setText("-")
            self._dlg.TITLE_line.setText("-")
            self._dlg.INPS_line.setText("-")
            self._dlg.IOPS_line.setText("-")
            self._dlg.IOW_line.setText("-")
            self._dlg.II_line.setText("-")
            self._dlg.IAPL_line.setText("-")
            self._dlg.NVCN_line.setText("-")
            self._dlg.WITH_line.setText("-")
            self._dlg.IPTS_line.setText("-")
            self._dlg.ISAO_line.setText("-")
            self._dlg.LUNS_line.setText("-")
            self._dlg.IMW_line.setText("-")
            self._dlg.SNO_line.setText("-")
            self._dlg.STDO_line.setText("-")
            self._dlg.YCT_line.setText("-")
            self._dlg.XCT_line.setText("-")
            self._dlg.AZM_line.setText("-")
            self._dlg.FL_line.setText("-")
            self._dlg.FW_line.setText("-")
            self._dlg.ANGL_line.setText("-")
            self._dlg.WSA_line.setText("-")
            self._dlg.CHL_line.setText("-")
            self._dlg.CHD_line.setText("-")
            self._dlg.CHS_line.setText("-")
            self._dlg.CHN_line.setText("-")
            self._dlg.SLP_line.setText("-")
            self._dlg.SLPG_line.setText("-")
            self._dlg.UPN_line.setText("-")
            self._dlg.FFPQ_line.setText("-")
            self._dlg.URBF_line.setText("-")
            self._dlg.RCHL_line.setText("-")
            self._dlg.RCHD_line.setText("-")
            self._dlg.RCBW_line.setText("-")
            self._dlg.RCTW_line.setText("-")
            self._dlg.RCHS_line.setText("-")
            self._dlg.RCHN_line.setText("-")
            self._dlg.RCHC_line.setText("-")
            self._dlg.RCHK_line.setText("-")
            self._dlg.RFPW_line.setText("-")
            self._dlg.RFPL_line.setText("-")
            self._dlg.RSEE_line.setText("-")
            self._dlg.RSAE_line.setText("-")
            self._dlg.RSVE_line.setText("-")
            self._dlg.RSEP_line.setText("-")
            self._dlg.RSAP_line.setText("-")
            self._dlg.RSVP_line.setText("-")
            self._dlg.RSV_line.setText("-")
            self._dlg.RSRR_line.setText("-")
            self._dlg.RSYS_line.setText("-")
            self._dlg.RSYN_line.setText("-")
            self._dlg.RSHC_line.setText("-")
            self._dlg.RSDP_line.setText("-")
            self._dlg.RSBD_line.setText("-")
            self._dlg.PCOF_line.setText("-")
            self._dlg.BCOF_line.setText("-")
            self._dlg.BFFL_line.setText("-")            
            self._dlg.NIRR_line.setText("-")
            self._dlg.IRI_line.setText("-")
            self._dlg.IFA_line.setText("-")
            self._dlg.LM_line.setText("-")
            self._dlg.IFD_line.setText("-")
            self._dlg.IDR_line.setText("-")
            self._dlg.IDF1_line.setText("-")
            self._dlg.IDF2_line.setText("-")
            self._dlg.IDF3_line.setText("-")
            self._dlg.IDF4_line.setText("-")
            self._dlg.IDF5_line.setText("-")
            self._dlg.BIR_line.setText("-")
            self._dlg.EFI_line.setText("-")
            self._dlg.VIMX_line.setText("-")
            self._dlg.ARMN_line.setText("-")
            self._dlg.ARMX_line.setText("-")
            self._dlg.BFT_line.setText("-")
            self._dlg.FNP4_line.setText("-")
            self._dlg.FMX_line.setText("-")
            self._dlg.DRT_line.setText("-")
            self._dlg.FDSF_line.setText("-")
            self._dlg.PEC_line.setText("-")
            self._dlg.DALG_line.setText("-")
            self._dlg.VLGN_line.setText("-")
            self._dlg.COWW_line.setText("-")
            self._dlg.DDLG_line.setText("-")
            self._dlg.SOLQ_line.setText("-")
            self._dlg.SFLG_line.setText("-")
            self._dlg.FNP2_line.setText("-")
            self._dlg.FNP5_line.setText("-")
            self._dlg.FIRG_line.setText("-")
            self._dlg.NY1_line.setText("-")
            self._dlg.NY2_line.setText("-")
            self._dlg.NY3_line.setText("-")
            self._dlg.NY4_line.setText("-")
            self._dlg.NY5_line.setText("-")
            self._dlg.NY6_line.setText("-")
            self._dlg.NY7_line.setText("-")
            self._dlg.NY8_line.setText("-")
            self._dlg.NY9_line.setText("-")
            self._dlg.NY10_line.setText("-")
            self._dlg.XTP1_line.setText("-")
            self._dlg.XTP2_line.setText("-")
            self._dlg.XTP3_line.setText("-")
            self._dlg.XTP4_line.setText("-")
            self._dlg.XTP5_line.setText("-")
            self._dlg.XTP6_line.setText("-")
            self._dlg.XTP7_line.setText("-")
            self._dlg.XTP8_line.setText("-")
            self._dlg.XTP9_line.setText("-")
            self._dlg.XTP10_line.setText("-")
        else:
            ##sub_line = 12*(int(self._Subbasin_num)-1)
            for n in range(0, len(f_lines)):
                if (n % 12 == 0 and len(f_lines) > n+7):

                    f_1_strip = f_lines[n].strip().split(" ")
                    f_1 = [x for x in f_1_strip if x]

                    if str(f_1[0]) == str(self._Subbasin_num):
                        #line_1
                        f_line_strip = f_lines[n].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.SNUM_line.setText(f_line[0])
                        self._dlg.TNUM_line.setText(f_line[1])
                        self._dlg.WSID_line.setText(f_line[2])
                        self._dlg.TITLE_line.setText(f_line[7])
                        #line_2
                        f_line_strip = f_lines[n + 1].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.INPS_line.setText(f_line[0])
                        self._dlg.IOPS_line.setText(f_line[1])
                        self._dlg.IOW_line.setText(f_line[2])
                        self._dlg.II_line.setText(f_line[3])
                        self._dlg.IAPL_line.setText(f_line[4])#
                        self._dlg.NVCN_line.setText(f_line[6])
                        self._dlg.WITH_line.setText(f_line[7])
                        self._dlg.IPTS_line.setText(f_line[8])
                        self._dlg.ISAO_line.setText(f_line[9])
                        self._dlg.LUNS_line.setText(f_line[10])
                        self._dlg.IMW_line.setText(f_line[11])
                        #line_3
                        f_line_strip = f_lines[n + 2].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.SNO_line.setText(f_line[0])
                        self._dlg.STDO_line.setText(f_line[1])
                        self._dlg.YCT_line.setText(f_line[2])
                        self._dlg.XCT_line.setText(f_line[3])
                        self._dlg.AZM_line.setText(f_line[4])
                        self._dlg.FL_line.setText(f_line[5])
                        self._dlg.FW_line.setText(f_line[6])
                        self._dlg.ANGL_line.setText(f_line[7])
                        #line_4
                        f_line_strip = f_lines[n + 3].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.WSA_line.setText(f_line[0])
                        self._dlg.CHL_line.setText(f_line[1])
                        self._dlg.CHD_line.setText(f_line[2])
                        self._dlg.CHS_line.setText(f_line[3])
                        self._dlg.CHN_line.setText(f_line[4])
                        self._dlg.SLP_line.setText(f_line[5])
                        self._dlg.SLPG_line.setText(f_line[6])
                        self._dlg.UPN_line.setText(f_line[7])
                        self._dlg.FFPQ_line.setText(f_line[8])
                        self._dlg.URBF_line.setText(f_line[9])
                        #line_5
                        f_line_strip = f_lines[n + 4].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.RCHL_line.setText(f_line[0])
                        self._dlg.RCHD_line.setText(f_line[1])
                        self._dlg.RCBW_line.setText(f_line[2])
                        self._dlg.RCTW_line.setText(f_line[3])
                        self._dlg.RCHS_line.setText(f_line[4])
                        self._dlg.RCHN_line.setText(f_line[5])
                        self._dlg.RCHC_line.setText(f_line[6])
                        self._dlg.RCHK_line.setText(f_line[7])
                        self._dlg.RFPW_line.setText(f_line[8])
                        self._dlg.RFPL_line.setText(f_line[9])
                        #line_6
                        f_line_strip = f_lines[n + 5].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.RSEE_line.setText(f_line[0])
                        self._dlg.RSAE_line.setText(f_line[1])
                        self._dlg.RSVE_line.setText(f_line[2])
                        self._dlg.RSEP_line.setText(f_line[3])
                        self._dlg.RSAP_line.setText(f_line[4])
                        self._dlg.RSVP_line.setText(f_line[5])
                        self._dlg.RSV_line.setText(f_line[6])
                        self._dlg.RSRR_line.setText(f_line[7])
                        self._dlg.RSYS_line.setText(f_line[8])
                        self._dlg.RSYN_line.setText(f_line[9])
                        #line_7
                        f_line_strip = f_lines[n + 6].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.RSHC_line.setText(f_line[0])
                        self._dlg.RSDP_line.setText(f_line[1])
                        self._dlg.RSBD_line.setText(f_line[2])
                        self._dlg.PCOF_line.setText(f_line[3])
                        self._dlg.BCOF_line.setText(f_line[4])
                        self._dlg.BFFL_line.setText(f_line[5])            
                        #line_8
                        f_line_strip = f_lines[n + 7].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.NIRR_line.setText(f_line[0])
                        self._dlg.IRI_line.setText(f_line[1])
                        self._dlg.IFA_line.setText(f_line[2])
                        self._dlg.LM_line.setText(f_line[3])
                        self._dlg.IFD_line.setText(f_line[4])
                        self._dlg.IDR_line.setText(f_line[5])
                        self._dlg.IDF1_line.setText(f_line[6])
                        self._dlg.IDF2_line.setText(f_line[7])
                        self._dlg.IDF3_line.setText(f_line[8])
                        self._dlg.IDF4_line.setText(f_line[9])
                        self._dlg.IDF5_line.setText(f_line[10])
                        #line_9
                        f_line_strip = f_lines[n + 8].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.BIR_line.setText(f_line[0])
                        self._dlg.EFI_line.setText(f_line[1])
                        self._dlg.VIMX_line.setText(f_line[2])
                        self._dlg.ARMN_line.setText(f_line[3])
                        self._dlg.ARMX_line.setText(f_line[4])
                        self._dlg.BFT_line.setText(f_line[5])
                        self._dlg.FNP4_line.setText(f_line[6])
                        self._dlg.FMX_line.setText(f_line[7])
                        self._dlg.DRT_line.setText(f_line[8])
                        self._dlg.FDSF_line.setText(f_line[9])
                        #line_10
                        f_line_strip = f_lines[n + 9].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.PEC_line.setText(f_line[0])
                        self._dlg.DALG_line.setText(f_line[1])
                        self._dlg.VLGN_line.setText(f_line[2])
                        self._dlg.COWW_line.setText(f_line[3])
                        self._dlg.DDLG_line.setText(f_line[4])
                        self._dlg.SOLQ_line.setText(f_line[5])
                        self._dlg.SFLG_line.setText(f_line[6])
                        self._dlg.FNP2_line.setText(f_line[7])
                        self._dlg.FNP5_line.setText(f_line[8])
                        self._dlg.FIRG_line.setText(f_line[9])
                        #line_11
                        f_line_strip = f_lines[n + 10].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.NY1_line.setText(f_line[0])
                        self._dlg.NY2_line.setText(f_line[1])
                        self._dlg.NY3_line.setText(f_line[2])
                        self._dlg.NY4_line.setText(f_line[3])
                        self._dlg.NY5_line.setText(f_line[4])
                        self._dlg.NY6_line.setText(f_line[5])
                        self._dlg.NY7_line.setText(f_line[6])
                        self._dlg.NY8_line.setText(f_line[7])
                        self._dlg.NY9_line.setText(f_line[8])
                        self._dlg.NY10_line.setText(f_line[9])
                        #line_12
                        f_line_strip = f_lines[n + 11].strip().split(" ")
                        f_line = [x for x in f_line_strip if x]
                        self._dlg.XTP1_line.setText(f_line[0])
                        self._dlg.XTP2_line.setText(f_line[1])
                        self._dlg.XTP3_line.setText(f_line[2])
                        self._dlg.XTP4_line.setText(f_line[3])
                        self._dlg.XTP5_line.setText(f_line[4])
                        self._dlg.XTP6_line.setText(f_line[5])
                        self._dlg.XTP7_line.setText(f_line[6])
                        self._dlg.XTP8_line.setText(f_line[7])
                        self._dlg.XTP9_line.setText(f_line[8])
                        self._dlg.XTP10_line.setText(f_line[9])
        return

    def Describe(self):
        try:
            self._dlg.Notes_text.setText(self._Des_dict[str(self._dlg.Notes_lineEdit.text())])
        except KeyError:
            self._dlg.Notes_text.setText(" ")
        return

    def doSave(self):
        #1. 기존 WINAPEX.SUB 읽기, 복사, 삭제
        #2.
        Read = self._set.Read_MDB(SUBParameter._MDB_path, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(SUBParameter._path+"/Scenarios/sample/"+line[2], "r") 
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x] #g_line[1] = WINAPEX.SUB

        f = open(SUBParameter._path+"/Scenarios/sample/"+g_line[1],"r")
        lines = f.readlines()
        f.close()

        if os.path.isfile(SUBParameter._path+"/Scenarios/sample/"+g_line[1]):
            os.remove(SUBParameter._path+"/Scenarios/sample/"+g_line[1])
        
        if self._Subbasin_num == "all":
            g = open(SUBParameter._path+"/Scenarios/sample/"+g_line[1],"a")
            for n in range(0, len(lines)):
                if not lines[n] == "\n":
                    if (n % 12 == 0 and len(lines) > n+7):
                        g_1_strip = lines[n].strip().split(" ")
                        g_1 = [x for x in g_1_strip if x]
                        g_2_strip = lines[n+1].strip().split(" ")
                        g_2 = [x for x in g_2_strip if x]
                        g_3_strip = lines[n+2].strip().split(" ")
                        g_3 = [x for x in g_3_strip if x]
                        g_4_strip = lines[n+3].strip().split(" ")
                        g_4 = [x for x in g_4_strip if x]
                        g_5_strip = lines[n+4].strip().split(" ")
                        g_5 = [x for x in g_5_strip if x]
                        g_6_strip = lines[n+5].strip().split(" ")
                        g_6 = [x for x in g_6_strip if x]
                        g_7_strip = lines[n+6].strip().split(" ")
                        g_7 = [x for x in g_7_strip if x]
                        g_8_strip = lines[n+7].strip().split(" ")
                        g_8 = [x for x in g_8_strip if x]
                        g_9_strip = lines[n+8].strip().split(" ")
                        g_9 = [x for x in g_9_strip if x]
                        g_10_strip = lines[n+9].strip().split(" ")
                        g_10 = [x for x in g_10_strip if x]
                        g_11_strip = lines[n+10].strip().split(" ")
                        g_11 = [x for x in g_11_strip if x]
                        g_12_strip = lines[n+11].strip().split(" ")
                        g_12 = [x for x in g_12_strip if x]
                        
                        #self.All_sub(self, parm, g_sub, num)
                        
                        g.write("{:>8d}{:>8d}{:>8d} {}  {} ! {}\n".format(int(self.All_sub(self._dlg.SNUM_line.text(), g_1, 0)),int(self.All_sub(self._dlg.SNUM_line.text(), g_1, 1)),int(self.All_sub(self._dlg.WSID_line.text(), g_1, 2)),g_1[3]+" "+g_1[4],int(g_1[5]),self.All_sub(self._dlg.TITLE_line.text(), g_1, 7)))
                        g.write("{:>8d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}\n".format(int(self.All_sub(self._dlg.INPS_line.text(), g_2, 0)),int(self.All_sub(self._dlg.IOPS_line.text(), g_2, 1)),int(self.All_sub(self._dlg.IOW_line.text(), g_2, 2)),int(self.All_sub(self._dlg.II_line.text(), g_2, 3)),int(self.All_sub(self._dlg.IAPL_line.text(), g_2, 4)),0,int(self.All_sub(self._dlg.NVCN_line.text(), g_2, 5)),int(self.All_sub(self._dlg.WITH_line.text(), g_2, 6)),int(self.All_sub(self._dlg.IPTS_line.text(), g_2, 7)),int(self.All_sub(self._dlg.ISAO_line.text(), g_2, 8)),int(self.All_sub(self._dlg.LUNS_line.text(), g_2, 9)),int(self.All_sub(self._dlg.IMW_line.text(), g_2, 1))))
                        g.write("{:>12.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(float(self.All_sub(self._dlg.SNO_line.text(), g_3, 0)),float(self.All_sub(self._dlg.STDO_line.text(), g_3, 1)),float(self.All_sub(self._dlg.YCT_line.text(), g_3, 2)),float(self.All_sub(self._dlg.XCT_line.text(), g_3, 3)),float(self.All_sub(self._dlg.AZM_line.text(), g_3, 4)),float(self.All_sub(self._dlg.FL_line.text(), g_3, 5)),float(self.All_sub(self._dlg.FW_line.text(), g_3, 6)),float(self.All_sub(self._dlg.ANGL_line.text(), g_3, 1))))
                        g.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.4f}{:>13.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self.All_sub(self._dlg.WSA_line.text(), g_4, 0)),float(self.All_sub(self._dlg.CHL_line.text(), g_4, 1)),float(self.All_sub(self._dlg.CHD_line.text(), g_4, 2)),float(self.All_sub(self._dlg.CHS_line.text(), g_4, 3)),float(self.All_sub(self._dlg.CHN_line.text(), g_4, 4)),float(self.All_sub(self._dlg.SLP_line.text(), g_4, 5)),float(self.All_sub(self._dlg.SLPG_line.text(), g_4, 6)),float(self.All_sub(self._dlg.UPN_line.text(), g_4, 7)),float(self.All_sub(self._dlg.FFPQ_line.text(), g_4, 8)),float(self.All_sub(self._dlg.URBF_line.text(), g_4, 1))))
                        g.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.5f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self.All_sub(self._dlg.RCHL_line.text(), g_5, 0)),float(self.All_sub(self._dlg.RCHD_line.text(), g_5, 1)),float(self.All_sub(self._dlg.RCBW_line.text(), g_5, 2)),float(self.All_sub(self._dlg.RCTW_line.text(), g_5, 3)),float(self.All_sub(self._dlg.RCHS_line.text(), g_5, 4)),float(self.All_sub(self._dlg.RCHN_line.text(), g_5, 5)),float(self.All_sub(self._dlg.RCHC_line.text(), g_5, 6)),float(self.All_sub(self._dlg.RCHK_line.text(), g_5, 7)),float(self.All_sub(self._dlg.RFPW_line.text(), g_5, 8)),float(self.All_sub(self._dlg.RFPL_line.text(), g_5, 1))))
                        g.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self.All_sub(self._dlg.RSEE_line.text(), g_6, 0)),float(self.All_sub(self._dlg.RSAE_line.text(), g_6, 1)),float(self.All_sub(self._dlg.RSVE_line.text(), g_6, 2)),float(self.All_sub(self._dlg.RSEP_line.text(), g_6, 3)),float(self.All_sub(self._dlg.RSAP_line.text(), g_6, 4)),float(self.All_sub(self._dlg.RSVP_line.text(), g_6, 5)),float(self.All_sub(self._dlg.RSV_line.text(), g_6, 6)),float(self.All_sub(self._dlg.RSRR_line.text(), g_6, 7)),float(self.All_sub(self._dlg.RSYS_line.text(), g_6, 8)),float(self.All_sub(self._dlg.RSYN_line.text(), g_6, 1))))
                        g.write("{:>12.6f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self.All_sub(self._dlg.RSHC_line.text(), g_7, 0)),float(self.All_sub(self._dlg.RSDP_line.text(), g_7, 1)),float(self.All_sub(self._dlg.RSBD_line.text(), g_7, 2)),float(self.All_sub(self._dlg.PCOF_line.text(), g_7, 3)),float(self.All_sub(self._dlg.BCOF_line.text(), g_7, 4)),float(self.All_sub(self._dlg.BFFL_line.text(), g_7, 1))))
                        g.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(self.All_sub(self._dlg.NIRR_line.text(), g_8, 0)),int(self.All_sub(self._dlg.IRI_line.text(), g_8, 1)),int(self.All_sub(self._dlg.IFA_line.text(), g_8, 2)),int(self.All_sub(self._dlg.LM_line.text(), g_8, 3)),int(self.All_sub(self._dlg.IFD_line.text(), g_8, 4)),int(self.All_sub(self._dlg.IDR_line.text(), g_8, 5)),int(self.All_sub(self._dlg.IDF1_line.text(), g_8, 6)),int(self.All_sub(self._dlg.IDF2_line.text(), g_8, 7)),int(self.All_sub(self._dlg.IDF3_line.text(), g_8, 8)),int(self.All_sub(self._dlg.IDF4_line.text(), g_8, 9)),int(self.All_sub(self._dlg.IDF5_line.text(), g_8, 10)),int(g_8[11]),int(g_8[12])))
                        g.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self.All_sub(self._dlg.BIR_line.text(), g_9, 0)),float(self.All_sub(self._dlg.EFI_line.text(), g_9, 1)),float(self.All_sub(self._dlg.VIMX_line.text(), g_9, 2)),float(self.All_sub(self._dlg.ARMN_line.text(), g_9, 3)),float(self.All_sub(self._dlg.ARMX_line.text(), g_9, 4)),float(self.All_sub(self._dlg.BFT_line.text(), g_9, 5)),float(self.All_sub(self._dlg.FNP4_line.text(), g_9, 6)),float(self.All_sub(self._dlg.FMX_line.text(), g_9, 7)),float(self.All_sub(self._dlg.DRT_line.text(), g_9, 8)),float(self.All_sub(self._dlg.FDSF_line.text(), g_9, 1))))
                        g.write("{:>12.4f}{:>13.2f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(float(self.All_sub(self._dlg.PEC_line.text(), g_10, 0)),float(self.All_sub(self._dlg.DALG_line.text(), g_10, 1)),float(self.All_sub(self._dlg.VLGN_line.text(), g_10, 2)),float(self.All_sub(self._dlg.COWW_line.text(), g_10, 3)),float(self.All_sub(self._dlg.DDLG_line.text(), g_10, 4)),float(self.All_sub(self._dlg.SOLQ_line.text(), g_10, 5)),float(self.All_sub(self._dlg.SFLG_line.text(), g_10, 6)),float(self.All_sub(self._dlg.FNP2_line.text(), g_10, 7)),float(self.All_sub(self._dlg.FNP5_line.text(), g_10, 8)),float(self.All_sub(self._dlg.FIRG_line.text(), g_10, 1))))
                        g.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(self.All_sub(self._dlg.NY1_line.text(), g_11, 0)),int(self.All_sub(self._dlg.NY2_line.text(), g_11, 1)),int(self.All_sub(self._dlg.NY3_line.text(), g_11, 2)),int(self.All_sub(self._dlg.NY4_line.text(), g_11, 3)),int(self.All_sub(self._dlg.NY5_line.text(), g_11, 4)),int(self.All_sub(self._dlg.NY6_line.text(), g_11, 5)),int(self.All_sub(self._dlg.NY7_line.text(), g_11, 6)),int(self.All_sub(self._dlg.NY8_line.text(), g_11, 7)),int(self.All_sub(self._dlg.NY9_line.text(), g_11, 8)),int(self.All_sub(self._dlg.NY10_line.text(), g_11, 1))))
                        g.write("{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}\n".format(float(self.All_sub(self._dlg.XTP1_line.text(), g_12, 0)),float(self.All_sub(self._dlg.XTP2_line.text(), g_12, 1)),float(self.All_sub(self._dlg.XTP3_line.text(), g_12, 2)),float(self.All_sub(self._dlg.XTP4_line.text(), g_12, 3)),float(self.All_sub(self._dlg.XTP5_line.text(), g_12, 4)),float(self.All_sub(self._dlg.XTP6_line.text(), g_12, 5)),float(self.All_sub(self._dlg.XTP7_line.text(), g_12, 6)),float(self.All_sub(self._dlg.XTP8_line.text(), g_12, 7)),float(self.All_sub(self._dlg.XTP9_line.text(), g_12, 8)),float(self.All_sub(self._dlg.XTP10_line.text(), g_12, 1))))
            g.write("\n\n")
            g.close()
            
        else:
            except_num = -12
            g = open(SUBParameter._path+"/Scenarios/sample/"+g_line[1],"a")
            for n in range(0, len(lines)):
                if (n % 12 == 0 and len(lines) > n+7):
                    g_1_strip = lines[n].strip().split(" ")
                    g_1 = [x for x in g_1_strip if x]
                    if str(g_1[0]) == self._Subbasin_num:
                        except_num = n
                        g_sub_strip = lines[n].strip().split(" ")
                        g_sub = [x for x in g_sub_strip if x]
                        g.write("{:>8d}{:>8d}{:>8d} {}  {} ! {}\n".format(int(self._dlg.SNUM_line.text()),int(self._dlg.TNUM_line.text()),int(self._dlg.WSID_line.text()),g_sub[3]+" "+g_sub[4],int(g_sub[5]),self._dlg.TITLE_line.text()))
                        g.write("{:>8d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}\n".format(int(self._dlg.INPS_line.text()),int(self._dlg.IOPS_line.text()),int(self._dlg.IOW_line.text()),int(self._dlg.II_line.text()),int(self._dlg.IAPL_line.text()),0,int(self._dlg.NVCN_line.text()),int(self._dlg.WITH_line.text()),int(self._dlg.IPTS_line.text()),int(self._dlg.ISAO_line.text()),int(self._dlg.LUNS_line.text()),int(self._dlg.IMW_line.text())))
                        g.write("{:>12.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(float(self._dlg.SNO_line.text()),float(self._dlg.STDO_line.text()),float(self._dlg.YCT_line.text()),float(self._dlg.XCT_line.text()),float(self._dlg.AZM_line.text()),float(self._dlg.FL_line.text()),float(self._dlg.FW_line.text()),float(self._dlg.ANGL_line.text())))
                        g.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.4f}{:>13.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._dlg.WSA_line.text()),float(self._dlg.CHL_line.text()),float(self._dlg.CHD_line.text()),float(self._dlg.CHS_line.text()),float(self._dlg.CHN_line.text()),float(self._dlg.SLP_line.text()),float(self._dlg.SLPG_line.text()),float(self._dlg.UPN_line.text()),float(self._dlg.FFPQ_line.text()),float(self._dlg.URBF_line.text())))
                        g.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.5f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._dlg.RCHL_line.text()),float(self._dlg.RCHD_line.text()),float(self._dlg.RCBW_line.text()),float(self._dlg.RCTW_line.text()),float(self._dlg.RCHS_line.text()),float(self._dlg.RCHN_line.text()),float(self._dlg.RCHC_line.text()),float(self._dlg.RCHK_line.text()),float(self._dlg.RFPW_line.text()),float(self._dlg.RFPL_line.text())))
                        g.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._dlg.RSEE_line.text()),float(self._dlg.RSAE_line.text()),float(self._dlg.RSVE_line.text()),float(self._dlg.RSEP_line.text()),float(self._dlg.RSAP_line.text()),float(self._dlg.RSVP_line.text()),float(self._dlg.RSV_line.text()),float(self._dlg.RSRR_line.text()),float(self._dlg.RSYS_line.text()),float(self._dlg.RSYN_line.text())))
                        g.write("{:>12.6f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._dlg.RSHC_line.text()),float(self._dlg.RSDP_line.text()),float(self._dlg.RSBD_line.text()),float(self._dlg.PCOF_line.text()),float(self._dlg.BCOF_line.text()),float(self._dlg.BFFL_line.text())))
                        g_sub_strip = lines[n+7].strip().split(" ")
                        g_sub = [x for x in g_sub_strip if x]
                        g.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(self._dlg.NIRR_line.text()),int(self._dlg.IRI_line.text()),int(self._dlg.IFA_line.text()),int(self._dlg.LM_line.text()),int(self._dlg.IFD_line.text()),int(self._dlg.IDR_line.text()),int(self._dlg.IDF1_line.text()),int(self._dlg.IDF2_line.text()),int(self._dlg.IDF3_line.text()),int(self._dlg.IDF4_line.text()),int(self._dlg.IDF5_line.text()),int(g_sub[11]),int(g_sub[12])))
                        g.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(self._dlg.BIR_line.text()),float(self._dlg.EFI_line.text()),float(self._dlg.VIMX_line.text()),float(self._dlg.ARMN_line.text()),float(self._dlg.ARMX_line.text()),float(self._dlg.BFT_line.text()),float(self._dlg.FNP4_line.text()),float(self._dlg.FMX_line.text()),float(self._dlg.DRT_line.text()),float(self._dlg.FDSF_line.text())))
                        g.write("{:>12.4f}{:>13.2f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(float(self._dlg.PEC_line.text()),float(self._dlg.DALG_line.text()),float(self._dlg.VLGN_line.text()),float(self._dlg.COWW_line.text()),float(self._dlg.DDLG_line.text()),float(self._dlg.SOLQ_line.text()),float(self._dlg.SFLG_line.text()),float(self._dlg.FNP2_line.text()),float(self._dlg.FNP5_line.text()),float(self._dlg.FIRG_line.text())))
                        g.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(self._dlg.NY1_line.text()),int(self._dlg.NY2_line.text()),int(self._dlg.NY3_line.text()),int(self._dlg.NY4_line.text()),int(self._dlg.NY5_line.text()),int(self._dlg.NY6_line.text()),int(self._dlg.NY7_line.text()),int(self._dlg.NY8_line.text()),int(self._dlg.NY9_line.text()),int(self._dlg.NY10_line.text())))
                        g.write("{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}\n".format(float(self._dlg.XTP1_line.text()),float(self._dlg.XTP2_line.text()),float(self._dlg.XTP3_line.text()),float(self._dlg.XTP4_line.text()),float(self._dlg.XTP5_line.text()),float(self._dlg.XTP6_line.text()),float(self._dlg.XTP7_line.text()),float(self._dlg.XTP8_line.text()),float(self._dlg.XTP9_line.text()),float(self._dlg.XTP10_line.text())))
                    else:
                        g.write(lines[n])
                elif except_num < n and n < except_num+12:
                    continue
                else:
                    g.write(lines[n])
            g.close()
        return

    def doClose(self):
        """Close form."""
        self._dlg.close()

    def All_sub(self, parm, g_sub, num):
        #parm  >>  self._dlg.SNUM_line.text()
        #g_sub  >>  g_1
        #num >> 0~12
        if str(parm) == "-":
            return g_sub[num]
        else:
            return parm
