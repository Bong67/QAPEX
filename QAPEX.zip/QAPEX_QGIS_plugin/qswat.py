# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QSWAT
                                 A QGIS plugin
 Create SWAT inputs
                              -------------------
        begin                : 2014-07-18
        copyright            : (C) 2014 by Chris George
        email                : cgeorge@mcmaster.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
# Import the PyQt and QGIS libraries
from PyQt4.QtCore import * # @UnusedWildImport
from PyQt4.QtGui import * # @UnusedWildImport
from qgis.core import * # @UnusedWildImport
import os.path
import subprocess
import time
# Import the code for the dialog
from qswatdialog import QSwatDialog
from hrus import HRUs
from QSWATUtils import QSWATUtils, FileTypes
from QSWATTopology import QSWATTopology
from globals import GlobalVars
from delineation import Delineation
from parameters import Parameters
from visualise import Visualise
from about import AboutQSWAT


class QSwat(QObject):
    """QGIS plugin to prepare geographic data for SWAT Editor."""
    _QSWATVERSION = '1.3'
    _SWATEDITORVERSION = Parameters._SWATEDITORVERSION
    _SLOPE_GROUP_NAME = 'Slope'
    _LANDUSE_GROUP_NAME = 'Landuse'
    _SOIL_GROUP_NAME = 'Soil'
    _WATERSHED_GROUP_NAME = 'Watershed'
    _RESULTS_GROUP_NAME = 'Results'

    def __init__(self, iface):
        """Constructor."""
        QObject.__init__(self)
        # uncomment next line for debugging
        # import pydevd; pydevd.settrace()
        # Save reference to the QGIS interface
        self._iface = iface
        # initialize plugin directory
        ## plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value("locale/userLocale")[0:2]
        localePath = os.path.join(self.plugin_dir, 'i18n', 'qswat_{}.qm'.format(locale))
        # set default behaviour for loading files with no CRS to prompt - the safest option
        QSettings().setValue('Projections/defaultBehaviour', 'prompt')
        ## translator
        if os.path.exists(localePath):
            self.translator = QTranslator()
            self.translator.load(localePath)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)
                
        self._gv = None  # set later
        # font = QFont('MS Shell Dlg 2', 8)
        # Create the dialog (after translation) and keep reference
        self._odlg = QSwatDialog()
        self._odlg.setWindowFlags(self._odlg.windowFlags() & ~Qt.WindowContextHelpButtonHint & Qt.WindowMinimizeButtonHint)
        self._odlg.move(0, 0)
        #=======================================================================
        # font = self._odlg.font()
        # fm = QFontMetrics(font)
        # txt = 'The quick brown fox jumps over the lazy dog.'
        # family = font.family()
        # size = font.pointSize()
        # QSWATUtils.information('Family: {2}.  Point size: {3!s}.\nWidth of "{0}" is {1} pixels.'.format(txt, fm.width(txt), family, size), False)
        #=======================================================================
        self._odlg.setWindowTitle('QSWAT {0}'.format(QSwat._QSWATVERSION))
        # flag used in initialising delineation form
        self._demIsProcessed = False
        
        # report QGIS version
        QSWATUtils.loginfo('QGIS version: {0}'.format(QGis.QGIS_VERSION))

    def initGui(self):
        """Create QSWAT button in the toolbar."""
        ## Action that will start plugin configuration
        self.action = QAction(
            QIcon(":/plugins/qswat/SWAT32.png"),
            u"QSWAT", self._iface.mainWindow())
        # connect the action to the run method
        self.action.triggered.connect(self.run)

        # Add toolbar button and menu item
        self._iface.addToolBarIcon(self.action)
        self._iface.addPluginToMenu(u"&QSWAT", self.action)

    def unload(self):
        """Remove the QSWAT menu item and icon."""
        self._iface.removePluginMenu(u"&QSWAT", self.action)
        self._iface.removeToolBarIcon(self.action)

    def run(self):
        """Run QSWAT."""
        self._odlg.reportsBox.setVisible(False)
        self._odlg.reportsLabel.setVisible(False)
        self._odlg.reportsBox.clear()
        self._odlg.reportsBox.addItem(QSWATUtils.trans('Select report to view'))
        # connect buttons
        self._odlg.aboutButton.clicked.connect(self.about)
        self._odlg.newButton.clicked.connect(self.newProject)
        self._odlg.existingButton.clicked.connect(self.existingProject)
        self._odlg.delinButton.clicked.connect(self.doDelineation)
        self._odlg.hrusButton.clicked.connect(self.doCreateHRUs)
        self._odlg.editButton.clicked.connect(self.startEditor)
        self._odlg.visualiseButton.clicked.connect(self.visualise)
        self._odlg.paramsButton.clicked.connect(self.runParams)
        self._odlg.reportsBox.activated.connect(self.showReport)
        self.initButtons()
        self._odlg.projPath.setText('')
        # show the dialog
        self._odlg.show()
        # initially only new/existing project buttons visible if project not set
        proj = QgsProject.instance()
        if proj.fileName() == '':
            self._odlg.mainBox.setVisible(False)
        else:
            self._iface.mainWindow().setCursor(Qt.WaitCursor)
            self.setupProject(proj, False)
            self._iface.mainWindow().setCursor(Qt.ArrowCursor)
        # Run the dialog event loop
        result = self._odlg.exec_() # @UnusedVariable
        #=======================================================================
        # # See if OK was pressed
        # if result == 1:
        #     # do something useful (delete the line containing pass and
        #     # substitute with your code)
        #=======================================================================
        
    def initButtons(self):
        """Initial button settings."""
        self._odlg.delinLabel.setText('Step 1')
        self._odlg.hrusLabel.setText('Step 2')
        self._odlg.hrusLabel.setEnabled(False)
        self._odlg.hrusButton.setEnabled(False)
        self._odlg.editLabel.setEnabled(False)
        self._odlg.editButton.setEnabled(False)
        self._odlg.visualiseLabel.setVisible(False)
        self._odlg.visualiseButton.setVisible(False)

    def about(self):
        """Show information about QSWAT."""
        form = AboutQSWAT(self._gv)
        form.run(QSwat._QSWATVERSION)
        
    def newProject(self):
        """Call QGIS actions to create and name a new project."""
        self._iface.actionNewProject().trigger()
        # save the project to force user to supply a name and location
        self._iface.actionSaveProjectAs().trigger()
        self.initButtons()
        # allow time for project to be created
        time.sleep(2)
        proj = QgsProject.instance()
        if proj.fileName() == '':
            # QSWATUtils.error('No project created', False)
            return
        self._odlg.raise_()
        self.setupProject(proj, False)
        self._gv.writeMasterProgress(0, 0)
        
    def existingProject(self):
        """Open an existing QGIS project."""
        self._iface.actionOpenProject().trigger()
        # allow time for project to be opened
        time.sleep(2)
        proj = QgsProject.instance()
        if proj.fileName() == '':
            QSWATUtils.error('No project opened', False)
            return
        self._odlg.raise_()
        self.setupProject(proj, False)
    
    def setupProject(self, proj, isBatch):
        """Set up the project."""
        self._odlg.mainBox.setVisible(True)
        self._odlg.mainBox.setEnabled(False)
        self._odlg.setCursor(Qt.WaitCursor)
        self._odlg.projPath.setText('Restarting project ...')
        proj.setTitle(QFileInfo(proj.fileName()).baseName())
        # now have project so initiate global vars
        # if we do this earlier we cannot for example find the project database
        self._gv = GlobalVars(isBatch)
        self._gv.plugin_dir = self.plugin_dir
        self._odlg.projPath.repaint()
        self.setLegendGroups()
        if self.demProcessed():
            self._demIsProcessed = True
            self.allowCreateHRU()
            hrus = HRUs(self._iface, self._gv, self._odlg.reportsBox)
            result = hrus.tryRun()
            if result == 1:
                QSWATUtils.progress('Done', self._odlg.hrusLabel)
                self._odlg.editLabel.setEnabled(True)
                self._odlg.editButton.setEnabled(True)
        if os.path.exists(QSWATUtils.join(self._gv.tablesOutDir, Parameters._OUTPUTDB)):
            self._odlg.visualiseLabel.setVisible(True)
            self._odlg.visualiseButton.setVisible(True)
        self._odlg.projPath.setText(self._gv.projDir)
        self._odlg.mainBox.setEnabled(True)
        self._odlg.setCursor(Qt.ArrowCursor)
            
    def runParams(self):
        """Run parameters form."""
        params = Parameters(self._gv)
        params.run()
        
    def showReport(self):
        """Display selected report."""
        if not self._odlg.reportsBox.hasFocus():
            return
        item = self._odlg.reportsBox.currentText()
        if item == Parameters._TOPOITEM:
            report = Parameters._TOPOREPORT
        elif item == Parameters._BASINITEM:
            report = Parameters._BASINREPORT
        elif item == Parameters._HRUSITEM:
            report = Parameters._HRUSREPORT
        else:
            return
        report = QSWATUtils.join(self._gv.textDir, report)
        if os.name == 'nt': # Windows
            os.startfile(report)
        elif os.name == 'posix': # Linux
            subprocess.call(('xdg-open', report))
        self._odlg.reportsBox.setCurrentIndex(0)

    def doDelineation(self):
        """Run the delineation dialog."""
        delin = Delineation(self._iface, self._gv, self._demIsProcessed)
        result = delin.run()
        if result == 1:
            self.allowCreateHRU()
            # remove old data so cannot be reused
            self._gv.db.clearTable('BASINSDATA1')
        elif result == 0:
            self._demIsProcessed = False
            self._odlg.delinLabel.setText('Step 1')
            self._odlg.hrusLabel.setText('Step 2')
            self._odlg.hrusLabel.setEnabled(False)
            self._odlg.hrusButton.setEnabled(False)
            self._odlg.editLabel.setEnabled(False)
            self._odlg.editButton.setEnabled(False)
        self._odlg.raise_()
        
    def doCreateHRUs(self):
        """Run the HRU creation dialog."""
        hrus = HRUs(self._iface, self._gv, self._odlg.reportsBox)
        result = hrus.run()
        if result == 1:
            # TODO: more?
            QSWATUtils.progress('Done', self._odlg.hrusLabel)
            self._odlg.editLabel.setEnabled(True)
            self._odlg.editButton.setEnabled(True)
        self._odlg.raise_()
            
    def demProcessed(self):
        """
        Return true if we can proceed with HRU creation.
        
        Return false if any required project setting is not found 
        in the project file
        Return true if:
        Using existing watershed and watershed grid exists and 
        is newer than dem
        or
        Not using existing watershed and filled dem exists and 
        is no older than dem, and
        watershed shapefile exists and is no older than filled dem
        """
        proj = QgsProject.instance()
        if not proj:
            QSWATUtils.loginfo('demProcessed failed: no project')
            return False
        title = proj.title()
        demFile, found = proj.readEntry(title, 'delin/DEM', '')
        if not found or demFile == '':
            QSWATUtils.loginfo('demProcessed failed: no DEM')
            return False
        li = self._iface.legendInterface()
        demFile = QSWATUtils.join(self._gv.projDir, demFile)
        demLayer, loaded = QSWATUtils.getLayerByFilename(li.layers(), demFile, FileTypes._DEM, self._gv, True)
        if not demLayer:
            QSWATUtils.loginfo('demProcessed failed: no DEM layer')
            return False
        if loaded: 
            li.moveLayer(demLayer, self._gv.watershedGroupIndex)
        self._gv.demFile = demFile
        outletFile, found = proj.readEntry(title, 'delin/outlets', '')
        if found and outletFile:
            outletFile = QSWATUtils.join(self._gv.projDir, outletFile)
            outletLayer, loaded = \
                QSWATUtils.getLayerByFilename(li.layers(), outletFile, FileTypes._OUTLETS, self._gv, True)
            if not outletLayer:
                QSWATUtils.loginfo('demProcessed failed: no outlet layer')
                return False
            if loaded: 
                li.moveLayer(outletLayer, self._gv.watershedGroupIndex)
        else:
            outletLayer = None
        self._gv.outletFile = outletFile
        streamFile, found = proj.readEntry(title, 'delin/net', '')
        if not found or streamFile == '':
            QSWATUtils.loginfo('demProcessed failed: no stream reaches shapefile')
            return False
        streamFile = QSWATUtils.join(self._gv.projDir, streamFile)
        streamLayer, loaded = \
            QSWATUtils.getLayerByFilename(li.layers(), streamFile, FileTypes._STREAMS, self._gv, True)
        if not streamLayer:
            QSWATUtils.loginfo('demProcessed failed: no stream reaches layer')
            return False
        if loaded: 
            li.moveLayer(streamLayer, self._gv.watershedGroupIndex)
        self._gv.streamFile = streamFile
        wshedFile, found = proj.readEntry(title, 'delin/wshed', '')
        if not found or wshedFile == '':
            QSWATUtils.loginfo('demProcessed failed: no subbasins shapefile')
            return False
        wshedFile = QSWATUtils.join(self._gv.projDir, wshedFile)
        wshedInfo = QFileInfo(wshedFile)
        wshedTime = wshedInfo.lastModified()
        wshedLayer, loaded = \
            QSWATUtils.getLayerByFilename(li.layers(), wshedFile, FileTypes._SUBBASINS, self._gv, True)
        if not wshedLayer:
            QSWATUtils.loginfo('demProcessed failed: no subbasins layer')
            return False
        if loaded: 
            li.moveLayer(wshedLayer, self._gv.watershedGroupIndex)
        self._gv.wshedFile = wshedFile
        extraOutletFile, found = proj.readEntry(title, 'delin/extraOutlets', '')
        if found and extraOutletFile != '':
            extraOutletFile = QSWATUtils.join(self._gv.projDir, extraOutletFile)
            extraOutletLayer, loaded = \
                QSWATUtils.getLayerByFilename(li.layers(), extraOutletFile, FileTypes._OUTLETS, self._gv, True)
            if not extraOutletLayer:
                QSWATUtils.loginfo('demProcessed failed: no extra outlet layer')
                return False
            if loaded: 
                li.moveLayer(outletLayer, self._gv.watershedGroupIndex)
        else:
            extraOutletLayer = None
        self._gv.extraOutletFile = extraOutletFile
        demInfo = QFileInfo(demFile)
        if not demInfo.exists():
            QSWATUtils.loginfo('demProcessed failed: no DEM info')
            return False
        base = QSWATUtils.join(demInfo.absolutePath(), demInfo.baseName())
        self._gv.basinFile = base + 'w.tif'
        if not os.path.exists(self._gv.basinFile):
            QSWATUtils.loginfo('demProcessed failed: no basins raster')
            return False
        self._gv.slopeFile = base + 'slp.tif'
        if not os.path.exists(self._gv.slopeFile):
            QSWATUtils.loginfo('demProcessed failed: no slope raster')
            return False
        self._gv.existingWshed = proj.readBoolEntry(title, 'delin/existingWshed', False)[0]
        if self._gv.existingWshed:
            winfo = QFileInfo(self._gv.basinFile)
            # cannot use last modified times because subbasin field in wshed file changed after wfile is created
            wCreateTime = winfo.created()
            wshedCreateTime = wshedInfo.created()
            if not wshedCreateTime <= wCreateTime:
                QSWATUtils.loginfo('demProcessed failed: wFile not up to date for existing watershed')
                return False
        else:
            self._gv.pFile = base + 'p.tif'
            if not os.path.exists(self._gv.pFile):
                QSWATUtils.loginfo('demProcessed failed: no p raster')
                return False
            felInfo = QFileInfo(base + 'fel.tif')
            if not (felInfo.exists() and wshedInfo.exists()):
                QSWATUtils.loginfo('demProcessed failed: no filled raster')
                return False
            demTime = demInfo.lastModified()
            felTime = felInfo.lastModified()
            if not (demTime <= felTime <= wshedTime):
                QSWATUtils.loginfo('demProcessed failed: not up to date')
                return False
            self._gv.distFile = base + 'dist.tif'
            if not os.path.exists(self._gv.distFile):
                QSWATUtils.loginfo('demProcessed failed: no distance to outlet raster')
        basinIndex = self._gv.topo.getIndex(wshedLayer, QSWATTopology._POLYGONID)
        for feature in wshedLayer.getFeatures():
            basin = feature.attributes()[basinIndex]
            centroid = feature.geometry().centroid().asPoint()
            centroidlatlong = self._gv.topo.pointToLatLong(centroid, wshedLayer.crs())
            self._gv.topo.basinCentroids[basin] = (centroidlatlong.x(), centroidlatlong.y())
        if not self._gv.topo.setUp0(demLayer, streamLayer, self._gv.verticalFactor):
            return False
        # this can go wrong if eg the streams and watershed files exist but are inconsistent
        try:
            if not self._gv.topo.setUp(demLayer, streamLayer, wshedLayer, outletLayer, extraOutletLayer, self._gv.db, self._gv.existingWshed, False, False):
                QSWATUtils.loginfo('demProcessed failed: topo setup failed')
                return False
            if not self._gv.topo.inletLinks:
                # no inlets, so no need to expand subbasins layer legend
                li.setLayerExpanded(wshedLayer, False)
        except Exception:
            QSWATUtils.loginfo('demProcessed failed: topo setup raised exception')
            return False
        return True
            
    def allowCreateHRU(self):
        """Mark delineation as Done and make create HRUs option visible."""
        QSWATUtils.progress('Done', self._odlg.delinLabel)
        QSWATUtils.progress('Step 2', self._odlg.hrusLabel)
        self._odlg.hrusLabel.setEnabled(True)
        self._odlg.hrusButton.setEnabled(True)
        self._odlg.editLabel.setEnabled(False)
        self._odlg.editButton.setEnabled(False)
            
    def setLegendGroups(self):
        """Legend groups are used to keep legend in reasonable order.  
        Create them if necessary.
        """
        li = self._iface.legendInterface()
        groups = li.groups()
        try:
            self._gv.resultsGroupIndex = groups.index(QSwat._RESULTS_GROUP_NAME)
        except Exception:
            self._gv.resultsGroupIndex = li.addGroup(QSwat._RESULTS_GROUP_NAME)
        try:
            self._gv.watershedGroupIndex = groups.index(QSwat._WATERSHED_GROUP_NAME)
        except Exception:
            self._gv.watershedGroupIndex = li.addGroup(QSwat._WATERSHED_GROUP_NAME)
        try:
            self._gv.landuseGroupIndex = groups.index(QSwat._LANDUSE_GROUP_NAME)
        except Exception:
            self._gv.landuseGroupIndex = li.addGroup(QSwat._LANDUSE_GROUP_NAME)
        try:
            self._gv.soilGroupIndex = groups.index(QSwat._SOIL_GROUP_NAME)
        except Exception:
            self._gv.soilGroupIndex = li.addGroup(QSwat._SOIL_GROUP_NAME)
        try:
            self._gv.slopeGroupIndex = groups.index(QSwat._SLOPE_GROUP_NAME)
        except Exception:
            self._gv.slopeGroupIndex = li.addGroup(QSwat._SLOPE_GROUP_NAME)

    def startEditor(self):
        """Start the SWAT Editor, first setting its initial parameters."""
        self._gv.setSWATEditorParams()
        subprocess.call(self._gv.SWATEditorPath)
        if os.path.exists(QSWATUtils.join(self._gv.tablesOutDir, Parameters._OUTPUTDB)):
            self._odlg.visualiseLabel.setVisible(True)
            self._odlg.visualiseButton.setVisible(True)
        
    def visualise(self):
        """Run visualise form."""
        vis = Visualise(self._iface, self._gv)
        # vis = VisualOutput(self._iface, self._gv)
        vis.run()
                    
            
