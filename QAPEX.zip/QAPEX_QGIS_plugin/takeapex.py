# -*- coding: utf-8 -*-
import os
global path  # => path => python start folder, paste
import csv, pyodbc, math, time, shutil

#Temp
#path = "d:/Jayoung/QAPEX/coding/create_files_2018_0314"
#File = "d:/Jayoung/QAPEX/coding/KOREA.mdb"

class HyperClass(object):
    pass

class SuperClass(HyperClass):
    def __init__(self):
        return
    
    def APEXFILE(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        f = open(path+"/APEXFILE.DAT", "w")
        for line in Read:
            f.write("{:>6}{:>16}\n".format(line[1], line[2]))
        f.close()

    def Read_MDB(self, File, Table):   #File: path, Table is table of mdb 
        # set up some constants
        MDB = File; DRV = '{Microsoft Access Driver (*.mdb)}'; PWD = 'pw'
        # connect to db
        con = pyodbc.connect('DRIVER={};DBQ={};PWD={}'.format(DRV,MDB,PWD))
        cur = con.cursor()

        # run a query and get the results 
        SQL = 'SELECT * FROM '+Table+';' # your query goes here
        rows = cur.execute(SQL).fetchall()
        cur.close()
        con.close()
        return rows

    def Read_column(self, File, Table):
        MDB = File; DRV = '{Microsoft Access Driver (*.mdb)}'; PWD = 'pw'
        con = pyodbc.connect('DRIVER={};DBQ={};PWD={}'.format(DRV,MDB,PWD))
        cur = con.cursor()

        Field = []
        for field in cur.columns(table=Table):
            Field.append(field.column_name)
        return Field

#==============================
   
    def APEXDIM(self, path, MPS, MRO, MNT, MNC, MHD, MBS, MFT, MPO, MHP, MHX):
        f = open(path+"/APEXDIM.DAT", "w")
        f.write("{:>8}{:>8}{:>8}{:>8}{:>8}{:>8}{:>8}{:>8}{:>8}{:>8}{:>8}\n".format(int(MPS),int(MRO),int(MNT),int(MNC),int(MHD),int(MBS),int(MFT),int(MPO),int(MHP),int(MHX),"15"))
        f.close()


                
#==============================
        
    def CROP(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FCROP":
                f = open(path+"/"+line[2], "w")
                
        #line 1, 2
        f.write("   Crop        1       2       3       4       5       6       7       8       9      10      11      12      13      14      15      16      17      18      19      20      21      22      23      24      25      26      27      28      29      30      31      32      33      34      35      36      37      38      39      40      41      42      43      44      45      46      47      48      49      50      51      52      53      54      55      56\n")
        f.write("   #  NAME     WA      HI     TOP     TBS    DMLA    DLAI   DLAP1   DLAP2    RLAD    RBMD     ALT     GSI     CAF     SDW     HMX    RDMX    WAC2     CNY     CPY     CKY    WSYF     PST    COSD    PRYG    PRYF     WCY     BN1     BN2     BN3     BP1     BP2     BP3     BK1     BK2     BK3     BW1     BW2     BW3     IDC   FRST1   FRST2    WAVP    VPTH    VPD2   RWPC1   RWPC2    GMHU   PPLP1   PPLP2    STX1    STX2    BLG1    BLG2     WUB     FTO     FLT\n")
        

        #line 3 
        Read = self.Read_MDB(File, "crop")
        for line in Read:
            f.write("{:>5}{:>5}{:>8.3f}{:>8.2f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.4f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}    {}\n".format(line[0],line[1],float(line[2]),float(line[3]),float(line[4]),float(line[5]),float(line[6]),float(line[7]),float(line[8]),float(line[9]),float(line[10]),float(line[11]),float(line[12]),float(line[13]),float(line[14]),float(line[15]),float(line[16]),float(line[17]),float(line[18]),float(line[19]),float(line[20]),float(line[21]),float(line[22]),float(line[23]),float(line[24]),float(line[25]),float(line[26]),float(line[27]),float(line[28]),float(line[29]),float(line[30]),float(line[31]),float(line[32]),float(line[33]),float(line[34]),float(line[35]),float(line[36]),float(line[37]),float(line[38]),float(line[39]),float(line[40]),float(line[41]),float(line[42]),float(line[43]),float(line[44]),float(line[45]),float(line[46]),float(line[47]),float(line[48]),float(line[49]),float(line[50]),float(line[51]),float(line[52]),float(line[53]),float(line[54]),float(line[55]),float(line[56]),float(line[57]),line[66])) 
        f.close()

    def FERT(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FFERT":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "fertmarn2 ORDER BY fert_num ASC")  #ASC
        for line in Read:
            f.write("{:>5} {:<8}".format(line[0],line[9][:8]))
            for n in range(10,19):
                f.write("{:>8.4f}".format(float(line[n])))
            f.write("\n")
        f.close()

    def MLRN(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FMLRN":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "MLRN")
        for line in Read:
            n=0
            for x in line:
                if n >= 1:
                    f.write("{:>4}".format(int(x)))
                n += 1
            f.write("\n")
        f.close()
        
    def OPSC(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FOPSC":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "ROTATIONS")
        for line in Read:
            year = 0
            for nn in range(13, 21):
                year += int(line[nn])
            year = str(year*11)
            f.write("{:>5}{:>6}.OPS{:>6}Y {}_{}_{}\n".format(line[0],line[0],year,line[2],line[3],line[4]))
        f.close()

    def PEST(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FPEST":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "pest ORDER BY ID ASC")
        for line in Read:
            f.write("{:>5} {:<16}{:>16}{:>16}{:>16}{:>16}{:>16}{:>16}\n".format(line[0],line[5][:15],line[12],line[13],line[14],line[15],line[16],line[11]))
        f.close()

    def RFDTLST(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FRFDT":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "RFDTLST")
        for line in Read:
            f.write("{:>5} {}".format(line[0],line[1]))
        f.close()
#=====
#===== hold ======= >> APEXRUN 
    def SITE(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSITE":
                f = open(path+"/"+line[2], "w")

        f.write("    1 WINAPEX.SIT\n")
        f.close()
        pass

    def SUBA(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                f = open(path+"/"+line[2], "w") 

        f.write("    1 WINAPEX.SUB\n")
        f.close()
#===== hold
#+====

    def SOIL(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSOIL":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "SOILS_LIST")
        for line in Read:
            f.write("{:>8}{:>10}.SOL  {}\n".format(line[0],line[0],line[5]))
        f.close()

    def TILL(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FTILL":
                f = open(path+"/"+line[2], "w")

        #line1, 2
        f.write("  |-----TILL------|       1       2       3       4       5       6       7       8       9      10      11      12      13      14      15      16      17      18      19      20      21      22      23      24      25      26      27      28      29\n")
        f.write("    #  NAME     PCD    PRIC    PLST     HRY     HRL     PWR     WDT     SPD     RC1     RC2     XLB     FCM     VR1     VR2     EFM     RTI     EMX      RR     TLD     RHT     RIN     DKH     DKI     IHC      HE    ORHI    FRCP    FPOP    CFEM    STIR      EQP\n")

        #line3
        Read = self.Read_MDB(File, "tillmarn ORDER BY recnum ASC")
        for line in Read:
            f.write("{:>5} {:<8} {:<4}{:>8}{:>8}{:>8}{:>8}{:>8}{:>8.1f}{:>8.2f}{:>8.3f}{:>8.4f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.4f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}{:>8.3f}  {}\n".format(line[1],line[3][:8],line[5][:4],int(line[6]),int(line[7]),int(line[8]),int(line[9]),int(line[10]),float(line[11]),float(line[12]),float(line[13]),float(line[14]),float(line[15]),float(line[16]),float(line[17]),float(line[18]),float(line[19]),float(line[20]),float(line[21]),float(line[22]),float(line[23]),float(line[24]),float(line[25]),float(line[26]),float(line[27]),float(line[28]),float(line[29]),float(line[30]),float(line[31]),float(line[32]),float(line[34]),float(line[35]),line[2]))
        f.close()

    def TR55(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FTR55":
                f = open(path+"/"+line[2], "w")
                
        Read = self.Read_MDB(File, "TR55")
        for line in Read:
            f.write("{:>10f}{:>10f}{:>10f}{:>10f}{:>10f}{:>10f}{:>10f}{:>10f}\n".format(float(line[1]),float(line[2]),float(line[3]),float(line[4]),float(line[5]),float(line[6]),float(line[7]),float(line[8])))
        f.write("   .045   .333     .1732    .5\n")
        f.close()
##
    def WDLST(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FPMV":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "WEATHER_LIST")
        for line in Read:
            f.write("{:>5}{:>7}.DLY{:>10.2f}{:>8.2f}{:>8.1f}    {}\n".format(line[0],line[7],float(line[8]),float(line[9]),float(line[10]),line[3]))
        f.close()
        
        
    def WIND(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FWIND":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "[WIND LIST]")   #space  [] 
        for line in Read:
            f.write("{:>8}{:>10}.WND{:>8.2f}{:>8.2f}   {}\n".format(line[0],line[0],float(line[6]),float(line[7]),line[2]))
        f.close()

    def WPM(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FWPM":
                f = open(path+"/"+line[2], "w")

        Read = self.Read_MDB(File, "WEATHER_LIST")
        for line in Read:
            f.write("{:>8}{:>10}.WP1{:>8.2f}{:>8.2f}{:>8.1f}   {}\n".format(line[0],line[0],float(line[8]),float(line[9]),float(line[10]),line[3]))
        f.close()

    def PSOCOM(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FPSOD":
                f = open(path+"/"+line[2], "w")
        f.close()

#default 값 
    def PRNT(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FPRNT":
                f = open(path+"/"+line[2], "w")

        f.write("""   1   2   3   4   5   6  10  11  12  13  14  15  16  18  24  25  26  27  29  30
  37  41  42  43  44  45  46  48  50  52  53  54  55  56  57  59  60  64  65  66
  67  71  72  73  74  75  76  77  78  81  83  84  85  86  88  93  94  96  98  99
 102 103 104 105 106 107 108 110 125 126 127 128 134                            
                                                                                
  38  39  40  49                                                                
   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17            
  13 117  29  37  48  38  49  88 108  76  77  72  15  83  17                    
                                                                                
   4   5   6  18  10  11 120  16  71  13  15  72 117  14   1   2  59   3  27  31
  53  54  55  56  57  43  42  37 119  38  49 118  39  80                        
   1       1   1                       1                               1        
               1                           1               1                    
                                                                                


""")
        f.close()

#default 값
    def APEXRUN(self, path, File, Weather_lookup):
        Read = self.Read_MDB(File, "WEATHER_LIST")
        for Read_Data in Read:
            if Read_Data[3] == Weather_lookup:
                Weather_stn = str(int(Read_Data[0]))
                Wind_lookup = Read_Data[14]
                Read_Wind = self.Read_MDB(File, "[WIND LIST]")
                for Read_Wind_Data in Read_Wind:
                    if Read_Wind_Data[1] == Wind_lookup:
                        Wind_stn = str(int(Read_Wind_Data[0]))
                
        f = open(path+"/APEXRUN.DAT", "w")  
        f.write(" Winapex    1        "+Weather_stn+"        "+Wind_stn+"    1    0    0\nXXXXXXXX    0    0    0    0    0    0\n")
        f.close()

    def APEXCONT(self, path, File, Control_Name=False):
        f = open(path+"/APEXCONT.DAT", "w")
        if Control_Name != False:
            Read = self.Read_MDB(File, "[Control Table APEX] where [Control Name] = '"+Control_Name+"'")[0]
        else:
            Read = self.Read_MDB(File, "[Control Table APEX]")[0]
        f.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(Read[2],Read[3],Read[4],Read[5],Read[6],Read[7],Read[8],Read[9],Read[10],Read[11],Read[12],Read[13],Read[14],Read[15],Read[16],Read[17],Read[18],Read[19],Read[20],Read[21]))
        f.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(Read[22],Read[23],Read[24],Read[25],Read[26],Read[27],Read[28],Read[29],Read[30],Read[31],Read[32],Read[33],Read[34],Read[35],Read[36],0,0,0,Read[37])) #IHRF, IWTB, NSTP
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(Read[38],Read[39],Read[40],Read[41],Read[42],Read[43],Read[44],Read[45],Read[46],Read[47]))
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(Read[48],Read[49],Read[50],Read[51],Read[52],Read[53],Read[54],Read[55],Read[56],Read[57]))
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(Read[58],Read[59],Read[60],Read[61],Read[62],Read[63],Read[64],Read[65],Read[66],Read[67]))
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n\n".format(Read[68],Read[69],Read[70],Read[71],Read[73],Read[74],Read[75],Read[76]))
        f.close()

    def APEXCONT_Users(self, path, path2, File):

        g = open(path2+"/Source/APEXCONT_parm.txt", "r")
        lines = g.readlines()
        g.close()
        f = open(path+"/APEXCONT.DAT", "w")
        p1 = lines[0].split(",")
        p2 = lines[1].split(",")
        p3 = lines[2].split(",")
        p4 = lines[3].split(",")
        p5 = lines[4].split(",")
        p6 = lines[5].split(",")
        
        f.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(p1[0]),int(p1[1]),int(p1[2]),int(p1[3]),int(p1[4]),int(p1[5]),int(p1[6]),int(p1[7]),int(p1[8]),int(p1[9]),int(p1[10]),int(p1[11]),int(p1[12]),int(p1[13]),int(p1[14]),int(p1[15]),int(p1[16]),int(p1[17]),int(p1[18]),int(p1[19])))
        f.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(p2[0]),int(p2[1]),int(p2[2]),int(p2[3]),int(p2[4]),int(p2[5]),int(p2[6]),int(p2[7]),int(p2[8]),int(p2[9]),int(p2[10]),int(p2[11]),int(p2[12]),int(p2[13]),int(p2[14]),int(p2[15]),int(p2[16]),int(p2[17]),int(p2[18]))) #IHRF, IWTB, NSTP
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(float(p3[0]),float(p3[1]),float(p3[2]),float(p3[3]),float(p3[4]),float(p3[5]),float(p3[6]),float(p3[7]),float(p3[8]),float(p3[9])))
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(float(p4[0]),float(p4[1]),float(p4[2]),float(p4[3]),float(p4[4]),float(p4[5]),float(p4[6]),float(p4[7]),float(p4[8]),float(p4[9])))
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(float(p5[0]),float(p5[1]),float(p5[2]),float(p5[3]),float(p5[4]),float(p5[5]),float(p5[6]),float(p5[7]),float(p5[8]),float(p5[9])))
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n\n".format(float(p6[0]),float(p6[1]),float(p6[2]),float(p6[3]),float(p6[4]),float(p6[5]),float(p6[6]),float(p6[7])))
        f.close()

#default
    def PARMS(self, path):
        f = open(path+"/PARMS.DAT", "w")
        f.write("""   90.05   99.95
   10.50  100.95
   50.10   95.95
     .00     .00
   25.05   75.90
    5.10  100.95
    5.25   50.95
   20.50   80.99
    1.10   10.99
   10.05  100.90
    5.01   20.90
    5.05  100.50
    1.80    3.99
    5.10   20.95
   10.10  100.95
    3.10   20.99
   20.10   50.95
    5.10   50.30
   10.01   25.95
  400.05  600.90
   10.50  100.90
  100.01 1000.90
    1.50    3.99
    3.25   15.95
   25.01   60.95
     .00     .00
     .00     .00
     .00     .00
     .00     .00
   50.00   10.00
   2.000   1.200    .500    .450    .500    .500    .900  15.000    20.0   20.00
  -100.0  1.5000   2.000    .200    .000   1.000    .100   1.500  0.0500  0.2000
    10.0  0.0500  0.0032     .10     .00     .05     .30    2.00  0.1000  1.3000
  0.3000  1.0000  2.5000  0.6000  0.9900  1.2000     0.2 1.00000  .00000    .001
     .50    1.00     .15    1.50    3.00     .70 1.00000  .00000    .000    .100
     0.0    15.0     .90    .780  .24680     .90     .78  .24680     1.0     7.0
     .80     .25    1.10    1.000.001000  3.0000     10.     0.5     .50     .60
   1.150    .100    .500    .200    .800    .010    .0001000.000   1.000    .100
     0.0     0.0 4.00000  .00010  .00010     0.0     0.0     0.0     0.0      1.
     .10     .80    2.24    2.24      1.     1.0       0       0       0       0
     .29    7.35\n""")
        f.close()


#===========================================APEXRUN.DAT================================================


    """
    OPS는 미리 만들어 두기.. (LUNS 실패)

    def ops(self):   # 한개 ops로만 
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(path+"/"+line[2], "r") # 파일리스트에서 읽어 목록대로 읽기.
                g_lines = g.readlines()

        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x]
            
            f = open(path+"/"+g_line[1], "r")  # f = WINAPEX.SUB
            f_lines = f.readlines()
            length = len(f_lines)
            for n in range(0, length):
                if n%12 == 1:
                    IOPS = int(f_lines[n][8:15])
                    Read_LIST = self.Read_MDB(File, "ROTATIONS")
                    for OPS_LIST in Read_LIST:
                        if IOPS == OPS_LIST[0]:
                            h = open(path+"/"+str(IOPS)+".ops", "w")
                            h.write(" "+OPS_LIST[2]+"\n")
                            #h.write("{:>4f}".format
                            
                            XP = 0  #CODE 개수
                            for N in range(13, 21):
                                if OPS_LIST[N] == 1:
                                    XP += 1
                            #print XP
                            #print IOPS

                                    #h.write(IOPS, CROP 해서 가져오기)
                            Management = []
                            if XP == 1:
                                Read_BUDGET = self.Read_MDB(File, "BUDGET_DATA where Lookup = '"+OPS_LIST[5]+"' ORDER BY month, day ASC")
                                Management.append(Read_BUDGET)
                                #print Management
                            elif XP != 1:
                                for N in range(0, XP):
                                    if not N+1 == XP:
                                        Read_BUDGET_N0 = self.Read_MDB(File, "BUDGET_DATA where Lookup = '"+OPS_LIST[5+N]+"' and year = 93 ORDER BY month, day ASC")
                                        Read_BUDGET_N1 = self.Read_MDB(File, "BUDGET_DATA where Lookup = '"+OPS_LIST[5+N+1]+"' and year = 92 ORDER BY month, day ASC")
                                    else:
                                        Read_BUDGET_N0 = self.Read_MDB(File, "BUDGET_DATA where Lookup = '"+OPS_LIST[5+N]+"' and year = 93 ORDER BY month, day ASC")
                                        Read_BUDGET_N1 = self.Read_MDB(File, "BUDGET_DATA where Lookup = '"+OPS_LIST[5]+"' and year = 92 ORDER BY month, day ASC")
                                        
                                    for N0 in Read_BUDGET_N0:
                                        list_N0 = list(N0)
                                        list_N0.insert(0, int("{:02d}{:02d}".format(N0[3],N0[4])))
                                        print "{:02d}{:02d}".format(N0[3],N0[4])
                                        Management.append(list_N0)
                                    for N1 in Read_BUDGET_N1:
                                        list_N1 = list(N1) 
                                        list_N1.insert(0, int("{:02d}{:02d}".format(N1[3],N1[4])))
                                        Management.append(list_N1)
                                Management.sort()
                                for X6 in Management:
                                    X6[15]
                                    Read_crop2curve = self.Read_MDB(File, "crop2curve where crop_num = "+str(X6[15]))
                                    Read_Curve = self.Read_MDB(File, "Curve where crop_num = "+str(X6[15]))
                               # print Management[0]
    """

    def SIT_ori(self, path, File, WSName=False):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSITE":
                g = open(path+"/"+line[2], "r")
                g_lines = g.readlines()
                
        if WSName != False:
            Read = self.Read_MDB(File, "Watershedtbl where WSName = '"+WSName+"'")[0]
        else:
            Read = self.Read_MDB(File, "Watershedtbl")[0]
            
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x]
            f = open(path+"/"+g_line[1], "w")
            f.write(g_line[1]+"\n")
            f.write(str(Read[0]) + " "+Read[1]+" Weathersheld\n")
            now = time.localtime()
            s = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
            f.write(s+"\n")
            f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(Read[3],Read[4],Read[5],Read[6],Read[9],Read[10],Read[11],Read[12],Read[13],0))  #FIR
            f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n\n\n\n\n\n\n".format(0,0,0,0,0,0,0,0,Read[7],Read[8]))
            f.close()

    def SIT(self, path, File, User_PARAM, PARAM):
        if not User_PARAM == '':
            PARAM = User_PARAM
            
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSITE":
                g = open(path+"/"+line[2], "r")
                g_lines = g.readlines()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x]
            
        f = open(path+"/"+g_line[1], "w")
        f.write(g_line[1]+"\n")
        f.write(PARAM[2] + " Weathersheld\n")
        now = time.localtime()
        s = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
        f.write(s+"\n")
        
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(float(PARAM[0][0]),float(PARAM[0][1]),float(PARAM[0][2]),float(PARAM[0][3]),float(PARAM[0][4]),float(PARAM[0][5]),float(PARAM[0][6]),float(PARAM[0][7]),float(PARAM[0][8]),float(PARAM[0][9])))
        f.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n\n\n\n\n\n\n".format(float(PARAM[1][0]),float(PARAM[1][1]),float(PARAM[1][2]),float(PARAM[1][3]),float(PARAM[1][4]),float(PARAM[1][5]),float(PARAM[1][6]),float(PARAM[1][7]),float(PARAM[1][8]),float(PARAM[1][9])))
        f.close()
  

    def wp1(self, path, File): 
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FWPM":
                g = open(path+"/"+line[2], "r")
                g_lines = g.readlines()
        
        f = open(path+"/APEXRUN.DAT", "r")
        f_lines = f.readlines()
        for f_line in f_lines:
            f_line_strip = f_line.strip().split(" ")
            f_line = [x for x in f_line_strip if x]
            if not f_line[0] == "XXXXXXXX":
                Weather_num = f_line[2]
                for g_line in g_lines:
                    g_line_strip = g_line.strip().split(" ")
                    g_line = [x for x in g_line_strip if x]
                    if g_line[0] == f_line[2]:  ###
                        Weather_Num = g_line[1] # WIND *.wnd 

                        h = open(path+"/"+Weather_Num, "w")
                        Read_LIST = self.Read_MDB(File, "WEATHER_LIST")
                        for Read_LIST_Data in Read_LIST:
                            if str(Read_LIST_Data[0]) ==  Weather_num:
                                h.write(" "+Read_LIST_Data[3]+"\n")
                                now = time.localtime()
                                s = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
                                h.write("  "+s+"\n")

                                Read_DATA = self.Read_MDB(File, "WEATHER_DATA WHERE Lookup = '"+Read_LIST_Data[3]+"'")
                                for Field_NAME in ["TMX", "TMN", "SDMX", "SDMN", "PRCP", "SDRF", "SKRF", "PW|D", "PW|W", "DAYP", "WI", "RAD", "RHUM"]:
                                    P = 0
                                    for LOOKUP in Read_DATA:
                                        if Field_NAME == LOOKUP[1]:
                                            for n in range(2, 14):
                                                h.write("{:>6.2f}".format(LOOKUP[n]))
                                                P += 1
                                            h.write("\n")
                                    if P == 0:
                                        for n in range(2, 14):
                                            h.write("{:>6.2f}".format(0))
                                        h.write("\n")
                                h.write("\n")
                                h.close()

                
    def wnd(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FWIND":
                g = open(path+"/"+line[2], "r")
                g_lines = g.readlines()
        
        f = open(path+"/APEXRUN.DAT", "r")
        f_lines = f.readlines()
        for f_line in f_lines:
            f_line_strip = f_line.strip().split(" ")
            f_line = [x for x in f_line_strip if x]
            if not f_line[0] == "XXXXXXXX":
                WIND_num = f_line[3]
                for g_line in g_lines:
                    g_line_strip = g_line.strip().split(" ")
                    g_line = [x for x in g_line_strip if x]
                    if g_line[0] == f_line[3]:  
                        WIND_Num = g_line[1]
                        #print WIND_Num

                        h = open(path+"/"+WIND_Num, "w")
                        Read_LIST = self.Read_MDB(File, "[WIND LIST]")
                        for Read_LIST_Data in Read_LIST:
                            if str(Read_LIST_Data[0]) ==  WIND_num:
                                h.write(" "+Read_LIST_Data[1]+"\n")
                                now = time.localtime()
                                s = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
                                h.write("  "+s+"\n")

                                Read_DATA = self.Read_MDB(File, "[WIND DATA] WHERE Lookup = '"+Read_LIST_Data[1]+"' ORDER BY Month ASC")

                                for n in range(0, 17):
                                    for month in range(0, 12):
                                        h.write("{:>6.2f}".format(float(Read_DATA[month][n+3])))
                                    h.write("\n")
                                h.close()

    def sol(self, path, File):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(path+"/"+line[2], "r")
                g_lines = g.readlines()
        
        f = open(path+"/APEXRUN.DAT", "r")
        f_lines = f.readlines()
        for f_line in f_lines:
            f_line_strip = f_line.strip().split(" ")
            f_line = [x for x in f_line_strip if x]
            if not f_line[0] == "XXXXXXXX":
                SUBA_Num = f_line[4]   # APEXRUN: SUBA 

                for g_line in g_lines:
                    g_line_strip = g_line.strip().split(" ")
                    g_line = [x for x in g_line_strip if x]
                    if g_line[0] == f_line[4]:
                        sub_name = g_line[1] # SUBA: Filename.sub

                        h = open(path+"/"+sub_name, "r")
                        h_lines = h.readlines()
                        length = len(h_lines)
                        for n in range(0, length):
                            if n%12 == 1:
                                try:
                                    INPS = int(h_lines[n][0:8])
                                    Read_LIST = self.Read_MDB(File, "SOILS_LIST")
                                    for MDB_line in Read_LIST:
                                        if INPS == MDB_line[0]:
                                            Lookup = MDB_line[5] # Filename.sub: lookup(Soil)

                                            if not os.path.isfile(path+"/"+str(MDB_line[0])+".sol"):
                                                Read_Data = self.Read_MDB(File, "SOILS_DATA ORDER BY Layer_Number ASC") 
                                                j = open(path+"/"+str(MDB_line[0])+".sol", "w")
                                                j.write(" {:<}\n".format(Lookup))
                                                #j.write(" {:<} ({:<})  ({:<})\n".format(Lookup,MDB_line[4],MDB_line[9]))
                                                dic = {"A":1, "B":2, "C":3, "D":4}
                                                #변수

                                                
                                                General_Data = self.Read_MDB(File, "[General Data]")

                                                Variable = {"SALB":float(MDB_line[13]), "HSG":dic[str(MDB_line[10])], "FFC":float(General_Data[0][67]), "WTMN":float(General_Data[0][68]), "WTMX":float(General_Data[0][69]), "WTBL":float(General_Data[0][70]), "GWST":float(General_Data[0][125]), "GWMX":float(General_Data[0][126]), "RFTT":float(General_Data[0][130]), "RFPK":float(General_Data[0][131]), "TSLA":float(General_Data[0][63]), "XIDS":float(General_Data[0][71]), "RTN1":float(General_Data[0][35]), "XIDK":float(General_Data[0][137]), "ZQT":float(General_Data[0][64]), "ZF":float(General_Data[0][66]), "ZTK":float(General_Data[0][65])}#, "FBM":float(General_Data[0][]), "FHP":float(General_Data[0][]), "XCC":float(General_Data[0][])
                                                j.write("{:>8.2f}{:>8}{:>8.2f}{:>8.4f}{:>8.4f}{:>8.4f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(Variable["SALB"],Variable["HSG"],Variable["FFC"],Variable["WTMN"],Variable["WTMX"],Variable["WTBL"],Variable["GWST"],Variable["GWMX"],Variable["RFTT"],Variable["RFPK"]))
                                                j.write("{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}{:>8.2f}\n".format(Variable["TSLA"],Variable["XIDS"],Variable["RTN1"],Variable["XIDK"],Variable["ZQT"],Variable["ZF"],Variable["ZTK"])) #,FBM,FHP,XCC))

                                                Data = []
                                                for Data_line in Read_Data:
                                                    if Lookup == Data_line[3]:
                                                        Data.append(Data_line)
                                                #print len(Data)
                                                for Layer in range(0, len(Data)):
                                                    j.write("{:>8.2f}".format(float(Data[Layer][9])))
                                                j.write("\n")
                                                for row in range(10,22): 
                                                    for Layer in range(0, len(Data)):
                                                        j.write("{:>8.4f}".format(float(Data[Layer][row])))
                                                    j.write("\n")

                                                #CNDS  (Nitrate)
                                                for Layer in range(0, len(Data)):
                                                    if float(Data[Layer][23]) == 0:
                                                        if float(Data[Layer][8]) == 1:
                                                            j.write("{:>8.4f}".format(10))
                                                        else:
                                                            j.write("{:>8.4f}".format(10/math.e))
                                                    else:
                                                        j.write("{:>8.4f}".format(float(Data[Layer][23])))
                                                j.write("\n")
                                                #SSF  (Phosphorus)
                                                for Layer in range(0, len(Data)):
                                                    if float(Data[Layer][24]) == 0:
                                                        if float(Data[Layer][8]) == 1:
                                                            j.write("{:>8.4f}".format(20))
                                                        else:
                                                            j.write("{:>8.4f}".format(20/math.e))
                                                    else:
                                                        j.write("{:>8.4f}".format(float(Data[Layer][24])))
                                                j.write("\n")
                                                #RSD   (Crop Residue)
                                                for Layer in range(0, len(Data)):
                                                    if float(Data[Layer][25]) == 0:
                                                        residue = 10   #Constant for residue
                                                        if float(Data[Layer][8]) == 1:  
                                                            RSD = 1
                                                            j.write("{:>8.4f}".format(RSD))
                                                        else:
                                                            ZX  = float(Data[Layer][9])  -float(Data[Layer-1][9])
                                                            if float(Data[Layer][8]) == 2:
                                                                Zxx = float(Data[Layer-1][9])
                                                            else:
                                                                Zxx = float(Data[Layer-1][9])-float(Data[Layer-2][9])
                                                            RSD = (RSD*ZX*pow(math.e,(-1)*residue*ZX))/Zxx
                                                            j.write("{:>8.4f}".format(RSD))
                                                    else:
                                                        j.write("{:>8.4f}".format(float(Data[Layer][24])))
                                                j.write("\n")
                                                #BDD, PSP
                                                for row in range(25,27):
                                                    for Layer in range(0, len(Data)):
                                                        j.write("{:>8.4f}".format(float(Data[Layer][row])))
                                                    j.write("\n")
                                                    
                                                #SC(SATC)
                                                for Layer in range(0, len(Data)):
                                                    j.write("{:>8.4f}".format(General_Data[0][141]))
                                                j.write("\n")
                                                
                                                """
                                                SC(SOILS_DATA)
                                                for Layer in range(0, len(Data)):
                                                    j.write("{:>8.4f}".format(float(Data[Layer][27])))
                                                j.write("\n")
                                                """
                                                
                                                #HCL
                                                for Layer in range(0, len(Data)):
                                                    j.write("{:>8.4f}".format(General_Data[0][149]))
                                                j.write("\n")
                                                #WP(WPO)
                                                for Layer in range(0, len(Data)):
                                                    j.write("{:>8.4f}".format(General_Data[0][138]))
                                                j.write("\n")
                                                #K(EXCK)
                                                for Layer in range(0, len(Data)):
                                                    j.write("{:>8.4f}".format(General_Data[0][140]))
                                                j.write("\n")

                                                #ECND(SALT)
                                                for Layer in range(0, len(Data)):
                                                    j.write("{:>8.4f}".format(General_Data[0][111+Layer]))
                                                j.write("\n")

                                                """
                                                ECND(SOILS_DATA)
                                                for Layer in range(0, len(Data)):
                                                    j.write("{:>8.4f}".format(float(Data[Layer][31])))
                                                j.write("\n")
                                                """   

                                                #STFR, ST, CPRV, CPRH
                                                for row in range(32,36): 
                                                    for Layer in range(0, len(Data)):
                                                        j.write("{:>8.4f}".format(float(Data[Layer][row])))
                                                    j.write("\n")
                                                j.write("\n"*20)
                                                j.close()
                                                f.close()
                                                g.close()
                                except:
                                    pass
                                
    def sub_mdb(self, path, File, Watershed_Title=False):
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(path+"/"+line[2], "r")
                g_lines = g.readlines()
                
        if Watershed_Title != False:
            Read = self.Read_MDB(File, "SubareaTbl where [Watershed Title] = '"+Watershed_Title+"'")
        else:
            Read = self.Read_MDB(File, "SubareaTbl")
            
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x]
            f = open(path+"/"+g_line[1], "w")

            for Subarea in Read:
                
                now = time.localtime()
                s = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)

                f.write("{:>8d}{:>8d}{:>8d} {}  {} ! {}\n".format(int(Subarea[1]),int(Subarea[2]),int(Subarea[3]),s,Subarea[0],Subarea[4]))
                f.write("{:>8d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}\n".format(int(Subarea[5]),int(Subarea[6]),int(Subarea[8]),int(Subarea[9]),int(Subarea[10]),0,int(Subarea[11]),int(Subarea[12]),int(Subarea[13]),int(Subarea[115]),int(Subarea[109]),int(Subarea[114])))
                f.write("{:>12.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(Subarea[14],Subarea[15],Subarea[17],Subarea[16],Subarea[18],Subarea[121],Subarea[122],Subarea[123]))
                f.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.4f}{:>13.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(Subarea[19],Subarea[20],Subarea[21],Subarea[22],Subarea[23],Subarea[24],Subarea[25],Subarea[26],Subarea[27],Subarea[116]))
                f.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.5f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(Subarea[28],Subarea[29],Subarea[30],Subarea[31],Subarea[32],Subarea[33],Subarea[34],Subarea[35],Subarea[36],Subarea[37]))
                f.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(Subarea[38],Subarea[39],Subarea[40],Subarea[41],Subarea[42],Subarea[43],Subarea[44],Subarea[45],Subarea[46],Subarea[47]))
                f.write("{:>12.6f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(Subarea[48],Subarea[49],Subarea[50],Subarea[117],Subarea[118],Subarea[119]))
                f.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(Subarea[51]),int(Subarea[53]),int(Subarea[54]),int(Subarea[55]),int(Subarea[56]),int(Subarea[57]),int(Subarea[58]),int(Subarea[59]),int(Subarea[60]),int(Subarea[61]),int(Subarea[62]),0,0))
                f.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(Subarea[63],Subarea[64],Subarea[65],Subarea[66],Subarea[67],Subarea[68],Subarea[69],Subarea[70],Subarea[71],Subarea[72]))
                f.write("{:>12.4f}{:>13.2f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(Subarea[73],Subarea[74],Subarea[75],Subarea[76],Subarea[77],Subarea[78],Subarea[81],Subarea[79],Subarea[80],Subarea[120]))
                f.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(Subarea[82]),int(Subarea[83]),int(Subarea[84]),int(Subarea[85]),int(Subarea[86]),int(Subarea[87]),int(Subarea[88]),int(Subarea[89]),int(Subarea[90]),int(Subarea[91])))
                f.write("{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}\n".format(Subarea[92],Subarea[93],Subarea[94],Subarea[95],Subarea[96],Subarea[97],Subarea[98],Subarea[99],Subarea[100],Subarea[101]))
            f.write("\n\n")
            f.close()

    def sub(self, path, path2, File, Weather_name, OPS_name, apexparm = False):#, Watershed_Title=False):
        if apexparm == False:
            apexparm = [['','','0','','','']
                        ,['','','1','0','0','0','0','','0','0','0','0']
                        ,['0','0','','','0','0','0','0']
                        ,['','','0','','0','0','121.92','0','0','0']
                        ,['','0','0','0','','0','0','0','0','0']
                        ,['0','0','0','0','0','0','0','0','0','0']
                        ,['0','0','0','0','0','0']
                        ,['0','0','0','1','0','0','0','0','0','0','0','0','0']
                        ,['0','0','0','0','0','0','0','0','0','0']
                        ,['1','0','0','0','0','0','0','0','0','0']
                        ,['0','0','0','0','0','0','0','0','0','0']
                        ,['0','0','0','0','0','0','0','0','0','0']]
        
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSUBA":
                g = open(path2+"/"+line[2], "r")
                g_lines = g.readlines()
                g.close()
        for g_line in g_lines:
            g_line_strip = g_line.strip().split(" ")
            g_line = [x for x in g_line_strip if x] #g_line[1] = WINAPEX.SUB

            
        #MDB-Watershed 
        Read = self.Read_MDB(path + "\\"+ path.split("\\")[-1]+".mdb", "Watershed")
        Watershed = []
        hrus = []
        Reach = []
        
        for line in Read:  #Subbasin, Area(ha), Slo1(%), Len1(m)(longest path), Sll, Csl, Wid1, Dep1, Lat, Long, Elev
            Watershed.append([line[3],line[4],line[5],line[6],line[7],line[8],line[9],line[10],line[11],line[12],line[13]])
            hrus.append([line[3]])
        #MDB-hrus 
        Read = self.Read_MDB(path + "\\"+ path.split("\\")[-1]+".mdb", "hrus")
        for n in range(1, len(Watershed) + 1):
            for line in Read:
                if int(line[1]) == n: #OID, LANDUSE, Landuse_area, SOIL, Soil_area, Slope_area, Slope, Unique_code, HRU_ID, Subbasin
                    hrus[n-1].append([line[0],line[3],line[4],line[5],line[6],line[8],line[9],line[10], line[11], line[1]])
                    #Watershed[n-1].append([line[0],line[3],line[4],line[5],line[6],line[8],line[9],line[10], line[11]])

        #MBD-Reach 
        Read = self.Read_MDB(path + "\\"+ path.split("\\")[-1]+".mdb", "Reach")
        for n in range(1, len(Watershed) + 1):
            for line in Read:
                if int(line[6]) == n: #Subbasin, SubbasinR, Area, Len2, Slo2, Wid2, Dep2, minel, maxel  11
                    Watershed[n-1].append([line[6],line[7],line[8],line[9],line[10],line[11],line[12],line[13],line[14]])

        ##Subarea_sort
        Reach = []
        extreme = []
        Read_reverse = []
        extreme_sub = []
        WSA_minus = []
        for start in Read:
            if int(start[7]) == 0:
                Reach.append(start[6])
                n = start[6]
                
        for m in Read:
            Read_reverse.insert(0,m)
            extreme_sub.insert(0, m[7])

        m = 0
        for N in range(1, len(Watershed) + 1):
            for line in Read_reverse:
                SubbasinR = Reach[-N]
                if int(line[7]) == SubbasinR:
                    
                    Rindex = Reach.index(SubbasinR)
                    Reach.insert(Rindex, line[6])
                    m += 1
                    if m%2 == 0: 
                        WSA_minus.insert(0, line[6])
                        
        #Subarea_extreme
        for N in Reach:
            try:
                extreme_sub.index(N)
            except:
                extreme.insert(0,N)


        
        #INPS_list
        INPS_dict = {}
        Read = self.Read_MDB(File, "ApexFile")
        for line in Read:
            if line[1] == "FSOIL":
                f = open(path2+"/"+line[2], "r")
                f_lines = f.readlines()
                for f_line in f_lines:
                    f_line_strip = f_line.strip().split(" ")
                    f_line = [x for x in f_line_strip if x]
                    INPS_dict[f_line[2]] = f_line[1].split(".")[0]
                f.close()

        #IOPS list
        IOPS_dict = {}
        f = open(OPS_name+"/landuse_lookup.txt", "r")
        f_lines = f.readlines()
        for f_line in f_lines:
            f_split = f_line.split(", ")
            IOPS_dict[f_split[0]] = f_split[1].split(".")[0]

        #sub 작성
        if os.path.isfile(path2 + "/" + g_line[1]):
            os.remove(path2 + "/" + g_line[1])
            
        for reach in Reach:
            for nn in range(1, len(hrus)+1): #watershed len
                if reach == hrus[nn-1][0]:
                    for n in range(1, len(hrus[nn-1])): #hrus len
                        if hrus[nn-1][n][9] == hrus[nn-1][0]:
                    ##for line in Watershed[n-1]:

                        #if len(Watershed[n-1]) == 12:
                            f = open(path2 + "/" + g_line[1], "a")
                            now = time.localtime()
                            s = "%04d-%02d-%02d %02d:%02d:%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)
                
                            #f.write("{:>8d}{:>8d}{:>8d} {}  {} ! {}\n".format(int(Watershed[n-1][11][0]),int(Watershed[n-1][11][0]),int(0),s,Watershed[n-1][11][8],Watershed[n-1][11][7]))                
                            P = 0
                            apexparm[P][0] = hrus[nn-1][n][0]
                            apexparm[P][1] = hrus[nn-1][n][0]
                            apexparm[P][3] = s
                            apexparm[P][4] = hrus[nn-1][n][9]
                            apexparm[P][5] = hrus[nn-1][n][7]
                            f.write("{:>8d}{:>8d}{:>8d} {}  {} ! {}\n".format(int(apexparm[P][0]),int(apexparm[P][1]),int(apexparm[P][2]),apexparm[P][3],int(apexparm[P][4]),apexparm[P][5]))

                            P +=1
                            apexparm[P][0] = INPS_dict[str(hrus[nn-1][n][3])] #INPS 
                            apexparm[P][1] = IOPS_dict[str(hrus[nn-1][n][1])] #IOPS
                            #copy ops file
                            for ops in os.listdir(OPS_name):
                                if ops.split(".")[0].startswith(str(IOPS_dict[str(hrus[nn-1][n][1])])):
                                    shutil.copy(OPS_name+"/"+ops, path2+"/"+ops)
                            #apexparm[P][2] = IOW
                            #WITH_list
                            WITH_min = 9999
                            Read = self.Read_MDB(File, "ApexFile")
                            for line in Read:
                                if line[1] == "FPMV":
                                    h = open(path2+"/"+line[2], "r")
                                    h_lines = h.readlines()
                                    for h_line in h_lines:
                                        h_line_strip = h_line.strip().split(" ")
                                        h_line = [x for x in h_line_strip if x]   #num, KR0090.DLY, 38, 128, elev, name

                                        distance = (float(Watershed[nn-1][8])-float(h_line[2]))**2 + (float(Watershed[nn-1][9])-float(h_line[3]))**2
                                        if WITH_min > distance:
                                            WITH_min = distance
                                            WITH = h_line[0]
                                            WITH_file = h_line[1]
                                    h.close()
                            apexparm[P][7] = WITH
                            shutil.copy(Weather_name+"/"+WITH_file, path2+"/"+WITH_file)
                            #apexparm[P][10] = LUNS
                            f.write("{:>8d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}{:>7d}\n".format(int(apexparm[P][0]),int(apexparm[P][1]),int(apexparm[P][2]),int(apexparm[P][3]),int(apexparm[P][4]),int(apexparm[P][5]),int(apexparm[P][6]),int(apexparm[P][7]),int(apexparm[P][8]),int(apexparm[P][9]),int(apexparm[P][10]),int(apexparm[P][11])))

                            P +=1
                            apexparm[P][2] = Watershed[nn-1][8]
                            apexparm[P][3] = Watershed[nn-1][9]
                            f.write("{:>12.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(float(apexparm[P][0]),float(apexparm[P][1]),float(apexparm[P][2]),float(apexparm[P][3]),float(apexparm[P][4]),float(apexparm[P][5]),float(apexparm[P][6]),float(apexparm[P][7])))

                            P +=1                                
                            if len(hrus[nn-1])-1 == 1:
                                apexparm[P][0] = hrus[nn-1][n][5]
                                for WSA_test in WSA_minus:
                                    if hrus[nn-1][0] == WSA_test:
                                        apexparm[P][0] = hrus[nn-1][n][5] * (-1)
                            else:
                                if n == 1:
                                    apexparm[P][0] = hrus[nn-1][n][5]  #AREA
                                else:
                                    apexparm[P][0] = hrus[nn-1][n][5] * (-1)
                                    
                            
                            #apexparm[P][1] = Watershed[nn-1][3] #CHL
                            apexparm[P][1] = Watershed[nn-1][3]/(len(hrus[nn-1])-1)#Divide_CHL/RCHL(HRU)
                            
                            #extreme_test
                            for extreme_test in extreme:
                                if hrus[nn-1][0] == extreme_test:
                                    extreme_test_n = 0
                                    for hrus_extreme in hrus[nn-1]:
                                        extreme_test_n += 1
                                        if extreme_test_n == 1:
                                            #apexparm[P][1] = Watershed[nn-1][11][3]
                                            apexparm[P][1] = Watershed[nn-1][11][3]/(len(hrus[nn-1])-1) #(cause RCHL = CHL) #Divide_CHL/RCHL(HRU)

                            apexparm[P][3] = Watershed[nn-1][5] #CHS
                            #apexparm[P][4] = 0 #CHN
                            apexparm[P][6] = Watershed[nn-1][4] #121.92(slopelength) #121.92 => delete
                            #apexparm[P][7] = 0 #UPN
                            f.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.4f}{:>13.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(apexparm[P][0]),float(apexparm[P][1])/1000,float(apexparm[P][2]),float(apexparm[P][3]),float(apexparm[P][4]),float(apexparm[P][5]),float(apexparm[P][6]),float(apexparm[P][7]),float(apexparm[P][8]),float(apexparm[P][9])))

                            P +=1  #OID, LANDUSE, Landuse_area, SOIL, Soil_area, Slope_area, Slope, Unique_code, HRU_ID
                            
                            #apexparm[P][0] = Watershed[nn-1][11][3] #RCHL
                            apexparm[P][0] = Watershed[nn-1][11][3]/(len(hrus[nn-1])-1)#Divide_CHL/RCHL(HRU)
                            
                            apexparm[P][4] = Watershed[nn-1][11][4] #RCHS
                            #apexparm[P][5] = 0 #RCHN
                            #apexparm[P][6] = 0 #RCHC
                            f.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.5f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(apexparm[P][0])/1000,float(apexparm[P][1]),float(apexparm[P][2]),float(apexparm[P][3]),float(apexparm[P][4]),float(apexparm[P][5]),float(apexparm[P][6]),float(apexparm[P][7]),float(apexparm[P][8]),float(apexparm[P][9])))

                            P +=1
                            f.write("{:>12.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(apexparm[P][0]),float(apexparm[P][1]),float(apexparm[P][2]),float(apexparm[P][3]),float(apexparm[P][4]),float(apexparm[P][5]),float(apexparm[P][6]),float(apexparm[P][7]),float(apexparm[P][8]),float(apexparm[P][9])))
                            P +=1
                            f.write("{:>12.6f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(apexparm[P][0]),float(apexparm[P][1]),float(apexparm[P][2]),float(apexparm[P][3]),float(apexparm[P][4]),float(apexparm[P][5])))
                            P +=1
                            f.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(apexparm[P][0]),int(apexparm[P][1]),int(apexparm[P][2]),int(apexparm[P][3]),int(apexparm[P][4]),int(apexparm[P][5]),int(apexparm[P][6]),int(apexparm[P][7]),int(apexparm[P][8]),int(apexparm[P][9]),int(apexparm[P][10]),int(apexparm[P][11]),int(apexparm[P][12])))
                            P +=1
                            f.write("{:>12.4f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}\n".format(float(apexparm[P][0]),float(apexparm[P][1]),float(apexparm[P][2]),float(apexparm[P][3]),float(apexparm[P][4]),float(apexparm[P][5]),float(apexparm[P][6]),float(apexparm[P][7]),float(apexparm[P][8]),float(apexparm[P][9])))
                            P +=1
                            f.write("{:>12.4f}{:>13.2f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.3f}{:>13.2f}{:>13.2f}{:>13.2f}{:>13.2f}\n".format(float(apexparm[P][0]),float(apexparm[P][1]),float(apexparm[P][2]),float(apexparm[P][3]),float(apexparm[P][4]),float(apexparm[P][5]),float(apexparm[P][6]),float(apexparm[P][7]),float(apexparm[P][8]),float(apexparm[P][9])))
                            P +=1
                            f.write("{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}{:>4d}\n".format(int(apexparm[P][0]),int(apexparm[P][1]),int(apexparm[P][2]),int(apexparm[P][3]),int(apexparm[P][4]),int(apexparm[P][5]),int(apexparm[P][6]),int(apexparm[P][7]),int(apexparm[P][8]),int(apexparm[P][9])))
                            P +=1
                            f.write("{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}{:>12.4f}\n".format(float(apexparm[P][0]),float(apexparm[P][1]),float(apexparm[P][2]),float(apexparm[P][3]),float(apexparm[P][4]),float(apexparm[P][5]),float(apexparm[P][6]),float(apexparm[P][7]),float(apexparm[P][8]),float(apexparm[P][9])))
                            f.close()
        f = open(path2 + "/" + g_line[1], "a")
        f.write("\n\n")
        f.close()

